﻿using CF4xxxDeviceLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Utils;

namespace CF4xxxDemo
{



    public partial class Form1 : Form
    {


        DeviceInfo_t[] deviceList;
        int deviceNumber = 0;
        int deviceHandle = 0;
        float[] g_measureData = new float[4];
        float[] g_saturation = new float[4];
        int g_signalNumber = 0;
        int g_channel = 0;
        int[][] signal = new int[2][];
        int channelIndex = 0;
        int[] triggerCount = new int[]{0,0,0};
        float[] distance = new float[] { 0, 0, 0 ,0,};
        int distanceLen = 0;
        bool isTriggerPass = false;


        public Form1()
        {
            InitializeComponent();
            signal[0] = new int[0];
            signal[1] = new int[0];
        }
        /// <summary>
        /// 获取时间戳
        /// </summary>
        /// <returns></returns>
        public Int64 GetTimeStamp()
        {
            TimeSpan ts = DateTime.Now - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return Convert.ToInt64(ts.TotalMilliseconds);
        }


        void singleChannelDataProcess(IntPtr data,int dataLen)
        {

            //获取测量结果，数组存储每个通道的计算结果，如果只有一个通道，则数组长度为1
            SC_ResultDataTypeDef_t[] result = Util.IntPtrToStructArray<SC_ResultDataTypeDef_t>(data, dataLen);

            for (int i = 0; i < result.Length; i++)
            {
                if (result[i].channelIndex == channelIndex)
                {
                    g_channel = result[i].channelIndex;   //该结果对应的通道索引
                    g_measureData[0] = result[i].result[0];  //测量结果,默认没有使能多距离测量模式只有resul[0]数据是有效的
                    g_saturation [0]= result[i].saturation;   //信号饱和度
                    g_signalNumber = result[i].resultLen;       //检测到信号个数
                    isTriggerPass = result[i].bTriggerPass !=0 ? true:false;
                        
                    //触发计数，仅适用于CF2000
                    if (rb_cf2000.Checked)
                    {
                        //触发计数，仅适用于CF2000
                        triggerCount[0] = result[i].triggerCount; //编码器通道1
                        triggerCount[1] = result[i].triggerCount1; //编码器通道1
                        triggerCount[2] = result[i].triggerCount2; //编码器通道1
                    }
                   
                    //厚度模式下，会输出每个波峰对应的距离
                    for(int n=0; n< result[i].distanceNumber && n < distance.Length; n++)
                    {
                        distance[n] = result[i].distance[n];
                    }
                    distanceLen = result[i].distanceNumber;


                    //获取通道信号值，仅调试用
                    signal[0] = CF4xxxDevice.getSignal(new IntPtr(result[i].signal), result[i].signalLength);

                }

            }
        }


        void doubleChannelDataProcess(IntPtr data, int dataLen)
        {
            //获取测量结果，数组存储每个通道的计算结果，如果只有一个通道，则数组长度为1
            MC_ResultDataTypeDef_t[] result = Util.IntPtrToStructArray<MC_ResultDataTypeDef_t>(data, dataLen);

           
            g_measureData[0] = result[0].thickness;  //测量结果,默认没有使能多距离测量模式只有resul[0]数据是有效的
            g_saturation[0]= result[0].channelResult[0].saturation;   //信号饱和度
            g_saturation[1] = result[0].channelResult[1].saturation;   //信号饱和度
            isTriggerPass = result[0].bTriggerPass != 0 ? true : false;
            //触发计数，仅适用于CF2000
            if (rb_cf2000.Checked)
            {
                triggerCount[0] = result[0].triggerCount; //编码器通道1
                triggerCount[1] = result[0].triggerCount1; //编码器通道1
                triggerCount[2] = result[0].triggerCount2; //编码器通道1
            }

            //获取第一个通道信号值，仅调试用
            signal[0] = CF4xxxDevice.getSignal(new IntPtr(result[0].channelResult[0].signal), result[0].channelResult[0].signalLength);
            signal[1] = CF4xxxDevice.getSignal(new IntPtr(result[0].channelResult[1].signal), result[0].channelResult[1].signalLength);

        }
        /// <summary>
        /// 传感器事件回调函数
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="arg"></param>
        /// <param name="userPara"></param>
        public  void UserEventCallbackHandle(int handle, EventCallbackArgs_t arg, IntPtr userPara)
        {
            // 光谱共焦数据回调函数，这里不宜做复杂的操作，应该只是将数据拷贝走
		    //接收到数据
            if (arg.eventType == EventTypeDef.EventType_DataRecv)
            {
                //数据类型
                if (arg.rid == (int)ConfocalDataRid_t.RID_RESULT)                //数据接收事件
                {
                    //双头测厚模式
                    if (cb_doubleChannel.Checked)
                    {
                        doubleChannelDataProcess(arg.data, arg.dataLen);
                    }
                    else
                    {
                        singleChannelDataProcess(arg.data, arg.dataLen);
                    }

                }
                else if (arg.rid == (int)ConfocalDataRid_t.RID_DEVICE_DISCONNECT) //设备端口事件
                {
                    MessageBox.Show( "Device disconnected!");
                }
                else if (arg.rid == (int)ConfocalDataRid_t.RID_API_CALL_EXCEPTION) //API调用异常事件
                {
              
                    string str = Marshal.PtrToStringAnsi(arg.data);
                    rtb_error_text.AppendText(str+"\n");
                }
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cb_inputport_func1.SelectedIndex = 0;
            cb_inputport_func2.SelectedIndex = 0;
            cb_calibrationmode.SelectedIndex = 0;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(CF4xxxDevice.hps_isOpen(deviceHandle))
                 CF4xxxDevice.hps_closeDevice(deviceHandle);
        }

        private void btn_scan_device_Click(object sender, EventArgs e)
        {
            //扫描设备列表，适用于CF1000/CF4000控制器
            StatusTypeDef ret = CF4xxxDevice.hps_scanDeviceList(out deviceList, out deviceNumber);
            if (ret != StatusTypeDef.Status_Succeed)
            {
                MessageBox.Show("失败，错误码: " + ret);
                return;
            }
            lb_device_number.Text = deviceNumber.ToString();
            if(deviceNumber==0)
            {
                MessageBox.Show("未检测到设备");
            }
        }




        private void btn_open_device_Click(object sender, EventArgs e)
        {
            if((rb_cf4000.Checked || rb_cf1000.Checked) && deviceNumber <=0 )
            {
                MessageBox.Show("请扫描设备");
                return;
            }

            if (CF4xxxDevice.hps_isOpen(deviceHandle))
            {
                return;
            }

            StatusTypeDef ret;
            if (rb_cf4000.Checked || rb_cf1000.Checked)
                //连接CF4000控制器
                ret =  CF4xxxDevice.hps_openDevice(deviceList[0], ref deviceHandle);           
            else
            {
                ControllerGEPara_t controllerPara = new ControllerGEPara_t();
                controllerPara.controllerIp = null;
                deviceNumber = 1;
                lb_device_number.Text = deviceNumber.ToString();

  
                //连接CF2000控制器
                ret = CF4xxxDevice.hps_GE_openDevice(controllerPara, null, ref deviceHandle);   

                if(ret == StatusTypeDef.Status_Succeed)
                {
                    string ip;
                    string mac;
                    UInt16 port;
                    CF4xxxDevice.hps_GE_getControlConnectParam(deviceHandle, out ip, out port, out mac);

                    lb_cf2000ip.Text = ip;
                    lb_cf2000port.Text = port.ToString();
                    lb_cf2000mac.Text = mac;
                }
            }
               
            if (ret!= StatusTypeDef.Status_Succeed)
            {
                MessageBox.Show("失败，错误码: "+ ret);
                return;
            }

            //gb_connectDevice.Enabled = false;
            lb_sdk_version.Text =  CF4xxxDevice.hps_getSDKVersion();
            lb_controler_version.Text = CF4xxxDevice.hps_getControlerVersion(deviceHandle);
            lb_controler_SN.Text = CF4xxxDevice.hps_getControlerSN(deviceHandle);
            gb_control.Enabled = true;
            cb_doubleChannel.Enabled = true;


 
        }

        void doubleChannelEnable()
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;



            bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);
            if (reStart)
                CF4xxxDevice.hps_continueCaptureStop(deviceHandle);

            //双头测厚
            if (cb_doubleChannel.Checked)
            {

                /***********************************配置传感器的测量模式**************************************/
                //关闭独立测量模式，启用多传感头协作工作模式
                CF4xxxDevice.hps_setChannelIndependentMode(deviceHandle, false);
                //设置多传感头协同模式下的测量模式为厚度测量
                CF4xxxDevice.hps_setMultiChannelMeasureMode(deviceHandle, Confocal_CooperationMeasureMode_t.CM_Thickness);
                //设置双头测厚组索引为0，对应使用通道0和通道1传感头进行测量
                //若组索引为1则使用通道2和通道3传感头进行测量
                CF4xxxDevice.hps_setDoubleChannelThicknessGroupIndex(deviceHandle, 0, true);

                //获取当前校准系数
                double[] coef = new double[3];
                CF4xxxDevice.hps_getDoubleChannelThicknessK(deviceHandle,0, coef);
                nud_k0.Value = (decimal)coef[0];
                nud_k1.Value = (decimal)coef[1];
                nud_k2.Value = (decimal)coef[2];

                btn_zero.Enabled = false;

            }
            else
            {
                //打开独立测量模式
                CF4xxxDevice.hps_setChannelIndependentMode(deviceHandle, true);

                btn_zero.Enabled = true;
            }


            if (reStart)
                CF4xxxDevice.hps_continueCaptureStart(deviceHandle);
        }

        private void btn_start_sample_Click(object sender, EventArgs e)
        {
          
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
            {
                MessageBox.Show("设备未打开");
                return;
            }

            //已经启动连续测量
            if (CF4xxxDevice.hps_isCaptureStart(deviceHandle))
                return;


            //注册接收回调函数
            CF4xxxDevice.hps_registerEventCallback(new UserEventCallbackHandleDelegate(UserEventCallbackHandle), IntPtr.Zero);
           
            //输出信号值，用于信号可视化，方便调试，该接口仅在调试中用，实际项目中可以去掉
            CF4xxxDevice.hps_setSignalDataOutput(deviceHandle, true);


            doubleChannelEnable();


            //启动测量
            CF4xxxDevice.hps_continueCaptureStart(deviceHandle);


            timer1.Start();

            cb_doubleChannel.Enabled = false;

        }

        private void btn_error_text_clear_Click(object sender, EventArgs e)
        {
            rtb_error_text.Clear();
        }

        private void btn_stop_sample_Click(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
            {
                MessageBox.Show("设备未打开");
                return;
            }
            //停止测量
            CF4xxxDevice.hps_continueCaptureStop(deviceHandle);

            cb_doubleChannel.Enabled = true;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;


            lb_result.Text      = g_measureData[0].ToString("0.0000");
            lb_saturation.Text  = g_saturation[0].ToString("0.0") + " %";
            lb_saturation2.Text = g_saturation[1].ToString("0.0") + " %";
            lb_signalNumber.Text = g_signalNumber.ToString();

            lb_frameRate.Text = CF4xxxDevice.hps_getCurFrameRate(deviceHandle).ToString() ;

           if(signal[0].Length > 0)
                chart1.Series["Signal"].Points.DataBindY(signal[0]);

            if (signal[1].Length > 0)
                chart2.Series["Signal"].Points.DataBindY(signal[1]);


            lb_trigger0.Text = triggerCount[0].ToString();
            lb_trigger1.Text = triggerCount[1].ToString();
            lb_trigger2.Text = triggerCount[2].ToString();


            lb_dis1.Text = distance[0].ToString("0.000");
            lb_dis2.Text = distance[1].ToString("0.000");
            lb_dis3.Text = distance[2].ToString("0.000");
            lb_dis4.Text = distance[3].ToString("0.000");
            lb_distanceNumber.Text = distanceLen.ToString();

            if (isTriggerPass)
                lb_isTriggerPass.Text = "1";
            else
                lb_isTriggerPass.Text = "0";

        }

        private void btn_zero_Click(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
            {
                MessageBox.Show("设备未打开");
                return;
            }
            StatusTypeDef ret;
            if (!cb_doubleChannel.Checked)
                ret = CF4xxxDevice.hps_zero(deviceHandle, channelIndex); //单头zero

        }

        private void rb_cf4000_CheckedChanged(object sender, EventArgs e)
        {
            if(rb_cf4000.Checked)
            {
                CF4xxxDevice.hps_setControllerModel(ControlerModel_t.Model_CF4000);
                btn_scan_device.Enabled = true;
                btn_open_device.Enabled = true;
            }
        }

        private void rb_cf2000_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_cf2000.Checked)
            {
                btn_scan_device.Enabled = false;
                btn_open_device.Enabled = true;
            }
        }

        private void btn_dark_Click(object sender, EventArgs e)
        {
            if(CF4xxxDevice.hps_isOpen(deviceHandle))
            {
                if(cb_dark_all_ch.Checked)
                     CF4xxxDevice.hps_darkSignal(deviceHandle, -1, cb_presetExpTime.Checked);
                else
                     CF4xxxDevice.hps_darkSignal(deviceHandle, channelIndex, cb_presetExpTime.Checked);
            }
        }

        private void btn_setExpTime_Click(object sender, EventArgs e)
        {
            CF4xxxDevice.hps_setExposureTime(deviceHandle, (PresetExposureTime_t)((int)nud_expTime.Value));
        }

        private void rb_autoLight_CheckedChanged(object sender, EventArgs e)
        {
            CF4xxxDevice.hps_setAutoLightIntensity(deviceHandle, channelIndex, true);
        }

        private void rb_manualLight_CheckedChanged(object sender, EventArgs e)
        {
            CF4xxxDevice.hps_setAutoLightIntensity(deviceHandle, channelIndex, false);
        }

        private void tb_light_TabIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void tb_light_Scroll(object sender, EventArgs e)
        {
            lb_light.Text = tb_light.Value.ToString();
            CF4xxxDevice.hps_setLightIntensity(deviceHandle, channelIndex, (byte)tb_light.Value);
        }

        private void btn_singleShot_Click(object sender, EventArgs e)
        {
            if(CF4xxxDevice.hps_isOpen(deviceHandle))
            {
          
                //双头测厚模式
                if(cb_doubleChannel.Checked)
                {
                    MC_ResultDataTypeDef_t[] result;
                    if (CF4xxxDevice.hps_singleShot_MC(deviceHandle, out result) == StatusTypeDef.Status_Succeed)
                    {
                        g_measureData[0] = result[0].thickness;  //测量结果,默认没有使能多距离测量模式只有resul[0]数据是有效的
                        g_saturation[0] = result[0].channelResult[0].saturation;   //信号饱和度
                        g_saturation[1] = result[0].channelResult[1].saturation;   //信号饱和度
                        isTriggerPass = result[0].bTriggerPass != 0 ? true : false;
                        //触发计数，仅适用于CF2000
                        if (rb_cf2000.Checked)
                        {
                            triggerCount[0] = result[0].triggerCount; //编码器通道1
                            triggerCount[1] = result[0].triggerCount1; //编码器通道1
                            triggerCount[2] = result[0].triggerCount2; //编码器通道1
                        }

                        //获取第一个通道信号值，仅调试用
                        signal[0] = CF4xxxDevice.getSignal(new IntPtr(result[0].channelResult[0].signal), result[0].channelResult[0].signalLength);
                        signal[1] = CF4xxxDevice.getSignal(new IntPtr(result[0].channelResult[1].signal), result[0].channelResult[1].signalLength);
                    }


                }
                //单头模式
                else
                {
                    SC_ResultDataTypeDef_t[] result;
                    if (CF4xxxDevice.hps_singleShot(deviceHandle, out result) == StatusTypeDef.Status_Succeed)
                    {
                        for (int i = 0; i < 4; i++)
                        {
                            if (result[i].channelIndex == channelIndex)
                            {

                                //获取第一个通道信号值，仅调试用
                                signal[0] = CF4xxxDevice.getSignal(new IntPtr(result[i].signal), result[i].signalLength);
                                g_channel = result[i].channelIndex;      //该结果对应的通道索引
                                g_measureData[0] = result[i].result[0];  //测量结果,默认没有使能多距离测量模式只有resul[0]数据是有效的
                                g_saturation[0] = result[i].saturation;   //信号
                                break;
                            }
                        }

                    }
                }
                   
            
              
            }
         }

        private void btn_saveConfig_Click(object sender, EventArgs e)
        {
            if (CF4xxxDevice.hps_isOpen(deviceHandle))
            {

                bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);
                if (reStart)
                        CF4xxxDevice.hps_continueCaptureStop(deviceHandle);

                CF4xxxDevice.hps_saveUserSetting(deviceHandle);

                if (reStart)
                        CF4xxxDevice.hps_continueCaptureStart(deviceHandle);
            }
        }

      

        private void cb_frameRateControlMode_CheckedChanged(object sender, EventArgs e)
        {
            CF4xxxDevice.hps_acquisitionFrameMode(deviceHandle, cb_frameRateControlMode.Checked);

            if(cb_frameRateControlMode.Checked)
            {
                nud_frameRate.Enabled = true;
                btn_setFrameRate.Enabled = true;
            }
            else
            {
                nud_frameRate.Enabled = false;
                btn_setFrameRate.Enabled = false;
            }
        }

        private void btn_setFrameRate_Click(object sender, EventArgs e)
        {
            CF4xxxDevice.hps_acquisitionFrameRate(deviceHandle, (int)nud_frameRate.Value);
        }

        private void btn_setMobingAverageFilter_Click(object sender, EventArgs e)
        {
            CF4xxxDevice.hps_setMovingAverageFilter(deviceHandle, channelIndex, (int)nud_movingAverageFilter.Value);
        }

        private void btn_setMedianFilter_Click(object sender, EventArgs e)
        {
            CF4xxxDevice.hps_setMedianFilter(deviceHandle, channelIndex, (int)nud_medianFilter.Value);
        }

        private void cb_channe_1_lEnable_CheckedChanged(object sender, EventArgs e)
        {
            bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);

            if (reStart)
                CF4xxxDevice.hps_continueCaptureStop(deviceHandle);

            if (cb_channe_1_lEnable.Checked)
                CF4xxxDevice.hps_activeChannel(deviceHandle, 0,true);
            else
                CF4xxxDevice.hps_activeChannel(deviceHandle, 0, false);

            if (reStart)
                CF4xxxDevice.hps_continueCaptureStart(deviceHandle);
        }

        private void cb_channelSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            byte[] channel = new byte[4];


            if(!CF4xxxDevice.hps_isOpen(deviceHandle))
            {
                cb_channelSelect.SelectedIndex = channelIndex;
                return;
            }

            CF4xxxDevice.hps_getActiveChannel(deviceHandle, channel);
            if (channel[cb_channelSelect.SelectedIndex] > 0)
                channelIndex = cb_channelSelect.SelectedIndex;
            else
                cb_channelSelect.SelectedIndex = channelIndex;
        }

        private void cb_channe_2_lEnable_CheckedChanged(object sender, EventArgs e)
        {
            bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);
            if (reStart)
                CF4xxxDevice.hps_continueCaptureStop(deviceHandle);


            if (cb_channe_2_lEnable.Checked)
                CF4xxxDevice.hps_activeChannel(deviceHandle, 1, true);
            else
                CF4xxxDevice.hps_activeChannel(deviceHandle, 1, false);

            if (reStart)
                CF4xxxDevice.hps_continueCaptureStart(deviceHandle);
        }

        private void cb_channe_3_lEnable_CheckedChanged(object sender, EventArgs e)
        {
            bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);
            if (reStart)
                CF4xxxDevice.hps_continueCaptureStop(deviceHandle);


            if (cb_channe_3_lEnable.Checked)
                CF4xxxDevice.hps_activeChannel(deviceHandle, 2,true);
            else
                CF4xxxDevice.hps_activeChannel(deviceHandle, 2, false);

            if (reStart)
                CF4xxxDevice.hps_continueCaptureStart(deviceHandle);
        }

        private void cb_channe_4_lEnable_CheckedChanged(object sender, EventArgs e)
        {
            bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);
            if (reStart)
                CF4xxxDevice.hps_continueCaptureStop(deviceHandle);


            if (cb_channe_4_lEnable.Checked)
                CF4xxxDevice.hps_activeChannel(deviceHandle, 3, true);
            else
                CF4xxxDevice.hps_activeChannel(deviceHandle, 3, false);

            if (reStart)
                CF4xxxDevice.hps_continueCaptureStart(deviceHandle);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);
            if (reStart)
                CF4xxxDevice.hps_continueCaptureStop(deviceHandle);


            if (cb_singleCH_MeasureMode.Text == "距离")
            {
                CF4xxxDevice.hps_setChannelMeasureMode(deviceHandle, channelIndex,  Confocal_MeasureMode_t.MeasureMode_Distance);
            }
            else
            {
                CF4xxxDevice.hps_setChannelMeasureMode(deviceHandle, channelIndex,    Confocal_MeasureMode_t.MeasureMode_Thickness);
            }

            if (reStart)
                CF4xxxDevice.hps_continueCaptureStart(deviceHandle);
        }


        private void rb_mulDis_EN_CheckedChanged(object sender, EventArgs e)
        {

            bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);
            if (reStart)
                CF4xxxDevice.hps_continueCaptureStop(deviceHandle);


            if (rb_mulDis_EN.Checked)
            {
                CF4xxxDevice.hps_setMultiDistanceMode(deviceHandle, channelIndex,true);
                nud_mainFaculIndex.Enabled = true;
                cb_signalSelect.Enabled = false;
            }
            else
            {
                CF4xxxDevice.hps_setMultiDistanceMode(deviceHandle, channelIndex, false);
                nud_mainFaculIndex.Enabled = false;
                cb_signalSelect.Enabled = true;
            }

            if (reStart)
                CF4xxxDevice.hps_continueCaptureStart(deviceHandle);
        }

        private void rb_mulDis_DIS_CheckedChanged(object sender, EventArgs e)
        {

            bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);
            if (reStart)
                CF4xxxDevice.hps_continueCaptureStop(deviceHandle);


            if (rb_mulDis_DIS.Checked)
            {
                CF4xxxDevice.hps_setMultiDistanceMode(deviceHandle, channelIndex, false);
                nud_mainFaculIndex.Enabled = false;
                cb_signalSelect.Enabled = true;
            }
            else
            {
                CF4xxxDevice.hps_setMultiDistanceMode(deviceHandle, channelIndex, true);
                nud_mainFaculIndex.Enabled = true;
                cb_signalSelect.Enabled = false;
            }

            if (reStart)
                CF4xxxDevice.hps_continueCaptureStart(deviceHandle);
        }

        private void btn_signalSet_Click(object sender, EventArgs e)
        {

            bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);
            if (reStart)
                CF4xxxDevice.hps_continueCaptureStop(deviceHandle);

            if (rb_mulDis_EN.Checked)
            {
                CF4xxxDevice.hps_setMainSignalIndex(deviceHandle, channelIndex, (int)nud_mainFaculIndex.Value);
                
            }
            else
            {
               if(cb_signalSelect.Text == "Near")
                {
                    CF4xxxDevice.hps_selectSignal(deviceHandle, channelIndex, Confocal_SignalSelect_t.Signal_NearEnd);
                }
                else if(cb_signalSelect.Text == "Far")
                {
                    CF4xxxDevice.hps_selectSignal(deviceHandle, channelIndex, Confocal_SignalSelect_t.Signal_FarEnd);
                }
               else
                {
                    CF4xxxDevice.hps_selectSignal(deviceHandle, channelIndex, Confocal_SignalSelect_t.Signal_MaxIntensity);
                }
            }

            if (reStart)
                CF4xxxDevice.hps_continueCaptureStart(deviceHandle);
        }

        private void btn_offset_set_Click(object sender, EventArgs e)
        {
            try
            {
                double value = Convert.ToDouble(tb_offset.Text);
                CF4xxxDevice.hps_setChxOffset(deviceHandle, channelIndex, (float)value);

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(CF4xxxDevice.hps_isOpen(deviceHandle))
            {
                bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);
                if (reStart)
                    CF4xxxDevice.hps_continueCaptureStop(deviceHandle);

                CF4xxxDevice.hps_restoreFactorySetting(deviceHandle);

                if (reStart)
                    CF4xxxDevice.hps_continueCaptureStart(deviceHandle);
            }
        }

        private void cb_doubleChannel_CheckedChanged(object sender, EventArgs e)
        {
            doubleChannelEnable();
        }

        private void cb_doubleChannel_MouseUp(object sender, MouseEventArgs e)
        {
            if (CF4xxxDevice.hps_isOpen(deviceHandle))
            {
                byte[] ch = new byte[4];
                int activeChannelNumber = 0;
                CF4xxxDevice.hps_getActiveChannel(deviceHandle, ch);
                if ((ch[0] > 0 && ch[1] > 0) || (ch[2] > 0 && ch[3] > 0))
                {
          
                }
                else
                {

                    MessageBox.Show("检测不到两个对称通道");
                    cb_doubleChannel.Checked = !cb_doubleChannel.Checked;
                }
            }
        }

        private void cb_triggerMode_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_trigger_set_Click(object sender, EventArgs e)
        {
            bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);
            if (reStart)
                CF4xxxDevice.hps_continueCaptureStop(deviceHandle);

            if (cb_triggerMode.Text == "Internal trigger")
            {
                CF4xxxDevice.hps_setTriggerMode(deviceHandle, Confocal_TriggerMode_t.Trigger_Internal);
            }
            else if (cb_triggerMode.Text == "Encoder trigger")
            {
                CF4xxxDevice.hps_setTriggerMode(deviceHandle, Confocal_TriggerMode_t.Trigger_Encoder);
            }
            else if(cb_triggerMode.Text == "Timing trigger")
            {
                CF4xxxDevice.hps_setTriggerMode(deviceHandle, Confocal_TriggerMode_t.Trigger_Timing);
            }
            else if(cb_triggerMode.Text == "Extern trigger")
            {
                CF4xxxDevice.hps_setTriggerMode(deviceHandle, Confocal_TriggerMode_t.Trigger_Extern);
            }




            if(cb_encoderTriggerSource.Text == "Channel 0")
            {
                CF4xxxDevice.hps_setEncoderChannel(deviceHandle,0);
            }
            else if (cb_encoderTriggerSource.Text == "Channel 1")
            {
                CF4xxxDevice.hps_setEncoderChannel(deviceHandle, 1);
            }
            else if (cb_encoderTriggerSource.Text == "Channel 2")
            {
                CF4xxxDevice.hps_setEncoderChannel(deviceHandle, 2);
            }



            if(cb_syncTriggerOut.Text =="Enable")
            {
                CF4xxxDevice.hps_setTriggerSyncOut(deviceHandle,true);
            }
            else if(cb_syncTriggerOut.Text == "Disable")
            {
                CF4xxxDevice.hps_setTriggerSyncOut(deviceHandle, false);
            }


            if (reStart)
                CF4xxxDevice.hps_continueCaptureStart(deviceHandle);

        }

        private void btn_encoderDivSet_Click(object sender, EventArgs e)
        {
            CF4xxxDevice.hps_setEncoderDivision(deviceHandle, (UInt16)nud_encoderDivision.Value);
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CF4xxxDevice.hps_setTimmerTriggerFreq(deviceHandle, (UInt32)nud_timingTriggerHZ.Value);
        }

        private void btn_ethernetPara_Click(object sender, EventArgs e)
        {
            bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);
            if (reStart)
                CF4xxxDevice.hps_continueCaptureStop(deviceHandle);

            CF4xxxDevice.hps_setControllerIPAddr(deviceHandle, tb_ip.Text);
            CF4xxxDevice.hps_setControllerPort(deviceHandle, (UInt16)nud_controllerport.Value);


            if (reStart)
                CF4xxxDevice.hps_continueCaptureStart(deviceHandle);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (CF4xxxDevice.hps_isOpen(deviceHandle))
            {
                CF4xxxDevice.hps_closeDevice(deviceHandle);
            }
        }

        private void btn_vol_set_Click(object sender, EventArgs e)
        {

            try
            {
                double max_vol = Convert.ToDouble(tb_max_vol.Text);
                double mini_vol = Convert.ToDouble(tb_mini_vol.Text);
                double max_dis = Convert.ToDouble(tb_max_dis.Text);
                double mini_dis = Convert.ToDouble(tb_min_dis.Text);


                bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);
                if (reStart)
                    CF4xxxDevice.hps_continueCaptureStop(deviceHandle);


                CF4xxxDevice.hps_setAnalogVoltageMapping(deviceHandle, channelIndex, mini_vol, max_vol, mini_dis, max_dis);

                if (reStart)
                    CF4xxxDevice.hps_continueCaptureStart(deviceHandle);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void rb_vol_output_en_CheckedChanged(object sender, EventArgs e)
        {
            if(rb_vol_output_en.Checked)
                 CF4xxxDevice.hps_setAnalogVoltageOutput(deviceHandle, channelIndex, true);
            else
                CF4xxxDevice.hps_setAnalogVoltageOutput(deviceHandle, channelIndex, false);
        }

        private void rb_vol_output_disen_CheckedChanged(object sender, EventArgs e)
        {
            if(rb_vol_output_disen.Checked)
                CF4xxxDevice.hps_setAnalogVoltageOutput(deviceHandle, channelIndex, false);
            else
                CF4xxxDevice.hps_setAnalogVoltageOutput(deviceHandle, channelIndex, true);
        }

        private void groupBox9_Enter(object sender, EventArgs e)
        {

        }


        int getChannelIndex(string CH_Str)
        {
            int index = 0;
            switch (CH_Str)
            {
                case "Channel 1":
                    index = 0;
                    break;
                case "Channel 2":
                    index = 1;
                    break;
                case "Channel 3":
                    index = 2;
                    break;
                case "Channel 4":
                    index = 3;
                    break;
                default:
                    return 0;

            }
            return index;
        }

        AlarmType_t getIoOutputFunc(string FUN_Str)
        {
            AlarmType_t func = AlarmType_t.AlarmType_None;
            switch (FUN_Str)
            {
                case "Disable":
                    func = AlarmType_t.AlarmType_None;
                    break;
                case "HI":
                    func = AlarmType_t.AlarmType_UpperLimit;
                    break;
                case "LO":
                    func = AlarmType_t.AlarmType_LowerLimit;
                    break;
                case "Disconnect":
                    func = AlarmType_t.AlarmTyp_DeviceDisconnect;
                    break;
                case "SIG Weak":
                    func = AlarmType_t.AlarmType_SignalWeak;
                    break;
                case "SIG SAT":
                    func = AlarmType_t.AlarmType_SignalSaturated;
                    break;
                case "TEMP Error":
                    func = AlarmType_t.AlarmType_TempError;
                    break;
                case "Fan Error":
                    func = AlarmType_t.AlarmType_FanError;
                    break;
                default:
                    break;


            }

            return func;
        }

        IoPortState_t getIoOutputState(string STATE_Str)
        {
            IoPortState_t io_state = IoPortState_t.PortState_Off;

            if(STATE_Str == "N.C")
            {
                io_state = IoPortState_t.PortState_Off;
            }
            else
            {
                io_state = IoPortState_t.PortState_On;
            }

            return io_state;
        }



        private void btn_IO_OutputSet_Click(object sender, EventArgs e)
        {
            int output_io_number;
            if (rb_cf2000.Checked)
            {
                output_io_number = 3;
               
            }
            else
            {
                output_io_number = 4;
            }

            bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);
            if (reStart)
                CF4xxxDevice.hps_continueCaptureStop(deviceHandle);

            for (int i = 0; i < output_io_number; i++)
                CF4xxxDevice.hps_unbindAlarmIOPort(deviceHandle,i);

            int[] io_bind_ch = new int[4];
            AlarmType_t[] io_func = new AlarmType_t[4];
            IoPortState_t[] io_state = new IoPortState_t[4];

            io_bind_ch[0] = getChannelIndex(cb_OUT_IO_1_CH.Text);
            io_bind_ch[1] = getChannelIndex(cb_OUT_IO_2_CH.Text);
            io_bind_ch[2] = getChannelIndex(cb_OUT_IO_3_CH.Text);
            io_bind_ch[3] = getChannelIndex(cb_OUT_IO_4_CH.Text);

            io_func[0] = getIoOutputFunc(cb_OUT_IO_1_FUNC.Text);
            io_func[1] = getIoOutputFunc(cb_OUT_IO_2_FUNC.Text);
            io_func[2] = getIoOutputFunc(cb_OUT_IO_3_FUNC.Text);
            io_func[3] = getIoOutputFunc(cb_group.Text);

            io_state[0] = getIoOutputState(cb_OUT_IO_1_Mode.Text);
            io_state[1] = getIoOutputState(cb_OUT_IO_2_Mode.Text);
            io_state[2] = getIoOutputState(cb_OUT_IO_3_Mode.Text);
            io_state[3] = getIoOutputState(cb_OUT_IO_4_Mode.Text);

            for(int i=0;i< output_io_number; i++)
            {
                CF4xxxDevice.hps_bindAlarmIOPort(deviceHandle, io_bind_ch[i], io_func[i],i, io_state[i]);
            }

            if (reStart)
                CF4xxxDevice.hps_continueCaptureStart(deviceHandle);
        }

        private void btn_tol_set_Click(object sender, EventArgs e)
        {
           

            try
            {
                int progIndex = (int)nud_prrgSeg.Value;
                double upperLimit;
                double lowerLimit;

                upperLimit = Convert.ToDouble(tb_upperLimitValue.Text);
                lowerLimit = Convert.ToDouble(tb_lowerLimitValue.Text);

                CF4xxxDevice.hps_setProgramSegmentIndex(deviceHandle, channelIndex, progIndex);

                CF4xxxDevice.hps_setUpperLimit(deviceHandle, channelIndex, progIndex, upperLimit);

                CF4xxxDevice.hps_setLowerLimit(deviceHandle, channelIndex, progIndex, lowerLimit);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
         
        }

        private void btn_set_input_port_Click(object sender, EventArgs e)
        {

            bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);
            if (reStart)
                CF4xxxDevice.hps_continueCaptureStop(deviceHandle);



            CF4xxxDevice.hps_unbindInputPort(deviceHandle,0);
            CF4xxxDevice.hps_unbindInputPort(deviceHandle, 1);


            StatusTypeDef ret = CF4xxxDevice.hps_bindInputPort(deviceHandle, cb_inputport_ch_1.SelectedIndex, (Confocal_InputPortFunc_t)cb_inputport_func1.SelectedIndex,0);
            ret = CF4xxxDevice.hps_bindInputPort(deviceHandle, cb_inputport_ch_2.SelectedIndex, (Confocal_InputPortFunc_t)cb_inputport_func2.SelectedIndex, 1);


            if (reStart)
                CF4xxxDevice.hps_continueCaptureStart(deviceHandle);
        }

        private void rb_cf1000_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_cf1000.Checked)
            {
                CF4xxxDevice.hps_setControllerModel( ControlerModel_t.Model_CF1000);
                btn_scan_device.Enabled = true;
                btn_open_device.Enabled = true;
            }
        }

        private void rb_trubo_enalbe_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_trubo_enalbe.Checked)
                CF4xxxDevice.hps_setTurboMode(deviceHandle,true);
        }

        private void rb_trubo_disalbe_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_trubo_disalbe.Checked)
                CF4xxxDevice.hps_setTurboMode(deviceHandle, false);
        }

        private void cb_binningMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            CF4xxxDevice.hps_setVerticalBinning(deviceHandle, (Confocal_V_BinningMode)(cb_binningMode.SelectedIndex) );
        }

        private void btn_get_cache_res_count_Click(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;

            rb_cache_info.Clear();
            int dataCount = 0;
            CF4xxxDevice.hps_getCurDataCacheCount(deviceHandle, channelIndex, out dataCount);
            if(dataCount > 0)
            {
                double[] value = new double[2];
                int[] minMaxIndex = new int[2];
                CF4xxxDevice.hps_selectCacheData(deviceHandle, channelIndex, DataSetAttribute_t.Attribute_MinMax, value, minMaxIndex);
                rb_cache_info.AppendText("Data count: "+ dataCount.ToString()+"\n");
                rb_cache_info.AppendText("Min value: " + value[0].ToString("0.0000") + "  Index: "+ minMaxIndex[0].ToString()+"\n");
                rb_cache_info.AppendText("Max value: " + value[1].ToString("0.0000") + "  Index: " + minMaxIndex[1].ToString()+"\n");
            }
            else
            {
                rb_cache_info.AppendText("Data count: 0" );
            }
        }

        private void btn_clear_cache_Click(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;

            rb_cache_info.Clear();
            CF4xxxDevice.hps_clearDataCache(deviceHandle, channelIndex);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;

            int index = cb_encoder_input.SelectedIndex;
            if (index < 0)
                return;


            bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);
            if (reStart)
                CF4xxxDevice.hps_continueCaptureStop(deviceHandle);

            CF4xxxDevice.hps_setEncoderInputMode(deviceHandle,(Confocal_EncoderInputMode_t)index);

            if (reStart)
                CF4xxxDevice.hps_continueCaptureStart(deviceHandle);

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;

            int index = cb_encoder_working_mode.SelectedIndex;
            if (index < 0)
                return;

            bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);
            if (reStart)
                CF4xxxDevice.hps_continueCaptureStop(deviceHandle);

            CF4xxxDevice.hps_setEncoderWorkingMode(deviceHandle, (Confocal_EncoderWorkingMode_t)index);

            if (reStart)
                CF4xxxDevice.hps_continueCaptureStart(deviceHandle);
        }

        private void btn_clear_trigger_count_Click(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;

            CF4xxxDevice.hps_clearEncodersCount(deviceHandle);
            lb_trigger0.Text = "0";
            lb_trigger1.Text = "0";
            lb_trigger2.Text = "0";
            triggerCount[0] = 0;
            triggerCount[1] = 0;
            triggerCount[2] = 0;
        }

        private void groupBox8_Enter(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;

            try
            {
                double calThreshold = Convert.ToDouble(tb_cal_threhold.Text);
                double detectThreshold = Convert.ToDouble(tb_signalDetectThrehold.Text);
                int miniPoint = Convert.ToInt32(tb_mini_cal_point.Text);
                byte step = Convert.ToByte(tb_autoSignalDetectStep.Text);
                int signalNumberLimit = Convert.ToInt32(tb_signalNumberLimit.Text);



                CF4xxxDevice.hps_setCalculationThreshold(deviceHandle, channelIndex,calThreshold);
                CF4xxxDevice.hps_setSignalDetectThresholdCoef(deviceHandle, channelIndex, detectThreshold);
                CF4xxxDevice.hps_setMiniCalPointsLimit(deviceHandle, channelIndex, miniPoint);
                CF4xxxDevice.hps_setSignalSearchAccurateStep(deviceHandle, channelIndex, step);
                CF4xxxDevice.hps_setDetectSignalNumber(deviceHandle, channelIndex, signalNumberLimit);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void trigger_pass_en_CheckedChanged(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;

            if(trigger_pass_en.Checked)
                CF4xxxDevice.hps_setTriggerPassDebug(deviceHandle,true);
        }

        private void trigger_pass_off_CheckedChanged(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;

            if (trigger_pass_off.Checked)
                CF4xxxDevice.hps_setTriggerPassDebug(deviceHandle,false);
        }

        private void btn_clear_trigger_pass_flag_Click(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;

            CF4xxxDevice.hps_clearTriggerPassFlag(deviceHandle);
            lb_isTriggerPass.Text = "0";
            isTriggerPass = false;

        }

        private void rb_sc_abs_en_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_sc_abs_en.Checked)
                CF4xxxDevice.hps_setAbsMode(deviceHandle, channelIndex, true);
        }

        private void rb_sc_abs_off_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_sc_abs_off.Checked)
                CF4xxxDevice.hps_setAbsMode(deviceHandle, channelIndex, false);
        }

        private void rb_mc_abs_en_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_mc_abs_en.Checked)
                CF4xxxDevice.hps_doubleChannelABSMode(deviceHandle,0,true);
        }

        private void rb_mc_abs_off_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_mc_abs_off.Checked)
                CF4xxxDevice.hps_doubleChannelABSMode(deviceHandle, 0, false);
        }

        private void rb_mc_reverse_en_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_mc_reverse_en.Checked)
                CF4xxxDevice.hps_doubleChannelReversePos(deviceHandle, 0, true);
        }

        private void groupBox19_Enter(object sender, EventArgs e)
        {

        }

        private void rb_mc_reverse_off_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_mc_reverse_off.Checked)
                CF4xxxDevice.hps_doubleChannelReversePos(deviceHandle, 0, false);
        }

        private void bt_setthicknesskparam_Click(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;

            CF4xxxDevice.hps_setThicknessRefractivePara(deviceHandle, cb_k_ch.SelectedIndex, (int)nud_k_index1.Value, (int)nud_k_index2.Value, 
                (float)nud_k_nc.Value, (float)nud_k_nd.Value, (float)nud_k_nf.Value);
        }

        private void rdb_lucency_en_CheckedChanged(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;

            bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);

            if (reStart)
                CF4xxxDevice.hps_continueCaptureStop(deviceHandle);

         

            if (rdb_lucency_en.Checked)
                CF4xxxDevice.hps_doubleChannelALMode(deviceHandle,true);

            if (reStart)
                CF4xxxDevice.hps_continueCaptureStart(deviceHandle);

        }

        private void rdb_lucency_disen_CheckedChanged(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;


            bool reStart = CF4xxxDevice.hps_isCaptureStart(deviceHandle);

            if (reStart)
                CF4xxxDevice.hps_continueCaptureStop(deviceHandle);



            if (rdb_lucency_disen.Checked)
                CF4xxxDevice.hps_doubleChannelALMode(deviceHandle, false);


            if (reStart)
                CF4xxxDevice.hps_continueCaptureStart(deviceHandle);
        }

        private void cb_doubleChannelRSxxxOutput_CheckedChanged(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;

            CF4xxxDevice.hps_setDoubleChannelRSxxxOutput(deviceHandle,cb_doubleChannelRSxxxOutput.Checked);
        }

        private void cb_rsxxx_set_Click(object sender, EventArgs e)
        {

            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;

            COMM_Protocol_Control_Enum_t comm_control;
            COMM_Protocol_Enum_t comm_protocol;
            COMM_BaudRate_Enum_t baudrate;
            COMM_Parity_Enum_t parity;
            COMM_Data_Format_Enum_t format;

            if (cb_rsxxx_rs232.Checked)
            {
                comm_protocol = COMM_Protocol_Enum_t.RS232_COMM;
            }
            else if (cb_rsxxx_rs422.Checked)
            {
                comm_protocol = COMM_Protocol_Enum_t.RS422_COMM;
            }
            else if (cb_rsxxx_rs485.Checked)
            {
                comm_protocol = COMM_Protocol_Enum_t.RS485_COMM;

            }
            else
                return;

            if (cb_rsxxx_hardware.Checked)
                comm_control = COMM_Protocol_Control_Enum_t.Hardware;
            else
                comm_control = COMM_Protocol_Control_Enum_t.Software;

            if (cb_rsxxx_hex.Checked)
                format = COMM_Data_Format_Enum_t.Hexadecimal;
            else
                format = COMM_Data_Format_Enum_t.ASCII;


            switch (cb_rsxxx_baudrate.Text)
            {
                case "9600":
                    baudrate = COMM_BaudRate_Enum_t.BaudRate_9600;
                    break;
                case "19200":
                    baudrate = COMM_BaudRate_Enum_t.BaudRate_19200;
                    break;
                case "38400":
                    baudrate = COMM_BaudRate_Enum_t.BaudRate_38400;
                    break;
                case "57600":
                    baudrate = COMM_BaudRate_Enum_t.BaudRate_57600;
                    break;
                case "115200":
                    baudrate = COMM_BaudRate_Enum_t.BaudRate_115200;
                    break;
                case "230400":
                    baudrate = COMM_BaudRate_Enum_t.BaudRate_230400;
                    break;
                case "406800":
                    baudrate = COMM_BaudRate_Enum_t.BaudRate_460800;
                    break;
                case "921600":
                    baudrate = COMM_BaudRate_Enum_t.BaudRate_921600;
                    break;
                default:
                    return;
            }

            switch (cb_rsxxx_parity.Text)
            {
                case "Even":
                    parity = COMM_Parity_Enum_t.Even;
                    break;

                case "Odd":
                    parity = COMM_Parity_Enum_t.Odd;
                    break;

                case "Mark":
                    parity = COMM_Parity_Enum_t.Mark;
                    break;

                case "Space":
                    parity = COMM_Parity_Enum_t.Space;
                    break;

                case "None":
                    parity = COMM_Parity_Enum_t.None;
                    break;

                default:               
                    return;
            }


            CF4xxxDevice.hps_setRSxxxProtocol(deviceHandle, comm_control, comm_protocol);
            CF4xxxDevice.hps_setRSxxxCommunicationPara(deviceHandle,baudrate, parity);
            CF4xxxDevice.hps_setRSxxxDataFormat(deviceHandle, format);





        }

        private void btn_signalSmooth_Click(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;

            CF4xxxDevice.hps_setSignalSmoothLen(deviceHandle, (int)nud_signalSmoothLen.Value);
        }

        private void rb_enable_autoSignalDetect_CheckedChanged(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;

            if (rb_enable_autoSignalDetect.Checked)
            {
                tb_autoSignalDetectStep.Enabled = true;
                CF4xxxDevice.hps_setAutoSignalDetect(deviceHandle, channelIndex, true);
            }
            else
            {
                tb_autoSignalDetectStep.Enabled = false;
                CF4xxxDevice.hps_setAutoSignalDetect(deviceHandle, channelIndex, false);
            }
        }

        private void btn_k_set_Click(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;


            int groupIndex = cb_group.SelectedIndex;
            //标定模式，K0为常数项（offset），K1为一次项系数，K2为二次项系数
            //写入点数为1时，为offset补偿
            //写入点数为2时，拟合直线
            //写入点数为3或以上时，拟合二元多次曲线
            if (cb_calibrationmode.SelectedIndex == 0)
            {
                double[] coef = new double[3];   
                CF4xxxDevice.hps_doDoubleChannelThicknessCal(deviceHandle, groupIndex, coef);
                nud_k0.Value = (decimal)coef[0];
                nud_k1.Value = (decimal)coef[1];
                nud_k2.Value = (decimal)coef[2];
            }
            //写入具体指定系数
            else
            {
                
                double[] coef = new double[3];
                coef[0] = (double)nud_k0.Value;
                coef[1] = (double)nud_k1.Value;
                coef[2] = (double)nud_k2.Value;
                CF4xxxDevice.hps_setDoubleChannelThicknessK(deviceHandle, groupIndex, coef);
            }

        }


        private void bt_reset_Click(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;

            int groupIndex = cb_group.SelectedIndex;
           //复位双头测厚校准系数（0，1，0）,同时清空写入的点数
            CF4xxxDevice.hps_clearDoubleChannelThicknessSamplePoint(deviceHandle,groupIndex);
            nud_k0.Value = 0;
            nud_k1.Value = 1;
            nud_k2.Value = 0;

            lb_calibthicknesspointnum.Text = CF4xxxDevice.hps_getDoubleChannelThicknessSamplePoint(deviceHandle, groupIndex).ToString();


        }

        private void btn_addPoint_Click(object sender, EventArgs e)
        {
            if (!CF4xxxDevice.hps_isOpen(deviceHandle))
                return;
            int groupIndex = cb_group.SelectedIndex;
            //写入真实厚度值，同时记录测量值
            CF4xxxDevice.hps_setDoubleChannelThicknessSamplePoint(deviceHandle,groupIndex, (float)nud_calibthickness.Value);
            //更新当前写入点数
            lb_calibthicknesspointnum.Text= CF4xxxDevice.hps_getDoubleChannelThicknessSamplePoint(deviceHandle,groupIndex).ToString();

        }
    }
}
