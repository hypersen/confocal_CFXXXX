﻿namespace CF4xxxDemo
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.lb_signalNumber = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.cb_doubleChannelRSxxxOutput = new System.Windows.Forms.CheckBox();
            this.lb_cf2000port = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.lb_cf2000mac = new System.Windows.Forms.Label();
            this.lb_cf2000ip = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.btn_clear_trigger_pass_flag = new System.Windows.Forms.Button();
            this.lb_isTriggerPass = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.lb_distanceNumber = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.lb_dis4 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.lb_dis3 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.lb_dis2 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.lb_dis1 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.btn_clear_trigger_count = new System.Windows.Forms.Button();
            this.lb_trigger2 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.lb_trigger1 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.lb_trigger0 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.btn_clear_cache = new System.Windows.Forms.Button();
            this.rb_cache_info = new System.Windows.Forms.RichTextBox();
            this.btn_get_cache_info = new System.Windows.Forms.Button();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.lb_saturation2 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.cb_doubleChannel = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.cb_dark_all_ch = new System.Windows.Forms.CheckBox();
            this.lb_controler_SN = new System.Windows.Forms.Label();
            this.cb_channelSelect = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.gb_control = new System.Windows.Forms.GroupBox();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.nud_k2 = new System.Windows.Forms.NumericUpDown();
            this.label105 = new System.Windows.Forms.Label();
            this.nud_k1 = new System.Windows.Forms.NumericUpDown();
            this.cb_group = new System.Windows.Forms.ComboBox();
            this.label104 = new System.Windows.Forms.Label();
            this.btn_k_set = new System.Windows.Forms.Button();
            this.label100 = new System.Windows.Forms.Label();
            this.nud_k0 = new System.Windows.Forms.NumericUpDown();
            this.label103 = new System.Windows.Forms.Label();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.cb_rsxxx_parity = new System.Windows.Forms.ComboBox();
            this.cb_rsxxx_baudrate = new System.Windows.Forms.ComboBox();
            this.cb_rsxxx_set = new System.Windows.Forms.Button();
            this.label93 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.cb_rsxxx_ascii = new System.Windows.Forms.RadioButton();
            this.cb_rsxxx_hex = new System.Windows.Forms.RadioButton();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.cb_rsxxx_hardware = new System.Windows.Forms.RadioButton();
            this.cb_rsxxx_software = new System.Windows.Forms.RadioButton();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.cb_rsxxx_rs232 = new System.Windows.Forms.RadioButton();
            this.cb_rsxxx_rs485 = new System.Windows.Forms.RadioButton();
            this.cb_rsxxx_rs422 = new System.Windows.Forms.RadioButton();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.rdb_lucency_en = new System.Windows.Forms.RadioButton();
            this.rdb_lucency_disen = new System.Windows.Forms.RadioButton();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.nud_k_nf = new System.Windows.Forms.NumericUpDown();
            this.label91 = new System.Windows.Forms.Label();
            this.nud_k_nd = new System.Windows.Forms.NumericUpDown();
            this.label89 = new System.Windows.Forms.Label();
            this.nud_k_nc = new System.Windows.Forms.NumericUpDown();
            this.label87 = new System.Windows.Forms.Label();
            this.nud_k_index2 = new System.Windows.Forms.NumericUpDown();
            this.label86 = new System.Windows.Forms.Label();
            this.nud_k_index1 = new System.Windows.Forms.NumericUpDown();
            this.label83 = new System.Windows.Forms.Label();
            this.bt_setthicknesskparam = new System.Windows.Forms.Button();
            this.label90 = new System.Windows.Forms.Label();
            this.cb_k_ch = new System.Windows.Forms.ComboBox();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.rb_mc_reverse_en = new System.Windows.Forms.RadioButton();
            this.rb_mc_reverse_off = new System.Windows.Forms.RadioButton();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.rb_mc_abs_en = new System.Windows.Forms.RadioButton();
            this.rb_mc_abs_off = new System.Windows.Forms.RadioButton();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.rb_sc_abs_en = new System.Windows.Forms.RadioButton();
            this.rb_sc_abs_off = new System.Windows.Forms.RadioButton();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.trigger_pass_en = new System.Windows.Forms.RadioButton();
            this.trigger_pass_off = new System.Windows.Forms.RadioButton();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.tb_signalNumberLimit = new System.Windows.Forms.TextBox();
            this.label97 = new System.Windows.Forms.Label();
            this.tb_autoSignalDetectStep = new System.Windows.Forms.TextBox();
            this.label96 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.rb_disable_autoSignalDetect = new System.Windows.Forms.RadioButton();
            this.rb_enable_autoSignalDetect = new System.Windows.Forms.RadioButton();
            this.tb_mini_cal_point = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.tb_signalDetectThrehold = new System.Windows.Forms.TextBox();
            this.tb_cal_threhold = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.label68 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.cb_inputport_func2 = new System.Windows.Forms.ComboBox();
            this.cb_inputport_ch_2 = new System.Windows.Forms.ComboBox();
            this.btn_set_input_port = new System.Windows.Forms.Button();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.cb_inputport_func1 = new System.Windows.Forms.ComboBox();
            this.cb_inputport_ch_1 = new System.Windows.Forms.ComboBox();
            this.label78 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.btn_tol_set = new System.Windows.Forms.Button();
            this.label61 = new System.Windows.Forms.Label();
            this.tb_lowerLimitValue = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.tb_upperLimitValue = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.nud_prrgSeg = new System.Windows.Forms.NumericUpDown();
            this.label58 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.cb_OUT_IO_4_Mode = new System.Windows.Forms.ComboBox();
            this.cb_OUT_IO_3_Mode = new System.Windows.Forms.ComboBox();
            this.cb_OUT_IO_2_Mode = new System.Windows.Forms.ComboBox();
            this.cb_OUT_IO_3_FUNC = new System.Windows.Forms.ComboBox();
            this.cb_OUT_IO_2_FUNC = new System.Windows.Forms.ComboBox();
            this.cb_OUT_IO_4_CH = new System.Windows.Forms.ComboBox();
            this.cb_OUT_IO_3_CH = new System.Windows.Forms.ComboBox();
            this.cb_OUT_IO_2_CH = new System.Windows.Forms.ComboBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.btn_IO_OutputSet = new System.Windows.Forms.Button();
            this.label53 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.cb_OUT_IO_1_Mode = new System.Windows.Forms.ComboBox();
            this.cb_OUT_IO_1_FUNC = new System.Windows.Forms.ComboBox();
            this.cb_OUT_IO_1_CH = new System.Windows.Forms.ComboBox();
            this.label42 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.btn_vol_set = new System.Windows.Forms.Button();
            this.rb_vol_output_disen = new System.Windows.Forms.RadioButton();
            this.rb_vol_output_en = new System.Windows.Forms.RadioButton();
            this.label41 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.tb_max_dis = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.tb_min_dis = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.tb_max_vol = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tb_mini_vol = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.btn_ethernetPara = new System.Windows.Forms.Button();
            this.tb_ip = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.nud_controllerport = new System.Windows.Forms.NumericUpDown();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.cb_encoder_working_mode = new System.Windows.Forms.ComboBox();
            this.label65 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.cb_encoder_input = new System.Windows.Forms.ComboBox();
            this.label64 = new System.Windows.Forms.Label();
            this.gb_timing_trigger = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.nud_timingTriggerHZ = new System.Windows.Forms.NumericUpDown();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.gb_encoder_division = new System.Windows.Forms.GroupBox();
            this.btn_encoderDivSet = new System.Windows.Forms.Button();
            this.nud_encoderDivision = new System.Windows.Forms.NumericUpDown();
            this.label28 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btn_trigger_set = new System.Windows.Forms.Button();
            this.cb_syncTriggerOut = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.cb_externTriggerSource = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.cb_encoderTriggerSource = new System.Windows.Forms.ComboBox();
            this.cb_triggerMode = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btn_signalSmooth = new System.Windows.Forms.Button();
            this.nud_signalSmoothLen = new System.Windows.Forms.NumericUpDown();
            this.label92 = new System.Windows.Forms.Label();
            this.tb_offset = new System.Windows.Forms.TextBox();
            this.btn_offset_set = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.btn_signalSet = new System.Windows.Forms.Button();
            this.cb_signalSelect = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.nud_mainFaculIndex = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.rb_mulDis_DIS = new System.Windows.Forms.RadioButton();
            this.rb_mulDis_EN = new System.Windows.Forms.RadioButton();
            this.cb_singleCH_MeasureMode = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.gb_control_para = new System.Windows.Forms.GroupBox();
            this.cb_binningMode = new System.Windows.Forms.ComboBox();
            this.label63 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.rb_trubo_enalbe = new System.Windows.Forms.RadioButton();
            this.rb_trubo_disalbe = new System.Windows.Forms.RadioButton();
            this.cb_frameRateControlMode = new System.Windows.Forms.CheckBox();
            this.btn_setFrameRate = new System.Windows.Forms.Button();
            this.nud_frameRate = new System.Windows.Forms.NumericUpDown();
            this.lb_light = new System.Windows.Forms.Label();
            this.tb_light = new System.Windows.Forms.TrackBar();
            this.rb_manualLight = new System.Windows.Forms.RadioButton();
            this.rb_autoLight = new System.Windows.Forms.RadioButton();
            this.nud_expTime = new System.Windows.Forms.NumericUpDown();
            this.btn_setExpTime = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cb_channe_4_lEnable = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cb_channe_3_lEnable = new System.Windows.Forms.CheckBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cb_channe_2_lEnable = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cb_channe_1_lEnable = new System.Windows.Forms.CheckBox();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.nud_movingAverageFilter = new System.Windows.Forms.NumericUpDown();
            this.btn_setMobingAverageFilter = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.nud_medianFilter = new System.Windows.Forms.NumericUpDown();
            this.btn_setMedianFilter = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.lb_frameRate = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_saveConfig = new System.Windows.Forms.Button();
            this.btn_singleShot = new System.Windows.Forms.Button();
            this.gb_connectDevice = new System.Windows.Forms.GroupBox();
            this.rb_cf1000 = new System.Windows.Forms.RadioButton();
            this.button2 = new System.Windows.Forms.Button();
            this.btn_scan_device = new System.Windows.Forms.Button();
            this.rb_cf2000 = new System.Windows.Forms.RadioButton();
            this.rb_cf4000 = new System.Windows.Forms.RadioButton();
            this.btn_open_device = new System.Windows.Forms.Button();
            this.cb_presetExpTime = new System.Windows.Forms.CheckBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btn_dark = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_device_number = new System.Windows.Forms.Label();
            this.lb_controler_version = new System.Windows.Forms.Label();
            this.btn_start_sample = new System.Windows.Forms.Button();
            this.lb_sdk_version = new System.Windows.Forms.Label();
            this.rtb_error_text = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_zero = new System.Windows.Forms.Button();
            this.lb_result = new System.Windows.Forms.Label();
            this.lb_saturation = new System.Windows.Forms.Label();
            this.btn_error_text_clear = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_stop_sample = new System.Windows.Forms.Button();
            this.gb_thickness = new System.Windows.Forms.GroupBox();
            this.lb_calibthicknesspointnum = new System.Windows.Forms.Label();
            this.lb_calibthicknesspoint = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.nud_calibthickness = new System.Windows.Forms.NumericUpDown();
            this.bt_reset = new System.Windows.Forms.Button();
            this.label99 = new System.Windows.Forms.Label();
            this.cb_calibrationmode = new System.Windows.Forms.ComboBox();
            this.btn_addPoint = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.gb_control.SuspendLayout();
            this.groupBox26.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_k2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_k1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_k0)).BeginInit();
            this.groupBox22.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_k_nf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_k_nd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_k_nc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_k_index2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_k_index1)).BeginInit();
            this.groupBox19.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_prrgSeg)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_controllerport)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.gb_timing_trigger.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_timingTriggerHZ)).BeginInit();
            this.gb_encoder_division.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_encoderDivision)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_signalSmoothLen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_mainFaculIndex)).BeginInit();
            this.gb_control_para.SuspendLayout();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_frameRate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_light)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_expTime)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_movingAverageFilter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_medianFilter)).BeginInit();
            this.gb_connectDevice.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.gb_thickness.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_calibthickness)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.lb_signalNumber);
            this.panel1.Controls.Add(this.label98);
            this.panel1.Controls.Add(this.cb_doubleChannelRSxxxOutput);
            this.panel1.Controls.Add(this.lb_cf2000port);
            this.panel1.Controls.Add(this.label84);
            this.panel1.Controls.Add(this.label85);
            this.panel1.Controls.Add(this.lb_cf2000mac);
            this.panel1.Controls.Add(this.lb_cf2000ip);
            this.panel1.Controls.Add(this.label88);
            this.panel1.Controls.Add(this.btn_clear_trigger_pass_flag);
            this.panel1.Controls.Add(this.lb_isTriggerPass);
            this.panel1.Controls.Add(this.label82);
            this.panel1.Controls.Add(this.lb_distanceNumber);
            this.panel1.Controls.Add(this.label31);
            this.panel1.Controls.Add(this.lb_dis4);
            this.panel1.Controls.Add(this.label81);
            this.panel1.Controls.Add(this.lb_dis3);
            this.panel1.Controls.Add(this.label67);
            this.panel1.Controls.Add(this.lb_dis2);
            this.panel1.Controls.Add(this.label70);
            this.panel1.Controls.Add(this.lb_dis1);
            this.panel1.Controls.Add(this.label79);
            this.panel1.Controls.Add(this.btn_clear_trigger_count);
            this.panel1.Controls.Add(this.lb_trigger2);
            this.panel1.Controls.Add(this.label71);
            this.panel1.Controls.Add(this.lb_trigger1);
            this.panel1.Controls.Add(this.label69);
            this.panel1.Controls.Add(this.lb_trigger0);
            this.panel1.Controls.Add(this.label66);
            this.panel1.Controls.Add(this.btn_clear_cache);
            this.panel1.Controls.Add(this.rb_cache_info);
            this.panel1.Controls.Add(this.btn_get_cache_info);
            this.panel1.Controls.Add(this.chart2);
            this.panel1.Controls.Add(this.lb_saturation2);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.cb_doubleChannel);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.cb_dark_all_ch);
            this.panel1.Controls.Add(this.lb_controler_SN);
            this.panel1.Controls.Add(this.cb_channelSelect);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.gb_control);
            this.panel1.Controls.Add(this.lb_frameRate);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.btn_saveConfig);
            this.panel1.Controls.Add(this.btn_singleShot);
            this.panel1.Controls.Add(this.gb_connectDevice);
            this.panel1.Controls.Add(this.cb_presetExpTime);
            this.panel1.Controls.Add(this.chart1);
            this.panel1.Controls.Add(this.btn_dark);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lb_device_number);
            this.panel1.Controls.Add(this.lb_controler_version);
            this.panel1.Controls.Add(this.btn_start_sample);
            this.panel1.Controls.Add(this.lb_sdk_version);
            this.panel1.Controls.Add(this.rtb_error_text);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.btn_zero);
            this.panel1.Controls.Add(this.lb_result);
            this.panel1.Controls.Add(this.lb_saturation);
            this.panel1.Controls.Add(this.btn_error_text_clear);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.btn_stop_sample);
            this.panel1.Location = new System.Drawing.Point(12, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1375, 646);
            this.panel1.TabIndex = 25;
            // 
            // lb_signalNumber
            // 
            this.lb_signalNumber.AutoSize = true;
            this.lb_signalNumber.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_signalNumber.Location = new System.Drawing.Point(1121, 14);
            this.lb_signalNumber.Name = "lb_signalNumber";
            this.lb_signalNumber.Size = new System.Drawing.Size(16, 16);
            this.lb_signalNumber.TabIndex = 84;
            this.lb_signalNumber.Text = "0";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label98.Location = new System.Drawing.Point(1035, 15);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(80, 16);
            this.label98.TabIndex = 83;
            this.label98.Text = "信号个数:";
            // 
            // cb_doubleChannelRSxxxOutput
            // 
            this.cb_doubleChannelRSxxxOutput.AutoSize = true;
            this.cb_doubleChannelRSxxxOutput.Location = new System.Drawing.Point(123, 449);
            this.cb_doubleChannelRSxxxOutput.Name = "cb_doubleChannelRSxxxOutput";
            this.cb_doubleChannelRSxxxOutput.Size = new System.Drawing.Size(150, 16);
            this.cb_doubleChannelRSxxxOutput.TabIndex = 82;
            this.cb_doubleChannelRSxxxOutput.Text = "双头模式RSxxx输出数据";
            this.cb_doubleChannelRSxxxOutput.UseVisualStyleBackColor = true;
            this.cb_doubleChannelRSxxxOutput.CheckedChanged += new System.EventHandler(this.cb_doubleChannelRSxxxOutput_CheckedChanged);
            // 
            // lb_cf2000port
            // 
            this.lb_cf2000port.AutoSize = true;
            this.lb_cf2000port.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_cf2000port.Location = new System.Drawing.Point(146, 209);
            this.lb_cf2000port.Name = "lb_cf2000port";
            this.lb_cf2000port.Size = new System.Drawing.Size(19, 19);
            this.lb_cf2000port.TabIndex = 81;
            this.lb_cf2000port.Text = " ";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label84.Location = new System.Drawing.Point(17, 209);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(127, 19);
            this.label84.TabIndex = 80;
            this.label84.Text = "CF2000 端口:";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label85.Location = new System.Drawing.Point(17, 251);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(119, 19);
            this.label85.TabIndex = 76;
            this.label85.Text = "CF2000 MAC:";
            // 
            // lb_cf2000mac
            // 
            this.lb_cf2000mac.AutoSize = true;
            this.lb_cf2000mac.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_cf2000mac.Location = new System.Drawing.Point(145, 252);
            this.lb_cf2000mac.Name = "lb_cf2000mac";
            this.lb_cf2000mac.Size = new System.Drawing.Size(19, 19);
            this.lb_cf2000mac.TabIndex = 77;
            this.lb_cf2000mac.Text = " ";
            // 
            // lb_cf2000ip
            // 
            this.lb_cf2000ip.AutoSize = true;
            this.lb_cf2000ip.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_cf2000ip.Location = new System.Drawing.Point(146, 170);
            this.lb_cf2000ip.Name = "lb_cf2000ip";
            this.lb_cf2000ip.Size = new System.Drawing.Size(19, 19);
            this.lb_cf2000ip.TabIndex = 79;
            this.lb_cf2000ip.Text = " ";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label88.Location = new System.Drawing.Point(15, 170);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(109, 19);
            this.label88.TabIndex = 78;
            this.label88.Text = "CF2000 IP:";
            // 
            // btn_clear_trigger_pass_flag
            // 
            this.btn_clear_trigger_pass_flag.Location = new System.Drawing.Point(1070, 308);
            this.btn_clear_trigger_pass_flag.Name = "btn_clear_trigger_pass_flag";
            this.btn_clear_trigger_pass_flag.Size = new System.Drawing.Size(51, 22);
            this.btn_clear_trigger_pass_flag.TabIndex = 75;
            this.btn_clear_trigger_pass_flag.Text = "清除";
            this.btn_clear_trigger_pass_flag.UseVisualStyleBackColor = true;
            this.btn_clear_trigger_pass_flag.Click += new System.EventHandler(this.btn_clear_trigger_pass_flag_Click);
            // 
            // lb_isTriggerPass
            // 
            this.lb_isTriggerPass.AutoSize = true;
            this.lb_isTriggerPass.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_isTriggerPass.Location = new System.Drawing.Point(1042, 310);
            this.lb_isTriggerPass.Name = "lb_isTriggerPass";
            this.lb_isTriggerPass.Size = new System.Drawing.Size(16, 16);
            this.lb_isTriggerPass.TabIndex = 74;
            this.lb_isTriggerPass.Text = "0";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label82.Location = new System.Drawing.Point(916, 310);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(120, 16);
            this.label82.TabIndex = 73;
            this.label82.Text = "Trigger pass :";
            // 
            // lb_distanceNumber
            // 
            this.lb_distanceNumber.AutoSize = true;
            this.lb_distanceNumber.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_distanceNumber.Location = new System.Drawing.Point(637, 599);
            this.lb_distanceNumber.Name = "lb_distanceNumber";
            this.lb_distanceNumber.Size = new System.Drawing.Size(11, 12);
            this.lb_distanceNumber.TabIndex = 72;
            this.lb_distanceNumber.Text = "0";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label31.Location = new System.Drawing.Point(584, 599);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(59, 12);
            this.label31.TabIndex = 71;
            this.label31.Text = "波峰个数:";
            // 
            // lb_dis4
            // 
            this.lb_dis4.AutoSize = true;
            this.lb_dis4.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_dis4.Location = new System.Drawing.Point(1171, 599);
            this.lb_dis4.Name = "lb_dis4";
            this.lb_dis4.Size = new System.Drawing.Size(11, 12);
            this.lb_dis4.TabIndex = 70;
            this.lb_dis4.Text = "0";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label81.Location = new System.Drawing.Point(1127, 599);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(41, 12);
            this.label81.TabIndex = 69;
            this.label81.Text = "距离4:";
            // 
            // lb_dis3
            // 
            this.lb_dis3.AutoSize = true;
            this.lb_dis3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_dis3.Location = new System.Drawing.Point(1038, 599);
            this.lb_dis3.Name = "lb_dis3";
            this.lb_dis3.Size = new System.Drawing.Size(11, 12);
            this.lb_dis3.TabIndex = 68;
            this.lb_dis3.Text = "0";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label67.Location = new System.Drawing.Point(995, 599);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(41, 12);
            this.label67.TabIndex = 67;
            this.label67.Text = "距离3:";
            // 
            // lb_dis2
            // 
            this.lb_dis2.AutoSize = true;
            this.lb_dis2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_dis2.Location = new System.Drawing.Point(906, 599);
            this.lb_dis2.Name = "lb_dis2";
            this.lb_dis2.Size = new System.Drawing.Size(11, 12);
            this.lb_dis2.TabIndex = 66;
            this.lb_dis2.Text = "0";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label70.Location = new System.Drawing.Point(863, 599);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(41, 12);
            this.label70.TabIndex = 65;
            this.label70.Text = "距离2:";
            // 
            // lb_dis1
            // 
            this.lb_dis1.AutoSize = true;
            this.lb_dis1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_dis1.Location = new System.Drawing.Point(774, 599);
            this.lb_dis1.Name = "lb_dis1";
            this.lb_dis1.Size = new System.Drawing.Size(11, 12);
            this.lb_dis1.TabIndex = 64;
            this.lb_dis1.Text = "0";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label79.Location = new System.Drawing.Point(731, 599);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(41, 12);
            this.label79.TabIndex = 63;
            this.label79.Text = "距离1:";
            // 
            // btn_clear_trigger_count
            // 
            this.btn_clear_trigger_count.Location = new System.Drawing.Point(639, 563);
            this.btn_clear_trigger_count.Name = "btn_clear_trigger_count";
            this.btn_clear_trigger_count.Size = new System.Drawing.Size(74, 22);
            this.btn_clear_trigger_count.TabIndex = 62;
            this.btn_clear_trigger_count.Text = "清除计数";
            this.btn_clear_trigger_count.UseVisualStyleBackColor = true;
            this.btn_clear_trigger_count.Click += new System.EventHandler(this.btn_clear_trigger_count_Click);
            // 
            // lb_trigger2
            // 
            this.lb_trigger2.AutoSize = true;
            this.lb_trigger2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_trigger2.Location = new System.Drawing.Point(1148, 568);
            this.lb_trigger2.Name = "lb_trigger2";
            this.lb_trigger2.Size = new System.Drawing.Size(11, 12);
            this.lb_trigger2.TabIndex = 61;
            this.lb_trigger2.Text = "0";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label71.Location = new System.Drawing.Point(1081, 568);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(65, 12);
            this.label71.TabIndex = 60;
            this.label71.Text = "触发计数3:";
            // 
            // lb_trigger1
            // 
            this.lb_trigger1.AutoSize = true;
            this.lb_trigger1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_trigger1.Location = new System.Drawing.Point(970, 568);
            this.lb_trigger1.Name = "lb_trigger1";
            this.lb_trigger1.Size = new System.Drawing.Size(11, 12);
            this.lb_trigger1.TabIndex = 59;
            this.lb_trigger1.Text = "0";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label69.Location = new System.Drawing.Point(904, 568);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(65, 12);
            this.label69.TabIndex = 58;
            this.label69.Text = "触发计数2:";
            // 
            // lb_trigger0
            // 
            this.lb_trigger0.AutoSize = true;
            this.lb_trigger0.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_trigger0.Location = new System.Drawing.Point(803, 568);
            this.lb_trigger0.Name = "lb_trigger0";
            this.lb_trigger0.Size = new System.Drawing.Size(11, 12);
            this.lb_trigger0.TabIndex = 57;
            this.lb_trigger0.Text = "0";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label66.Location = new System.Drawing.Point(737, 568);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(65, 12);
            this.label66.TabIndex = 56;
            this.label66.Text = "触发计数1:";
            // 
            // btn_clear_cache
            // 
            this.btn_clear_cache.Location = new System.Drawing.Point(289, 473);
            this.btn_clear_cache.Name = "btn_clear_cache";
            this.btn_clear_cache.Size = new System.Drawing.Size(105, 33);
            this.btn_clear_cache.TabIndex = 55;
            this.btn_clear_cache.Text = "清除Cache";
            this.btn_clear_cache.UseVisualStyleBackColor = true;
            this.btn_clear_cache.Click += new System.EventHandler(this.btn_clear_cache_Click);
            // 
            // rb_cache_info
            // 
            this.rb_cache_info.Location = new System.Drawing.Point(409, 369);
            this.rb_cache_info.Name = "rb_cache_info";
            this.rb_cache_info.Size = new System.Drawing.Size(286, 136);
            this.rb_cache_info.TabIndex = 54;
            this.rb_cache_info.Text = "";
            // 
            // btn_get_cache_info
            // 
            this.btn_get_cache_info.Location = new System.Drawing.Point(289, 424);
            this.btn_get_cache_info.Name = "btn_get_cache_info";
            this.btn_get_cache_info.Size = new System.Drawing.Size(105, 33);
            this.btn_get_cache_info.TabIndex = 52;
            this.btn_get_cache_info.Text = "获取Cache信息";
            this.btn_get_cache_info.UseVisualStyleBackColor = true;
            this.btn_get_cache_info.Click += new System.EventHandler(this.btn_get_cache_res_count_Click);
            // 
            // chart2
            // 
            this.chart2.AllowDrop = true;
            chartArea1.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart2.Legends.Add(legend1);
            this.chart2.Location = new System.Drawing.Point(723, 338);
            this.chart2.Name = "chart2";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            series1.Legend = "Legend1";
            series1.Name = "Signal";
            this.chart2.Series.Add(series1);
            this.chart2.Size = new System.Drawing.Size(488, 218);
            this.chart2.TabIndex = 51;
            this.chart2.Text = "chart2";
            // 
            // lb_saturation2
            // 
            this.lb_saturation2.AutoSize = true;
            this.lb_saturation2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_saturation2.Location = new System.Drawing.Point(824, 306);
            this.lb_saturation2.Name = "lb_saturation2";
            this.lb_saturation2.Size = new System.Drawing.Size(32, 16);
            this.lb_saturation2.TabIndex = 50;
            this.lb_saturation2.Text = "0 %";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label27.Location = new System.Drawing.Point(732, 307);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(80, 16);
            this.label27.TabIndex = 49;
            this.label27.Text = "信号强度:";
            // 
            // cb_doubleChannel
            // 
            this.cb_doubleChannel.AutoSize = true;
            this.cb_doubleChannel.Enabled = false;
            this.cb_doubleChannel.Location = new System.Drawing.Point(123, 431);
            this.cb_doubleChannel.Name = "cb_doubleChannel";
            this.cb_doubleChannel.Size = new System.Drawing.Size(96, 16);
            this.cb_doubleChannel.TabIndex = 46;
            this.cb_doubleChannel.Text = "双头测厚模式";
            this.cb_doubleChannel.UseVisualStyleBackColor = true;
            this.cb_doubleChannel.CheckedChanged += new System.EventHandler(this.cb_doubleChannel_CheckedChanged);
            this.cb_doubleChannel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.cb_doubleChannel_MouseUp);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(603, 284);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 37);
            this.button1.TabIndex = 45;
            this.button1.Text = "恢复出厂设置";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cb_dark_all_ch
            // 
            this.cb_dark_all_ch.AutoSize = true;
            this.cb_dark_all_ch.Location = new System.Drawing.Point(453, 544);
            this.cb_dark_all_ch.Name = "cb_dark_all_ch";
            this.cb_dark_all_ch.Size = new System.Drawing.Size(72, 16);
            this.cb_dark_all_ch.TabIndex = 44;
            this.cb_dark_all_ch.Text = "所有通道";
            this.cb_dark_all_ch.UseVisualStyleBackColor = true;
            // 
            // lb_controler_SN
            // 
            this.lb_controler_SN.AutoSize = true;
            this.lb_controler_SN.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_controler_SN.Location = new System.Drawing.Point(146, 89);
            this.lb_controler_SN.Name = "lb_controler_SN";
            this.lb_controler_SN.Size = new System.Drawing.Size(19, 19);
            this.lb_controler_SN.TabIndex = 43;
            this.lb_controler_SN.Text = "0";
            // 
            // cb_channelSelect
            // 
            this.cb_channelSelect.FormattingEnabled = true;
            this.cb_channelSelect.Items.AddRange(new object[] {
            "Channel 0",
            "Channel 1",
            "Channel 2",
            "Channel 3"});
            this.cb_channelSelect.Location = new System.Drawing.Point(787, 11);
            this.cb_channelSelect.Name = "cb_channelSelect";
            this.cb_channelSelect.Size = new System.Drawing.Size(99, 20);
            this.cb_channelSelect.TabIndex = 44;
            this.cb_channelSelect.Text = "Channel 0";
            this.cb_channelSelect.SelectedIndexChanged += new System.EventHandler(this.cb_channelSelect_SelectedIndexChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(17, 89);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(133, 19);
            this.label15.TabIndex = 42;
            this.label15.Text = "控制器序列号:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(701, 16);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 16);
            this.label16.TabIndex = 41;
            this.label16.Text = "通道选择";
            // 
            // gb_control
            // 
            this.gb_control.Controls.Add(this.groupBox26);
            this.gb_control.Controls.Add(this.groupBox22);
            this.gb_control.Controls.Add(this.groupBox21);
            this.gb_control.Controls.Add(this.groupBox20);
            this.gb_control.Controls.Add(this.groupBox19);
            this.gb_control.Controls.Add(this.groupBox18);
            this.gb_control.Controls.Add(this.groupBox17);
            this.gb_control.Controls.Add(this.groupBox16);
            this.gb_control.Controls.Add(this.groupBox15);
            this.gb_control.Controls.Add(this.groupBox11);
            this.gb_control.Controls.Add(this.groupBox10);
            this.gb_control.Controls.Add(this.groupBox9);
            this.gb_control.Controls.Add(this.groupBox8);
            this.gb_control.Controls.Add(this.groupBox6);
            this.gb_control.Controls.Add(this.groupBox4);
            this.gb_control.Controls.Add(this.groupBox3);
            this.gb_control.Controls.Add(this.cb_singleCH_MeasureMode);
            this.gb_control.Controls.Add(this.label17);
            this.gb_control.Controls.Add(this.gb_control_para);
            this.gb_control.Controls.Add(this.groupBox2);
            this.gb_control.Controls.Add(this.groupBox1);
            this.gb_control.Enabled = false;
            this.gb_control.Location = new System.Drawing.Point(1217, -10);
            this.gb_control.Name = "gb_control";
            this.gb_control.Size = new System.Drawing.Size(2668, 704);
            this.gb_control.TabIndex = 41;
            this.gb_control.TabStop = false;
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.label99);
            this.groupBox26.Controls.Add(this.cb_calibrationmode);
            this.groupBox26.Controls.Add(this.bt_reset);
            this.groupBox26.Controls.Add(this.gb_thickness);
            this.groupBox26.Controls.Add(this.nud_k2);
            this.groupBox26.Controls.Add(this.label105);
            this.groupBox26.Controls.Add(this.nud_k1);
            this.groupBox26.Controls.Add(this.cb_group);
            this.groupBox26.Controls.Add(this.label104);
            this.groupBox26.Controls.Add(this.btn_k_set);
            this.groupBox26.Controls.Add(this.label100);
            this.groupBox26.Controls.Add(this.nud_k0);
            this.groupBox26.Controls.Add(this.label103);
            this.groupBox26.Location = new System.Drawing.Point(1854, 501);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(436, 203);
            this.groupBox26.TabIndex = 64;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "双头测厚标定";
            // 
            // nud_k2
            // 
            this.nud_k2.DecimalPlaces = 4;
            this.nud_k2.Location = new System.Drawing.Point(341, 74);
            this.nud_k2.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.nud_k2.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.nud_k2.Name = "nud_k2";
            this.nud_k2.Size = new System.Drawing.Size(81, 21);
            this.nud_k2.TabIndex = 61;
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label105.Location = new System.Drawing.Point(311, 74);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(24, 16);
            this.label105.TabIndex = 60;
            this.label105.Text = "K2";
            // 
            // nud_k1
            // 
            this.nud_k1.DecimalPlaces = 4;
            this.nud_k1.Location = new System.Drawing.Point(210, 74);
            this.nud_k1.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.nud_k1.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.nud_k1.Name = "nud_k1";
            this.nud_k1.Size = new System.Drawing.Size(81, 21);
            this.nud_k1.TabIndex = 59;
            // 
            // cb_group
            // 
            this.cb_group.FormattingEnabled = true;
            this.cb_group.Items.AddRange(new object[] {
            "group0",
            "group1"});
            this.cb_group.Location = new System.Drawing.Point(75, 22);
            this.cb_group.Name = "cb_group";
            this.cb_group.Size = new System.Drawing.Size(81, 20);
            this.cb_group.TabIndex = 45;
            this.cb_group.Text = "group0";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label104.Location = new System.Drawing.Point(180, 76);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(24, 16);
            this.label104.TabIndex = 58;
            this.label104.Text = "K1";
            // 
            // btn_k_set
            // 
            this.btn_k_set.Location = new System.Drawing.Point(336, 165);
            this.btn_k_set.Name = "btn_k_set";
            this.btn_k_set.Size = new System.Drawing.Size(75, 23);
            this.btn_k_set.TabIndex = 57;
            this.btn_k_set.Text = "标定";
            this.btn_k_set.UseVisualStyleBackColor = true;
            this.btn_k_set.Click += new System.EventHandler(this.btn_k_set_Click);
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label100.Location = new System.Drawing.Point(21, 25);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(48, 16);
            this.label100.TabIndex = 55;
            this.label100.Text = "Group";
            // 
            // nud_k0
            // 
            this.nud_k0.DecimalPlaces = 4;
            this.nud_k0.Location = new System.Drawing.Point(93, 72);
            this.nud_k0.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.nud_k0.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.nud_k0.Name = "nud_k0";
            this.nud_k0.Size = new System.Drawing.Size(81, 21);
            this.nud_k0.TabIndex = 51;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label103.Location = new System.Drawing.Point(9, 73);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(88, 16);
            this.label103.TabIndex = 49;
            this.label103.Text = "K0(offset)";
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.groupBox25);
            this.groupBox22.Controls.Add(this.groupBox23);
            this.groupBox22.Controls.Add(this.groupBox24);
            this.groupBox22.Location = new System.Drawing.Point(2316, 20);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(346, 322);
            this.groupBox22.TabIndex = 63;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "串口输出配置";
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.cb_rsxxx_parity);
            this.groupBox25.Controls.Add(this.cb_rsxxx_baudrate);
            this.groupBox25.Controls.Add(this.cb_rsxxx_set);
            this.groupBox25.Controls.Add(this.label93);
            this.groupBox25.Controls.Add(this.label95);
            this.groupBox25.Controls.Add(this.cb_rsxxx_ascii);
            this.groupBox25.Controls.Add(this.cb_rsxxx_hex);
            this.groupBox25.Location = new System.Drawing.Point(12, 128);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(306, 171);
            this.groupBox25.TabIndex = 85;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "串口参数";
            // 
            // cb_rsxxx_parity
            // 
            this.cb_rsxxx_parity.FormattingEnabled = true;
            this.cb_rsxxx_parity.Items.AddRange(new object[] {
            "Even",
            "Odd",
            "Mark",
            "Space",
            "None"});
            this.cb_rsxxx_parity.Location = new System.Drawing.Point(115, 104);
            this.cb_rsxxx_parity.Name = "cb_rsxxx_parity";
            this.cb_rsxxx_parity.Size = new System.Drawing.Size(106, 20);
            this.cb_rsxxx_parity.TabIndex = 68;
            this.cb_rsxxx_parity.Text = "None";
            // 
            // cb_rsxxx_baudrate
            // 
            this.cb_rsxxx_baudrate.FormattingEnabled = true;
            this.cb_rsxxx_baudrate.Items.AddRange(new object[] {
            "9600",
            "19200",
            "38400",
            "57600",
            "115200",
            "230400",
            "460800",
            "921600"});
            this.cb_rsxxx_baudrate.Location = new System.Drawing.Point(115, 66);
            this.cb_rsxxx_baudrate.Name = "cb_rsxxx_baudrate";
            this.cb_rsxxx_baudrate.Size = new System.Drawing.Size(106, 20);
            this.cb_rsxxx_baudrate.TabIndex = 46;
            this.cb_rsxxx_baudrate.Text = "115200";
            // 
            // cb_rsxxx_set
            // 
            this.cb_rsxxx_set.Location = new System.Drawing.Point(225, 137);
            this.cb_rsxxx_set.Name = "cb_rsxxx_set";
            this.cb_rsxxx_set.Size = new System.Drawing.Size(75, 23);
            this.cb_rsxxx_set.TabIndex = 67;
            this.cb_rsxxx_set.Text = "设置";
            this.cb_rsxxx_set.UseVisualStyleBackColor = true;
            this.cb_rsxxx_set.Click += new System.EventHandler(this.cb_rsxxx_set_Click);
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(24, 110);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(53, 12);
            this.label93.TabIndex = 65;
            this.label93.Text = "奇偶校验";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(24, 68);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(41, 12);
            this.label95.TabIndex = 62;
            this.label95.Text = "波特率";
            // 
            // cb_rsxxx_ascii
            // 
            this.cb_rsxxx_ascii.AutoSize = true;
            this.cb_rsxxx_ascii.Location = new System.Drawing.Point(115, 36);
            this.cb_rsxxx_ascii.Name = "cb_rsxxx_ascii";
            this.cb_rsxxx_ascii.Size = new System.Drawing.Size(53, 16);
            this.cb_rsxxx_ascii.TabIndex = 18;
            this.cb_rsxxx_ascii.Text = "ASCII";
            this.cb_rsxxx_ascii.UseVisualStyleBackColor = true;
            // 
            // cb_rsxxx_hex
            // 
            this.cb_rsxxx_hex.AutoSize = true;
            this.cb_rsxxx_hex.Checked = true;
            this.cb_rsxxx_hex.Location = new System.Drawing.Point(26, 36);
            this.cb_rsxxx_hex.Name = "cb_rsxxx_hex";
            this.cb_rsxxx_hex.Size = new System.Drawing.Size(41, 16);
            this.cb_rsxxx_hex.TabIndex = 17;
            this.cb_rsxxx_hex.TabStop = true;
            this.cb_rsxxx_hex.Text = "HEX";
            this.cb_rsxxx_hex.UseVisualStyleBackColor = true;
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.cb_rsxxx_hardware);
            this.groupBox23.Controls.Add(this.cb_rsxxx_software);
            this.groupBox23.Location = new System.Drawing.Point(16, 21);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(230, 45);
            this.groupBox23.TabIndex = 83;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "选择";
            // 
            // cb_rsxxx_hardware
            // 
            this.cb_rsxxx_hardware.AutoSize = true;
            this.cb_rsxxx_hardware.Checked = true;
            this.cb_rsxxx_hardware.Location = new System.Drawing.Point(111, 15);
            this.cb_rsxxx_hardware.Name = "cb_rsxxx_hardware";
            this.cb_rsxxx_hardware.Size = new System.Drawing.Size(47, 16);
            this.cb_rsxxx_hardware.TabIndex = 18;
            this.cb_rsxxx_hardware.TabStop = true;
            this.cb_rsxxx_hardware.Text = "硬件";
            this.cb_rsxxx_hardware.UseVisualStyleBackColor = true;
            // 
            // cb_rsxxx_software
            // 
            this.cb_rsxxx_software.AutoSize = true;
            this.cb_rsxxx_software.Location = new System.Drawing.Point(26, 15);
            this.cb_rsxxx_software.Name = "cb_rsxxx_software";
            this.cb_rsxxx_software.Size = new System.Drawing.Size(47, 16);
            this.cb_rsxxx_software.TabIndex = 17;
            this.cb_rsxxx_software.Text = "软件";
            this.cb_rsxxx_software.UseVisualStyleBackColor = true;
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.cb_rsxxx_rs232);
            this.groupBox24.Controls.Add(this.cb_rsxxx_rs485);
            this.groupBox24.Controls.Add(this.cb_rsxxx_rs422);
            this.groupBox24.Location = new System.Drawing.Point(13, 70);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(270, 45);
            this.groupBox24.TabIndex = 84;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "协议";
            // 
            // cb_rsxxx_rs232
            // 
            this.cb_rsxxx_rs232.AutoSize = true;
            this.cb_rsxxx_rs232.Checked = true;
            this.cb_rsxxx_rs232.Location = new System.Drawing.Point(192, 15);
            this.cb_rsxxx_rs232.Name = "cb_rsxxx_rs232";
            this.cb_rsxxx_rs232.Size = new System.Drawing.Size(53, 16);
            this.cb_rsxxx_rs232.TabIndex = 19;
            this.cb_rsxxx_rs232.TabStop = true;
            this.cb_rsxxx_rs232.Text = "RS232";
            this.cb_rsxxx_rs232.UseVisualStyleBackColor = true;
            // 
            // cb_rsxxx_rs485
            // 
            this.cb_rsxxx_rs485.AutoSize = true;
            this.cb_rsxxx_rs485.Checked = true;
            this.cb_rsxxx_rs485.Location = new System.Drawing.Point(114, 15);
            this.cb_rsxxx_rs485.Name = "cb_rsxxx_rs485";
            this.cb_rsxxx_rs485.Size = new System.Drawing.Size(53, 16);
            this.cb_rsxxx_rs485.TabIndex = 18;
            this.cb_rsxxx_rs485.TabStop = true;
            this.cb_rsxxx_rs485.Text = "RS485";
            this.cb_rsxxx_rs485.UseVisualStyleBackColor = true;
            // 
            // cb_rsxxx_rs422
            // 
            this.cb_rsxxx_rs422.AutoSize = true;
            this.cb_rsxxx_rs422.Location = new System.Drawing.Point(26, 15);
            this.cb_rsxxx_rs422.Name = "cb_rsxxx_rs422";
            this.cb_rsxxx_rs422.Size = new System.Drawing.Size(53, 16);
            this.cb_rsxxx_rs422.TabIndex = 17;
            this.cb_rsxxx_rs422.Text = "RS422";
            this.cb_rsxxx_rs422.UseVisualStyleBackColor = true;
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.rdb_lucency_en);
            this.groupBox21.Controls.Add(this.rdb_lucency_disen);
            this.groupBox21.Location = new System.Drawing.Point(687, 556);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(199, 65);
            this.groupBox21.TabIndex = 62;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "双头测厚透明模式模式";
            // 
            // rdb_lucency_en
            // 
            this.rdb_lucency_en.AutoSize = true;
            this.rdb_lucency_en.Location = new System.Drawing.Point(16, 39);
            this.rdb_lucency_en.Name = "rdb_lucency_en";
            this.rdb_lucency_en.Size = new System.Drawing.Size(59, 16);
            this.rdb_lucency_en.TabIndex = 39;
            this.rdb_lucency_en.TabStop = true;
            this.rdb_lucency_en.Text = "Enable";
            this.rdb_lucency_en.UseVisualStyleBackColor = true;
            this.rdb_lucency_en.CheckedChanged += new System.EventHandler(this.rdb_lucency_en_CheckedChanged);
            // 
            // rdb_lucency_disen
            // 
            this.rdb_lucency_disen.AutoSize = true;
            this.rdb_lucency_disen.Location = new System.Drawing.Point(111, 39);
            this.rdb_lucency_disen.Name = "rdb_lucency_disen";
            this.rdb_lucency_disen.Size = new System.Drawing.Size(65, 16);
            this.rdb_lucency_disen.TabIndex = 40;
            this.rdb_lucency_disen.Text = "Disable";
            this.rdb_lucency_disen.UseVisualStyleBackColor = true;
            this.rdb_lucency_disen.CheckedChanged += new System.EventHandler(this.rdb_lucency_disen_CheckedChanged);
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.nud_k_nf);
            this.groupBox20.Controls.Add(this.label91);
            this.groupBox20.Controls.Add(this.nud_k_nd);
            this.groupBox20.Controls.Add(this.label89);
            this.groupBox20.Controls.Add(this.nud_k_nc);
            this.groupBox20.Controls.Add(this.label87);
            this.groupBox20.Controls.Add(this.nud_k_index2);
            this.groupBox20.Controls.Add(this.label86);
            this.groupBox20.Controls.Add(this.nud_k_index1);
            this.groupBox20.Controls.Add(this.label83);
            this.groupBox20.Controls.Add(this.bt_setthicknesskparam);
            this.groupBox20.Controls.Add(this.label90);
            this.groupBox20.Controls.Add(this.cb_k_ch);
            this.groupBox20.Location = new System.Drawing.Point(1445, 497);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(400, 163);
            this.groupBox20.TabIndex = 62;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "厚度折射率参数设定";
            // 
            // nud_k_nf
            // 
            this.nud_k_nf.DecimalPlaces = 6;
            this.nud_k_nf.Location = new System.Drawing.Point(273, 90);
            this.nud_k_nf.Name = "nud_k_nf";
            this.nud_k_nf.Size = new System.Drawing.Size(106, 21);
            this.nud_k_nf.TabIndex = 26;
            this.nud_k_nf.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(215, 93);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(23, 12);
            this.label91.TabIndex = 25;
            this.label91.Text = "Nf:";
            // 
            // nud_k_nd
            // 
            this.nud_k_nd.DecimalPlaces = 6;
            this.nud_k_nd.Location = new System.Drawing.Point(273, 56);
            this.nud_k_nd.Name = "nud_k_nd";
            this.nud_k_nd.Size = new System.Drawing.Size(106, 21);
            this.nud_k_nd.TabIndex = 24;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(215, 59);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(23, 12);
            this.label89.TabIndex = 23;
            this.label89.Text = "Nd:";
            // 
            // nud_k_nc
            // 
            this.nud_k_nc.DecimalPlaces = 6;
            this.nud_k_nc.Location = new System.Drawing.Point(273, 23);
            this.nud_k_nc.Name = "nud_k_nc";
            this.nud_k_nc.Size = new System.Drawing.Size(106, 21);
            this.nud_k_nc.TabIndex = 22;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(215, 26);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(23, 12);
            this.label87.TabIndex = 21;
            this.label87.Text = "Nc:";
            // 
            // nud_k_index2
            // 
            this.nud_k_index2.Location = new System.Drawing.Point(80, 90);
            this.nud_k_index2.Name = "nud_k_index2";
            this.nud_k_index2.Size = new System.Drawing.Size(106, 21);
            this.nud_k_index2.TabIndex = 20;
            this.nud_k_index2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(22, 93);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(47, 12);
            this.label86.TabIndex = 19;
            this.label86.Text = "index2:";
            // 
            // nud_k_index1
            // 
            this.nud_k_index1.Location = new System.Drawing.Point(82, 56);
            this.nud_k_index1.Name = "nud_k_index1";
            this.nud_k_index1.Size = new System.Drawing.Size(106, 21);
            this.nud_k_index1.TabIndex = 18;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(24, 59);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(47, 12);
            this.label83.TabIndex = 17;
            this.label83.Text = "index1:";
            // 
            // bt_setthicknesskparam
            // 
            this.bt_setthicknesskparam.Location = new System.Drawing.Point(304, 128);
            this.bt_setthicknesskparam.Name = "bt_setthicknesskparam";
            this.bt_setthicknesskparam.Size = new System.Drawing.Size(75, 23);
            this.bt_setthicknesskparam.TabIndex = 16;
            this.bt_setthicknesskparam.Text = "设置";
            this.bt_setthicknesskparam.UseVisualStyleBackColor = true;
            this.bt_setthicknesskparam.Click += new System.EventHandler(this.bt_setthicknesskparam_Click);
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(24, 26);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(35, 12);
            this.label90.TabIndex = 16;
            this.label90.Text = "通道:";
            // 
            // cb_k_ch
            // 
            this.cb_k_ch.FormattingEnabled = true;
            this.cb_k_ch.Items.AddRange(new object[] {
            "Channel 1",
            "Channel 2",
            "Channel 3",
            "Channel 4"});
            this.cb_k_ch.Location = new System.Drawing.Point(82, 23);
            this.cb_k_ch.Name = "cb_k_ch";
            this.cb_k_ch.Size = new System.Drawing.Size(106, 20);
            this.cb_k_ch.TabIndex = 12;
            this.cb_k_ch.Text = "Channel 1";
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.rb_mc_reverse_en);
            this.groupBox19.Controls.Add(this.rb_mc_reverse_off);
            this.groupBox19.Location = new System.Drawing.Point(471, 556);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(208, 65);
            this.groupBox19.TabIndex = 61;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "双头测厚reverse模式";
            this.groupBox19.Enter += new System.EventHandler(this.groupBox19_Enter);
            // 
            // rb_mc_reverse_en
            // 
            this.rb_mc_reverse_en.AutoSize = true;
            this.rb_mc_reverse_en.Location = new System.Drawing.Point(16, 39);
            this.rb_mc_reverse_en.Name = "rb_mc_reverse_en";
            this.rb_mc_reverse_en.Size = new System.Drawing.Size(59, 16);
            this.rb_mc_reverse_en.TabIndex = 39;
            this.rb_mc_reverse_en.TabStop = true;
            this.rb_mc_reverse_en.Text = "Enable";
            this.rb_mc_reverse_en.UseVisualStyleBackColor = true;
            this.rb_mc_reverse_en.CheckedChanged += new System.EventHandler(this.rb_mc_reverse_en_CheckedChanged);
            // 
            // rb_mc_reverse_off
            // 
            this.rb_mc_reverse_off.AutoSize = true;
            this.rb_mc_reverse_off.Location = new System.Drawing.Point(111, 39);
            this.rb_mc_reverse_off.Name = "rb_mc_reverse_off";
            this.rb_mc_reverse_off.Size = new System.Drawing.Size(65, 16);
            this.rb_mc_reverse_off.TabIndex = 40;
            this.rb_mc_reverse_off.TabStop = true;
            this.rb_mc_reverse_off.Text = "Disable";
            this.rb_mc_reverse_off.UseVisualStyleBackColor = true;
            this.rb_mc_reverse_off.CheckedChanged += new System.EventHandler(this.rb_mc_reverse_off_CheckedChanged);
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.rb_mc_abs_en);
            this.groupBox18.Controls.Add(this.rb_mc_abs_off);
            this.groupBox18.Location = new System.Drawing.Point(238, 556);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(208, 65);
            this.groupBox18.TabIndex = 60;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "双头测厚ABS模式";
            // 
            // rb_mc_abs_en
            // 
            this.rb_mc_abs_en.AutoSize = true;
            this.rb_mc_abs_en.Location = new System.Drawing.Point(16, 39);
            this.rb_mc_abs_en.Name = "rb_mc_abs_en";
            this.rb_mc_abs_en.Size = new System.Drawing.Size(59, 16);
            this.rb_mc_abs_en.TabIndex = 39;
            this.rb_mc_abs_en.TabStop = true;
            this.rb_mc_abs_en.Text = "Enable";
            this.rb_mc_abs_en.UseVisualStyleBackColor = true;
            this.rb_mc_abs_en.CheckedChanged += new System.EventHandler(this.rb_mc_abs_en_CheckedChanged);
            // 
            // rb_mc_abs_off
            // 
            this.rb_mc_abs_off.AutoSize = true;
            this.rb_mc_abs_off.Location = new System.Drawing.Point(101, 40);
            this.rb_mc_abs_off.Name = "rb_mc_abs_off";
            this.rb_mc_abs_off.Size = new System.Drawing.Size(65, 16);
            this.rb_mc_abs_off.TabIndex = 40;
            this.rb_mc_abs_off.TabStop = true;
            this.rb_mc_abs_off.Text = "Disable";
            this.rb_mc_abs_off.UseVisualStyleBackColor = true;
            this.rb_mc_abs_off.CheckedChanged += new System.EventHandler(this.rb_mc_abs_off_CheckedChanged);
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.rb_sc_abs_en);
            this.groupBox17.Controls.Add(this.rb_sc_abs_off);
            this.groupBox17.Location = new System.Drawing.Point(293, 420);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(172, 103);
            this.groupBox17.TabIndex = 59;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "单传感头ABS模式";
            // 
            // rb_sc_abs_en
            // 
            this.rb_sc_abs_en.AutoSize = true;
            this.rb_sc_abs_en.Location = new System.Drawing.Point(16, 39);
            this.rb_sc_abs_en.Name = "rb_sc_abs_en";
            this.rb_sc_abs_en.Size = new System.Drawing.Size(59, 16);
            this.rb_sc_abs_en.TabIndex = 39;
            this.rb_sc_abs_en.TabStop = true;
            this.rb_sc_abs_en.Text = "Enable";
            this.rb_sc_abs_en.UseVisualStyleBackColor = true;
            this.rb_sc_abs_en.CheckedChanged += new System.EventHandler(this.rb_sc_abs_en_CheckedChanged);
            // 
            // rb_sc_abs_off
            // 
            this.rb_sc_abs_off.AutoSize = true;
            this.rb_sc_abs_off.Location = new System.Drawing.Point(101, 40);
            this.rb_sc_abs_off.Name = "rb_sc_abs_off";
            this.rb_sc_abs_off.Size = new System.Drawing.Size(65, 16);
            this.rb_sc_abs_off.TabIndex = 40;
            this.rb_sc_abs_off.TabStop = true;
            this.rb_sc_abs_off.Text = "Disable";
            this.rb_sc_abs_off.UseVisualStyleBackColor = true;
            this.rb_sc_abs_off.CheckedChanged += new System.EventHandler(this.rb_sc_abs_off_CheckedChanged);
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.trigger_pass_en);
            this.groupBox16.Controls.Add(this.trigger_pass_off);
            this.groupBox16.Location = new System.Drawing.Point(17, 556);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(198, 67);
            this.groupBox16.TabIndex = 58;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Trigger pass debug";
            // 
            // trigger_pass_en
            // 
            this.trigger_pass_en.AutoSize = true;
            this.trigger_pass_en.Location = new System.Drawing.Point(13, 34);
            this.trigger_pass_en.Name = "trigger_pass_en";
            this.trigger_pass_en.Size = new System.Drawing.Size(59, 16);
            this.trigger_pass_en.TabIndex = 37;
            this.trigger_pass_en.TabStop = true;
            this.trigger_pass_en.Text = "Enable";
            this.trigger_pass_en.UseVisualStyleBackColor = true;
            this.trigger_pass_en.CheckedChanged += new System.EventHandler(this.trigger_pass_en_CheckedChanged);
            // 
            // trigger_pass_off
            // 
            this.trigger_pass_off.AutoSize = true;
            this.trigger_pass_off.Location = new System.Drawing.Point(118, 35);
            this.trigger_pass_off.Name = "trigger_pass_off";
            this.trigger_pass_off.Size = new System.Drawing.Size(65, 16);
            this.trigger_pass_off.TabIndex = 38;
            this.trigger_pass_off.TabStop = true;
            this.trigger_pass_off.Text = "Disable";
            this.trigger_pass_off.UseVisualStyleBackColor = true;
            this.trigger_pass_off.CheckedChanged += new System.EventHandler(this.trigger_pass_off_CheckedChanged);
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.tb_signalNumberLimit);
            this.groupBox15.Controls.Add(this.label97);
            this.groupBox15.Controls.Add(this.tb_autoSignalDetectStep);
            this.groupBox15.Controls.Add(this.label96);
            this.groupBox15.Controls.Add(this.label94);
            this.groupBox15.Controls.Add(this.rb_disable_autoSignalDetect);
            this.groupBox15.Controls.Add(this.rb_enable_autoSignalDetect);
            this.groupBox15.Controls.Add(this.tb_mini_cal_point);
            this.groupBox15.Controls.Add(this.label80);
            this.groupBox15.Controls.Add(this.tb_signalDetectThrehold);
            this.groupBox15.Controls.Add(this.tb_cal_threhold);
            this.groupBox15.Controls.Add(this.button5);
            this.groupBox15.Controls.Add(this.label68);
            this.groupBox15.Controls.Add(this.label75);
            this.groupBox15.Font = new System.Drawing.Font("黑体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox15.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox15.Location = new System.Drawing.Point(468, 372);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(417, 183);
            this.groupBox15.TabIndex = 57;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "信号设置";
            // 
            // tb_signalNumberLimit
            // 
            this.tb_signalNumberLimit.Location = new System.Drawing.Point(215, 99);
            this.tb_signalNumberLimit.Name = "tb_signalNumberLimit";
            this.tb_signalNumberLimit.Size = new System.Drawing.Size(79, 21);
            this.tb_signalNumberLimit.TabIndex = 65;
            this.tb_signalNumberLimit.Text = "0";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label97.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label97.Location = new System.Drawing.Point(15, 95);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(140, 14);
            this.label97.TabIndex = 64;
            this.label97.Text = "Signal number limit";
            // 
            // tb_autoSignalDetectStep
            // 
            this.tb_autoSignalDetectStep.Enabled = false;
            this.tb_autoSignalDetectStep.Location = new System.Drawing.Point(215, 149);
            this.tb_autoSignalDetectStep.Name = "tb_autoSignalDetectStep";
            this.tb_autoSignalDetectStep.Size = new System.Drawing.Size(79, 21);
            this.tb_autoSignalDetectStep.TabIndex = 63;
            this.tb_autoSignalDetectStep.Text = "5";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label96.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label96.Location = new System.Drawing.Point(16, 150);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(133, 14);
            this.label96.TabIndex = 62;
            this.label96.Text = "Signal detect step";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("黑体", 10.5F);
            this.label94.Location = new System.Drawing.Point(15, 121);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(133, 14);
            this.label94.TabIndex = 59;
            this.label94.Text = "Auto signal detect";
            // 
            // rb_disable_autoSignalDetect
            // 
            this.rb_disable_autoSignalDetect.AutoSize = true;
            this.rb_disable_autoSignalDetect.Checked = true;
            this.rb_disable_autoSignalDetect.Location = new System.Drawing.Point(301, 123);
            this.rb_disable_autoSignalDetect.Name = "rb_disable_autoSignalDetect";
            this.rb_disable_autoSignalDetect.Size = new System.Drawing.Size(65, 16);
            this.rb_disable_autoSignalDetect.TabIndex = 61;
            this.rb_disable_autoSignalDetect.TabStop = true;
            this.rb_disable_autoSignalDetect.Text = "Disable";
            this.rb_disable_autoSignalDetect.UseVisualStyleBackColor = true;
            // 
            // rb_enable_autoSignalDetect
            // 
            this.rb_enable_autoSignalDetect.AutoSize = true;
            this.rb_enable_autoSignalDetect.Location = new System.Drawing.Point(212, 123);
            this.rb_enable_autoSignalDetect.Name = "rb_enable_autoSignalDetect";
            this.rb_enable_autoSignalDetect.Size = new System.Drawing.Size(59, 16);
            this.rb_enable_autoSignalDetect.TabIndex = 60;
            this.rb_enable_autoSignalDetect.Text = "Enable";
            this.rb_enable_autoSignalDetect.UseVisualStyleBackColor = true;
            this.rb_enable_autoSignalDetect.CheckedChanged += new System.EventHandler(this.rb_enable_autoSignalDetect_CheckedChanged);
            // 
            // tb_mini_cal_point
            // 
            this.tb_mini_cal_point.Location = new System.Drawing.Point(216, 45);
            this.tb_mini_cal_point.Name = "tb_mini_cal_point";
            this.tb_mini_cal_point.Size = new System.Drawing.Size(79, 21);
            this.tb_mini_cal_point.TabIndex = 58;
            this.tb_mini_cal_point.Text = "8";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label80.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label80.Location = new System.Drawing.Point(15, 48);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(147, 14);
            this.label80.TabIndex = 57;
            this.label80.Text = "Mini calculate point";
            // 
            // tb_signalDetectThrehold
            // 
            this.tb_signalDetectThrehold.Location = new System.Drawing.Point(216, 72);
            this.tb_signalDetectThrehold.Name = "tb_signalDetectThrehold";
            this.tb_signalDetectThrehold.Size = new System.Drawing.Size(79, 21);
            this.tb_signalDetectThrehold.TabIndex = 56;
            this.tb_signalDetectThrehold.Text = "3.0";
            // 
            // tb_cal_threhold
            // 
            this.tb_cal_threhold.Location = new System.Drawing.Point(216, 17);
            this.tb_cal_threhold.Name = "tb_cal_threhold";
            this.tb_cal_threhold.Size = new System.Drawing.Size(79, 21);
            this.tb_cal_threhold.TabIndex = 55;
            this.tb_cal_threhold.Text = "0.65";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(330, 143);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(80, 31);
            this.button5.TabIndex = 54;
            this.button5.Text = "Set";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label68.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label68.Location = new System.Drawing.Point(15, 20);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(182, 14);
            this.label68.TabIndex = 24;
            this.label68.Text = "Calculation threhold(0~1)";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label75.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label75.Location = new System.Drawing.Point(15, 72);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(161, 14);
            this.label75.TabIndex = 25;
            this.label75.Text = "Signal detect threhold";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.cb_inputport_func2);
            this.groupBox11.Controls.Add(this.cb_inputport_ch_2);
            this.groupBox11.Controls.Add(this.btn_set_input_port);
            this.groupBox11.Controls.Add(this.label72);
            this.groupBox11.Controls.Add(this.label73);
            this.groupBox11.Controls.Add(this.label74);
            this.groupBox11.Controls.Add(this.label76);
            this.groupBox11.Controls.Add(this.label77);
            this.groupBox11.Controls.Add(this.cb_inputport_func1);
            this.groupBox11.Controls.Add(this.cb_inputport_ch_1);
            this.groupBox11.Controls.Add(this.label78);
            this.groupBox11.Location = new System.Drawing.Point(1447, 305);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(400, 187);
            this.groupBox11.TabIndex = 56;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "IO输入";
            // 
            // cb_inputport_func2
            // 
            this.cb_inputport_func2.FormattingEnabled = true;
            this.cb_inputport_func2.Items.AddRange(new object[] {
            "None",
            "ExtTrigger",
            "ExtTriggerCache",
            "Zero",
            "StartSample",
            "StopSample",
            "SampleToggle",
            "ClearCache"});
            this.cb_inputport_func2.Location = new System.Drawing.Point(203, 108);
            this.cb_inputport_func2.Name = "cb_inputport_func2";
            this.cb_inputport_func2.Size = new System.Drawing.Size(106, 20);
            this.cb_inputport_func2.TabIndex = 41;
            this.cb_inputport_func2.Text = "None";
            // 
            // cb_inputport_ch_2
            // 
            this.cb_inputport_ch_2.FormattingEnabled = true;
            this.cb_inputport_ch_2.Items.AddRange(new object[] {
            "Channel 1",
            "Channel 2",
            "Channel 3",
            "Channel 4"});
            this.cb_inputport_ch_2.Location = new System.Drawing.Point(80, 106);
            this.cb_inputport_ch_2.Name = "cb_inputport_ch_2";
            this.cb_inputport_ch_2.Size = new System.Drawing.Size(106, 20);
            this.cb_inputport_ch_2.TabIndex = 40;
            this.cb_inputport_ch_2.Text = "Channel 1";
            // 
            // btn_set_input_port
            // 
            this.btn_set_input_port.Location = new System.Drawing.Point(289, 145);
            this.btn_set_input_port.Name = "btn_set_input_port";
            this.btn_set_input_port.Size = new System.Drawing.Size(75, 23);
            this.btn_set_input_port.TabIndex = 16;
            this.btn_set_input_port.Text = "设置";
            this.btn_set_input_port.UseVisualStyleBackColor = true;
            this.btn_set_input_port.Click += new System.EventHandler(this.btn_set_input_port_Click);
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(242, 87);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(29, 12);
            this.label72.TabIndex = 24;
            this.label72.Text = "功能";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(117, 87);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(29, 12);
            this.label73.TabIndex = 23;
            this.label73.Text = "通道";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label74.Location = new System.Drawing.Point(21, 110);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(48, 16);
            this.label74.TabIndex = 19;
            this.label74.Text = "IO 2:";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(242, 32);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(29, 12);
            this.label76.TabIndex = 17;
            this.label76.Text = "功能";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(117, 32);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(29, 12);
            this.label77.TabIndex = 16;
            this.label77.Text = "通道";
            // 
            // cb_inputport_func1
            // 
            this.cb_inputport_func1.FormattingEnabled = true;
            this.cb_inputport_func1.Items.AddRange(new object[] {
            "None",
            "ExtTrigger",
            "ExtTriggerCache",
            "Zero",
            "StartSample",
            "StopSample",
            "SampleToggle",
            "ClearCache"});
            this.cb_inputport_func1.Location = new System.Drawing.Point(203, 51);
            this.cb_inputport_func1.Name = "cb_inputport_func1";
            this.cb_inputport_func1.Size = new System.Drawing.Size(106, 20);
            this.cb_inputport_func1.TabIndex = 13;
            this.cb_inputport_func1.Text = "None";
            // 
            // cb_inputport_ch_1
            // 
            this.cb_inputport_ch_1.FormattingEnabled = true;
            this.cb_inputport_ch_1.Items.AddRange(new object[] {
            "Channel 1",
            "Channel 2",
            "Channel 3",
            "Channel 4"});
            this.cb_inputport_ch_1.Location = new System.Drawing.Point(80, 52);
            this.cb_inputport_ch_1.Name = "cb_inputport_ch_1";
            this.cb_inputport_ch_1.Size = new System.Drawing.Size(106, 20);
            this.cb_inputport_ch_1.TabIndex = 12;
            this.cb_inputport_ch_1.Text = "Channel 1";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label78.Location = new System.Drawing.Point(21, 55);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(48, 16);
            this.label78.TabIndex = 11;
            this.label78.Text = "IO 1:";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.btn_tol_set);
            this.groupBox10.Controls.Add(this.label61);
            this.groupBox10.Controls.Add(this.tb_lowerLimitValue);
            this.groupBox10.Controls.Add(this.label62);
            this.groupBox10.Controls.Add(this.label60);
            this.groupBox10.Controls.Add(this.tb_upperLimitValue);
            this.groupBox10.Controls.Add(this.label59);
            this.groupBox10.Controls.Add(this.nud_prrgSeg);
            this.groupBox10.Controls.Add(this.label58);
            this.groupBox10.Location = new System.Drawing.Point(1854, 305);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(430, 187);
            this.groupBox10.TabIndex = 55;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "公差设置";
            // 
            // btn_tol_set
            // 
            this.btn_tol_set.Location = new System.Drawing.Point(340, 149);
            this.btn_tol_set.Name = "btn_tol_set";
            this.btn_tol_set.Size = new System.Drawing.Size(75, 23);
            this.btn_tol_set.TabIndex = 57;
            this.btn_tol_set.Text = "设置";
            this.btn_tol_set.UseVisualStyleBackColor = true;
            this.btn_tol_set.Click += new System.EventHandler(this.btn_tol_set_Click);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(312, 126);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(17, 12);
            this.label61.TabIndex = 54;
            this.label61.Text = "mm";
            // 
            // tb_lowerLimitValue
            // 
            this.tb_lowerLimitValue.Location = new System.Drawing.Point(176, 117);
            this.tb_lowerLimitValue.Name = "tb_lowerLimitValue";
            this.tb_lowerLimitValue.Size = new System.Drawing.Size(115, 21);
            this.tb_lowerLimitValue.TabIndex = 56;
            this.tb_lowerLimitValue.Text = "0";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label62.Location = new System.Drawing.Point(21, 116);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(152, 16);
            this.label62.TabIndex = 55;
            this.label62.Text = "Lower limit value:";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(312, 82);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(17, 12);
            this.label60.TabIndex = 16;
            this.label60.Text = "mm";
            // 
            // tb_upperLimitValue
            // 
            this.tb_upperLimitValue.Location = new System.Drawing.Point(177, 73);
            this.tb_upperLimitValue.Name = "tb_upperLimitValue";
            this.tb_upperLimitValue.Size = new System.Drawing.Size(115, 21);
            this.tb_upperLimitValue.TabIndex = 53;
            this.tb_upperLimitValue.Text = "0";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label59.Location = new System.Drawing.Point(21, 72);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(152, 16);
            this.label59.TabIndex = 52;
            this.label59.Text = "Upper limit value:";
            // 
            // nud_prrgSeg
            // 
            this.nud_prrgSeg.Location = new System.Drawing.Point(174, 32);
            this.nud_prrgSeg.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.nud_prrgSeg.Name = "nud_prrgSeg";
            this.nud_prrgSeg.Size = new System.Drawing.Size(99, 21);
            this.nud_prrgSeg.TabIndex = 51;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label58.Location = new System.Drawing.Point(21, 33);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(136, 16);
            this.label58.TabIndex = 49;
            this.label58.Text = "Program segment:";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.cb_OUT_IO_4_Mode);
            this.groupBox9.Controls.Add(this.cb_OUT_IO_3_Mode);
            this.groupBox9.Controls.Add(this.cb_OUT_IO_2_Mode);
            this.groupBox9.Controls.Add(this.cb_OUT_IO_3_FUNC);
            this.groupBox9.Controls.Add(this.cb_OUT_IO_2_FUNC);
            this.groupBox9.Controls.Add(this.cb_OUT_IO_4_CH);
            this.groupBox9.Controls.Add(this.cb_OUT_IO_3_CH);
            this.groupBox9.Controls.Add(this.cb_OUT_IO_2_CH);
            this.groupBox9.Controls.Add(this.label54);
            this.groupBox9.Controls.Add(this.label55);
            this.groupBox9.Controls.Add(this.label56);
            this.groupBox9.Controls.Add(this.label57);
            this.groupBox9.Controls.Add(this.label50);
            this.groupBox9.Controls.Add(this.label51);
            this.groupBox9.Controls.Add(this.label52);
            this.groupBox9.Controls.Add(this.btn_IO_OutputSet);
            this.groupBox9.Controls.Add(this.label53);
            this.groupBox9.Controls.Add(this.label46);
            this.groupBox9.Controls.Add(this.label47);
            this.groupBox9.Controls.Add(this.label48);
            this.groupBox9.Controls.Add(this.label49);
            this.groupBox9.Controls.Add(this.label45);
            this.groupBox9.Controls.Add(this.label44);
            this.groupBox9.Controls.Add(this.label43);
            this.groupBox9.Controls.Add(this.cb_OUT_IO_1_Mode);
            this.groupBox9.Controls.Add(this.cb_OUT_IO_1_FUNC);
            this.groupBox9.Controls.Add(this.cb_OUT_IO_1_CH);
            this.groupBox9.Controls.Add(this.label42);
            this.groupBox9.Location = new System.Drawing.Point(1445, 15);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(486, 285);
            this.groupBox9.TabIndex = 54;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "IO输出";
            this.groupBox9.Enter += new System.EventHandler(this.groupBox9_Enter);
            // 
            // cb_OUT_IO_4_Mode
            // 
            this.cb_OUT_IO_4_Mode.FormattingEnabled = true;
            this.cb_OUT_IO_4_Mode.Items.AddRange(new object[] {
            "N.O",
            "N.C"});
            this.cb_OUT_IO_4_Mode.Location = new System.Drawing.Point(324, 213);
            this.cb_OUT_IO_4_Mode.Name = "cb_OUT_IO_4_Mode";
            this.cb_OUT_IO_4_Mode.Size = new System.Drawing.Size(106, 20);
            this.cb_OUT_IO_4_Mode.TabIndex = 48;
            this.cb_OUT_IO_4_Mode.Text = "N.O";
            // 
            // cb_OUT_IO_3_Mode
            // 
            this.cb_OUT_IO_3_Mode.FormattingEnabled = true;
            this.cb_OUT_IO_3_Mode.Items.AddRange(new object[] {
            "N.O",
            "N.C"});
            this.cb_OUT_IO_3_Mode.Location = new System.Drawing.Point(324, 165);
            this.cb_OUT_IO_3_Mode.Name = "cb_OUT_IO_3_Mode";
            this.cb_OUT_IO_3_Mode.Size = new System.Drawing.Size(106, 20);
            this.cb_OUT_IO_3_Mode.TabIndex = 47;
            this.cb_OUT_IO_3_Mode.Text = "N.O";
            // 
            // cb_OUT_IO_2_Mode
            // 
            this.cb_OUT_IO_2_Mode.FormattingEnabled = true;
            this.cb_OUT_IO_2_Mode.Items.AddRange(new object[] {
            "N.O",
            "N.C"});
            this.cb_OUT_IO_2_Mode.Location = new System.Drawing.Point(324, 105);
            this.cb_OUT_IO_2_Mode.Name = "cb_OUT_IO_2_Mode";
            this.cb_OUT_IO_2_Mode.Size = new System.Drawing.Size(106, 20);
            this.cb_OUT_IO_2_Mode.TabIndex = 46;
            this.cb_OUT_IO_2_Mode.Text = "N.O";
            // 
            // cb_OUT_IO_3_FUNC
            // 
            this.cb_OUT_IO_3_FUNC.FormattingEnabled = true;
            this.cb_OUT_IO_3_FUNC.Items.AddRange(new object[] {
            "Disable",
            "HI",
            "LO",
            "Disconnect",
            "SIG Weak",
            "SIG SAT",
            "TEMP Error",
            "Fan Error"});
            this.cb_OUT_IO_3_FUNC.Location = new System.Drawing.Point(203, 165);
            this.cb_OUT_IO_3_FUNC.Name = "cb_OUT_IO_3_FUNC";
            this.cb_OUT_IO_3_FUNC.Size = new System.Drawing.Size(106, 20);
            this.cb_OUT_IO_3_FUNC.TabIndex = 44;
            this.cb_OUT_IO_3_FUNC.Text = "Disable";
            // 
            // cb_OUT_IO_2_FUNC
            // 
            this.cb_OUT_IO_2_FUNC.FormattingEnabled = true;
            this.cb_OUT_IO_2_FUNC.Items.AddRange(new object[] {
            "Disable",
            "HI",
            "LO",
            "Disconnect",
            "SIG Weak",
            "SIG SAT",
            "TEMP Error",
            "Fan Error"});
            this.cb_OUT_IO_2_FUNC.Location = new System.Drawing.Point(203, 106);
            this.cb_OUT_IO_2_FUNC.Name = "cb_OUT_IO_2_FUNC";
            this.cb_OUT_IO_2_FUNC.Size = new System.Drawing.Size(106, 20);
            this.cb_OUT_IO_2_FUNC.TabIndex = 43;
            this.cb_OUT_IO_2_FUNC.Text = "Disable";
            // 
            // cb_OUT_IO_4_CH
            // 
            this.cb_OUT_IO_4_CH.FormattingEnabled = true;
            this.cb_OUT_IO_4_CH.Items.AddRange(new object[] {
            "Channel 1",
            "Channel 2",
            "Channel 3",
            "Channel 4"});
            this.cb_OUT_IO_4_CH.Location = new System.Drawing.Point(80, 218);
            this.cb_OUT_IO_4_CH.Name = "cb_OUT_IO_4_CH";
            this.cb_OUT_IO_4_CH.Size = new System.Drawing.Size(106, 20);
            this.cb_OUT_IO_4_CH.TabIndex = 42;
            this.cb_OUT_IO_4_CH.Text = "Channel 1";
            // 
            // cb_OUT_IO_3_CH
            // 
            this.cb_OUT_IO_3_CH.FormattingEnabled = true;
            this.cb_OUT_IO_3_CH.Items.AddRange(new object[] {
            "Channel 1",
            "Channel 2",
            "Channel 3",
            "Channel 4"});
            this.cb_OUT_IO_3_CH.Location = new System.Drawing.Point(80, 165);
            this.cb_OUT_IO_3_CH.Name = "cb_OUT_IO_3_CH";
            this.cb_OUT_IO_3_CH.Size = new System.Drawing.Size(106, 20);
            this.cb_OUT_IO_3_CH.TabIndex = 41;
            this.cb_OUT_IO_3_CH.Text = "Channel 1";
            // 
            // cb_OUT_IO_2_CH
            // 
            this.cb_OUT_IO_2_CH.FormattingEnabled = true;
            this.cb_OUT_IO_2_CH.Items.AddRange(new object[] {
            "Channel 1",
            "Channel 2",
            "Channel 3",
            "Channel 4"});
            this.cb_OUT_IO_2_CH.Location = new System.Drawing.Point(80, 106);
            this.cb_OUT_IO_2_CH.Name = "cb_OUT_IO_2_CH";
            this.cb_OUT_IO_2_CH.Size = new System.Drawing.Size(106, 20);
            this.cb_OUT_IO_2_CH.TabIndex = 40;
            this.cb_OUT_IO_2_CH.Text = "Channel 1";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(362, 195);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(29, 12);
            this.label54.TabIndex = 39;
            this.label54.Text = "模式";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(242, 195);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(29, 12);
            this.label55.TabIndex = 38;
            this.label55.Text = "功能";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(117, 195);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(29, 12);
            this.label56.TabIndex = 37;
            this.label56.Text = "通道";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label57.Location = new System.Drawing.Point(21, 218);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(48, 16);
            this.label57.TabIndex = 33;
            this.label57.Text = "IO 4:";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(362, 142);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(29, 12);
            this.label50.TabIndex = 32;
            this.label50.Text = "模式";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(242, 142);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(29, 12);
            this.label51.TabIndex = 31;
            this.label51.Text = "功能";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(117, 142);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(29, 12);
            this.label52.TabIndex = 30;
            this.label52.Text = "通道";
            // 
            // btn_IO_OutputSet
            // 
            this.btn_IO_OutputSet.Location = new System.Drawing.Point(355, 245);
            this.btn_IO_OutputSet.Name = "btn_IO_OutputSet";
            this.btn_IO_OutputSet.Size = new System.Drawing.Size(75, 23);
            this.btn_IO_OutputSet.TabIndex = 16;
            this.btn_IO_OutputSet.Text = "设置";
            this.btn_IO_OutputSet.UseVisualStyleBackColor = true;
            this.btn_IO_OutputSet.Click += new System.EventHandler(this.btn_IO_OutputSet_Click);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label53.Location = new System.Drawing.Point(21, 165);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(48, 16);
            this.label53.TabIndex = 26;
            this.label53.Text = "IO 3:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(362, 87);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(29, 12);
            this.label46.TabIndex = 25;
            this.label46.Text = "模式";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(242, 87);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(29, 12);
            this.label47.TabIndex = 24;
            this.label47.Text = "功能";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(117, 87);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(29, 12);
            this.label48.TabIndex = 23;
            this.label48.Text = "通道";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label49.Location = new System.Drawing.Point(21, 110);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(48, 16);
            this.label49.TabIndex = 19;
            this.label49.Text = "IO 2:";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(362, 32);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(29, 12);
            this.label45.TabIndex = 18;
            this.label45.Text = "模式";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(242, 32);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(29, 12);
            this.label44.TabIndex = 17;
            this.label44.Text = "功能";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(117, 32);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(29, 12);
            this.label43.TabIndex = 16;
            this.label43.Text = "通道";
            // 
            // cb_OUT_IO_1_Mode
            // 
            this.cb_OUT_IO_1_Mode.FormattingEnabled = true;
            this.cb_OUT_IO_1_Mode.Items.AddRange(new object[] {
            "N.O",
            "N.C"});
            this.cb_OUT_IO_1_Mode.Location = new System.Drawing.Point(324, 51);
            this.cb_OUT_IO_1_Mode.Name = "cb_OUT_IO_1_Mode";
            this.cb_OUT_IO_1_Mode.Size = new System.Drawing.Size(106, 20);
            this.cb_OUT_IO_1_Mode.TabIndex = 14;
            this.cb_OUT_IO_1_Mode.Text = "N.O";
            // 
            // cb_OUT_IO_1_FUNC
            // 
            this.cb_OUT_IO_1_FUNC.FormattingEnabled = true;
            this.cb_OUT_IO_1_FUNC.Items.AddRange(new object[] {
            "Disable",
            "HI",
            "LO",
            "Disconnect",
            "SIG Weak",
            "SIG SAT",
            "TEMP Error",
            "Fan Error"});
            this.cb_OUT_IO_1_FUNC.Location = new System.Drawing.Point(203, 51);
            this.cb_OUT_IO_1_FUNC.Name = "cb_OUT_IO_1_FUNC";
            this.cb_OUT_IO_1_FUNC.Size = new System.Drawing.Size(106, 20);
            this.cb_OUT_IO_1_FUNC.TabIndex = 13;
            this.cb_OUT_IO_1_FUNC.Text = "Disable";
            // 
            // cb_OUT_IO_1_CH
            // 
            this.cb_OUT_IO_1_CH.FormattingEnabled = true;
            this.cb_OUT_IO_1_CH.Items.AddRange(new object[] {
            "Channel 1",
            "Channel 2",
            "Channel 3",
            "Channel 4"});
            this.cb_OUT_IO_1_CH.Location = new System.Drawing.Point(80, 52);
            this.cb_OUT_IO_1_CH.Name = "cb_OUT_IO_1_CH";
            this.cb_OUT_IO_1_CH.Size = new System.Drawing.Size(106, 20);
            this.cb_OUT_IO_1_CH.TabIndex = 12;
            this.cb_OUT_IO_1_CH.Text = "Channel 1";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label42.Location = new System.Drawing.Point(21, 55);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(48, 16);
            this.label42.TabIndex = 11;
            this.label42.Text = "IO 1:";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.btn_vol_set);
            this.groupBox8.Controls.Add(this.rb_vol_output_disen);
            this.groupBox8.Controls.Add(this.rb_vol_output_en);
            this.groupBox8.Controls.Add(this.label41);
            this.groupBox8.Controls.Add(this.label39);
            this.groupBox8.Controls.Add(this.label40);
            this.groupBox8.Controls.Add(this.tb_max_dis);
            this.groupBox8.Controls.Add(this.label37);
            this.groupBox8.Controls.Add(this.label38);
            this.groupBox8.Controls.Add(this.tb_min_dis);
            this.groupBox8.Controls.Add(this.label35);
            this.groupBox8.Controls.Add(this.label36);
            this.groupBox8.Controls.Add(this.tb_max_vol);
            this.groupBox8.Controls.Add(this.label32);
            this.groupBox8.Controls.Add(this.label18);
            this.groupBox8.Controls.Add(this.tb_mini_vol);
            this.groupBox8.Location = new System.Drawing.Point(1950, 20);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(346, 284);
            this.groupBox8.TabIndex = 53;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "模拟量输出";
            this.groupBox8.Enter += new System.EventHandler(this.groupBox8_Enter);
            // 
            // btn_vol_set
            // 
            this.btn_vol_set.Location = new System.Drawing.Point(183, 229);
            this.btn_vol_set.Name = "btn_vol_set";
            this.btn_vol_set.Size = new System.Drawing.Size(75, 23);
            this.btn_vol_set.TabIndex = 15;
            this.btn_vol_set.Text = "设置";
            this.btn_vol_set.UseVisualStyleBackColor = true;
            this.btn_vol_set.Click += new System.EventHandler(this.btn_vol_set_Click);
            // 
            // rb_vol_output_disen
            // 
            this.rb_vol_output_disen.AutoSize = true;
            this.rb_vol_output_disen.Checked = true;
            this.rb_vol_output_disen.Location = new System.Drawing.Point(152, 197);
            this.rb_vol_output_disen.Name = "rb_vol_output_disen";
            this.rb_vol_output_disen.Size = new System.Drawing.Size(47, 16);
            this.rb_vol_output_disen.TabIndex = 14;
            this.rb_vol_output_disen.TabStop = true;
            this.rb_vol_output_disen.Text = "禁用";
            this.rb_vol_output_disen.UseVisualStyleBackColor = true;
            this.rb_vol_output_disen.CheckedChanged += new System.EventHandler(this.rb_vol_output_disen_CheckedChanged);
            // 
            // rb_vol_output_en
            // 
            this.rb_vol_output_en.AutoSize = true;
            this.rb_vol_output_en.Location = new System.Drawing.Point(99, 197);
            this.rb_vol_output_en.Name = "rb_vol_output_en";
            this.rb_vol_output_en.Size = new System.Drawing.Size(47, 16);
            this.rb_vol_output_en.TabIndex = 13;
            this.rb_vol_output_en.Text = "使能";
            this.rb_vol_output_en.UseVisualStyleBackColor = true;
            this.rb_vol_output_en.CheckedChanged += new System.EventHandler(this.rb_vol_output_en_CheckedChanged);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(21, 197);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(65, 12);
            this.label41.TabIndex = 12;
            this.label41.Text = "模拟量输出";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(220, 158);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(17, 12);
            this.label39.TabIndex = 11;
            this.label39.Text = "mm";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(21, 158);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(65, 12);
            this.label40.TabIndex = 10;
            this.label40.Text = "最大测量值";
            // 
            // tb_max_dis
            // 
            this.tb_max_dis.Location = new System.Drawing.Point(99, 155);
            this.tb_max_dis.Name = "tb_max_dis";
            this.tb_max_dis.Size = new System.Drawing.Size(115, 21);
            this.tb_max_dis.TabIndex = 9;
            this.tb_max_dis.Text = "1.5";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(220, 116);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(17, 12);
            this.label37.TabIndex = 8;
            this.label37.Text = "mm";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(21, 116);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(65, 12);
            this.label38.TabIndex = 7;
            this.label38.Text = "最小测量值";
            // 
            // tb_min_dis
            // 
            this.tb_min_dis.Location = new System.Drawing.Point(99, 113);
            this.tb_min_dis.Name = "tb_min_dis";
            this.tb_min_dis.Size = new System.Drawing.Size(115, 21);
            this.tb_min_dis.TabIndex = 6;
            this.tb_min_dis.Text = "-1.5";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(220, 71);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(11, 12);
            this.label35.TabIndex = 5;
            this.label35.Text = "V";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(21, 71);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(53, 12);
            this.label36.TabIndex = 4;
            this.label36.Text = "最大电压";
            // 
            // tb_max_vol
            // 
            this.tb_max_vol.Location = new System.Drawing.Point(99, 68);
            this.tb_max_vol.Name = "tb_max_vol";
            this.tb_max_vol.Size = new System.Drawing.Size(115, 21);
            this.tb_max_vol.TabIndex = 3;
            this.tb_max_vol.Text = "10";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(220, 34);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(11, 12);
            this.label32.TabIndex = 2;
            this.label32.Text = "V";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(21, 34);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 1;
            this.label18.Text = "最小电压";
            // 
            // tb_mini_vol
            // 
            this.tb_mini_vol.Location = new System.Drawing.Point(99, 31);
            this.tb_mini_vol.Name = "tb_mini_vol";
            this.tb_mini_vol.Size = new System.Drawing.Size(115, 21);
            this.tb_mini_vol.TabIndex = 0;
            this.tb_mini_vol.Text = "-10";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.groupBox7);
            this.groupBox6.Location = new System.Drawing.Point(468, 242);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(431, 135);
            this.groupBox6.TabIndex = 52;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "通讯参数(CF2000)";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.btn_ethernetPara);
            this.groupBox7.Controls.Add(this.tb_ip);
            this.groupBox7.Controls.Add(this.label33);
            this.groupBox7.Controls.Add(this.label34);
            this.groupBox7.Controls.Add(this.nud_controllerport);
            this.groupBox7.Font = new System.Drawing.Font("黑体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox7.Location = new System.Drawing.Point(14, 19);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(403, 107);
            this.groupBox7.TabIndex = 29;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Controller Param.";
            // 
            // btn_ethernetPara
            // 
            this.btn_ethernetPara.Location = new System.Drawing.Point(301, 23);
            this.btn_ethernetPara.Name = "btn_ethernetPara";
            this.btn_ethernetPara.Size = new System.Drawing.Size(67, 38);
            this.btn_ethernetPara.TabIndex = 54;
            this.btn_ethernetPara.Text = "Set";
            this.btn_ethernetPara.UseVisualStyleBackColor = true;
            this.btn_ethernetPara.Click += new System.EventHandler(this.btn_ethernetPara_Click);
            // 
            // tb_ip
            // 
            this.tb_ip.Location = new System.Drawing.Point(123, 33);
            this.tb_ip.Name = "tb_ip";
            this.tb_ip.Size = new System.Drawing.Size(143, 21);
            this.tb_ip.TabIndex = 52;
            this.tb_ip.Text = "192.168.0.2";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label33.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label33.Location = new System.Drawing.Point(15, 40);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(91, 14);
            this.label33.TabIndex = 24;
            this.label33.Text = "IP Address :";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label34.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label34.Location = new System.Drawing.Point(15, 65);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(91, 14);
            this.label34.TabIndex = 25;
            this.label34.Text = "Port       :";
            // 
            // nud_controllerport
            // 
            this.nud_controllerport.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.nud_controllerport.Location = new System.Drawing.Point(123, 65);
            this.nud_controllerport.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.nud_controllerport.Name = "nud_controllerport";
            this.nud_controllerport.Size = new System.Drawing.Size(95, 26);
            this.nud_controllerport.TabIndex = 26;
            this.nud_controllerport.Value = new decimal(new int[] {
            8080,
            0,
            0,
            0});
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.groupBox14);
            this.groupBox4.Controls.Add(this.groupBox13);
            this.groupBox4.Controls.Add(this.gb_timing_trigger);
            this.groupBox4.Controls.Add(this.gb_encoder_division);
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.Location = new System.Drawing.Point(892, 20);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(547, 586);
            this.groupBox4.TabIndex = 52;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "触发设置";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.button6);
            this.groupBox14.Controls.Add(this.cb_encoder_working_mode);
            this.groupBox14.Controls.Add(this.label65);
            this.groupBox14.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox14.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox14.Location = new System.Drawing.Point(6, 406);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(535, 66);
            this.groupBox14.TabIndex = 53;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Encoder working mode";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(447, 29);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(67, 26);
            this.button6.TabIndex = 52;
            this.button6.Text = "Set";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // cb_encoder_working_mode
            // 
            this.cb_encoder_working_mode.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cb_encoder_working_mode.FormattingEnabled = true;
            this.cb_encoder_working_mode.Items.AddRange(new object[] {
            "Mode_Three_Signal_End",
            "Mode_Diff_One_Signal_End"});
            this.cb_encoder_working_mode.Location = new System.Drawing.Point(265, 26);
            this.cb_encoder_working_mode.Name = "cb_encoder_working_mode";
            this.cb_encoder_working_mode.Size = new System.Drawing.Size(138, 22);
            this.cb_encoder_working_mode.TabIndex = 22;
            this.cb_encoder_working_mode.Text = "Mode_Three_Signal_End";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label65.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label65.Location = new System.Drawing.Point(19, 29);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(39, 14);
            this.label65.TabIndex = 17;
            this.label65.Text = "Mode";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.button3);
            this.groupBox13.Controls.Add(this.cb_encoder_input);
            this.groupBox13.Controls.Add(this.label64);
            this.groupBox13.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox13.Location = new System.Drawing.Point(6, 333);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(535, 66);
            this.groupBox13.TabIndex = 39;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Encoder input mode";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(447, 29);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(67, 26);
            this.button3.TabIndex = 52;
            this.button3.Text = "Set";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // cb_encoder_input
            // 
            this.cb_encoder_input.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cb_encoder_input.FormattingEnabled = true;
            this.cb_encoder_input.Items.AddRange(new object[] {
            "Mode_1_INC_1",
            "Mode_2_INC_1",
            "Mode_2_INC_2",
            "Mode_2_INC_4"});
            this.cb_encoder_input.Location = new System.Drawing.Point(265, 26);
            this.cb_encoder_input.Name = "cb_encoder_input";
            this.cb_encoder_input.Size = new System.Drawing.Size(138, 22);
            this.cb_encoder_input.TabIndex = 22;
            this.cb_encoder_input.Text = "Mode_1_INC_1";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label64.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label64.Location = new System.Drawing.Point(19, 29);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(39, 14);
            this.label64.TabIndex = 17;
            this.label64.Text = "Mode";
            // 
            // gb_timing_trigger
            // 
            this.gb_timing_trigger.Controls.Add(this.button4);
            this.gb_timing_trigger.Controls.Add(this.nud_timingTriggerHZ);
            this.gb_timing_trigger.Controls.Add(this.label29);
            this.gb_timing_trigger.Controls.Add(this.label30);
            this.gb_timing_trigger.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.gb_timing_trigger.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gb_timing_trigger.Location = new System.Drawing.Point(6, 487);
            this.gb_timing_trigger.Name = "gb_timing_trigger";
            this.gb_timing_trigger.Size = new System.Drawing.Size(535, 83);
            this.gb_timing_trigger.TabIndex = 36;
            this.gb_timing_trigger.TabStop = false;
            this.gb_timing_trigger.Text = "Timing Trigger";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(447, 34);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(67, 26);
            this.button4.TabIndex = 52;
            this.button4.Text = "Set";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // nud_timingTriggerHZ
            // 
            this.nud_timingTriggerHZ.DecimalPlaces = 2;
            this.nud_timingTriggerHZ.Location = new System.Drawing.Point(265, 30);
            this.nud_timingTriggerHZ.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_timingTriggerHZ.Minimum = new decimal(new int[] {
            1526,
            0,
            0,
            131072});
            this.nud_timingTriggerHZ.Name = "nud_timingTriggerHZ";
            this.nud_timingTriggerHZ.Size = new System.Drawing.Size(120, 23);
            this.nud_timingTriggerHZ.TabIndex = 21;
            this.nud_timingTriggerHZ.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label29.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label29.Location = new System.Drawing.Point(391, 34);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(23, 14);
            this.label29.TabIndex = 20;
            this.label29.Text = "Hz";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label30.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label30.Location = new System.Drawing.Point(19, 34);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(87, 14);
            this.label30.TabIndex = 17;
            this.label30.Text = "Frequency:";
            // 
            // gb_encoder_division
            // 
            this.gb_encoder_division.Controls.Add(this.btn_encoderDivSet);
            this.gb_encoder_division.Controls.Add(this.nud_encoderDivision);
            this.gb_encoder_division.Controls.Add(this.label28);
            this.gb_encoder_division.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.gb_encoder_division.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gb_encoder_division.Location = new System.Drawing.Point(6, 248);
            this.gb_encoder_division.Name = "gb_encoder_division";
            this.gb_encoder_division.Size = new System.Drawing.Size(525, 74);
            this.gb_encoder_division.TabIndex = 35;
            this.gb_encoder_division.TabStop = false;
            this.gb_encoder_division.Text = "Encoder Division";
            // 
            // btn_encoderDivSet
            // 
            this.btn_encoderDivSet.Location = new System.Drawing.Point(447, 28);
            this.btn_encoderDivSet.Name = "btn_encoderDivSet";
            this.btn_encoderDivSet.Size = new System.Drawing.Size(67, 26);
            this.btn_encoderDivSet.TabIndex = 52;
            this.btn_encoderDivSet.Text = "Set";
            this.btn_encoderDivSet.UseVisualStyleBackColor = true;
            this.btn_encoderDivSet.Click += new System.EventHandler(this.btn_encoderDivSet_Click);
            // 
            // nud_encoderDivision
            // 
            this.nud_encoderDivision.Location = new System.Drawing.Point(265, 34);
            this.nud_encoderDivision.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.nud_encoderDivision.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_encoderDivision.Name = "nud_encoderDivision";
            this.nud_encoderDivision.Size = new System.Drawing.Size(120, 23);
            this.nud_encoderDivision.TabIndex = 22;
            this.nud_encoderDivision.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label28.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label28.Location = new System.Drawing.Point(19, 34);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(135, 14);
            this.label28.TabIndex = 17;
            this.label28.Text = "Factor(1~65535):";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btn_trigger_set);
            this.groupBox5.Controls.Add(this.cb_syncTriggerOut);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.cb_externTriggerSource);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Controls.Add(this.cb_encoderTriggerSource);
            this.groupBox5.Controls.Add(this.cb_triggerMode);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox5.Location = new System.Drawing.Point(6, 36);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(535, 206);
            this.groupBox5.TabIndex = 34;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Trigger Source";
            // 
            // btn_trigger_set
            // 
            this.btn_trigger_set.Location = new System.Drawing.Point(447, 174);
            this.btn_trigger_set.Name = "btn_trigger_set";
            this.btn_trigger_set.Size = new System.Drawing.Size(67, 26);
            this.btn_trigger_set.TabIndex = 52;
            this.btn_trigger_set.Text = "Set";
            this.btn_trigger_set.UseVisualStyleBackColor = true;
            this.btn_trigger_set.Click += new System.EventHandler(this.btn_trigger_set_Click);
            // 
            // cb_syncTriggerOut
            // 
            this.cb_syncTriggerOut.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cb_syncTriggerOut.FormattingEnabled = true;
            this.cb_syncTriggerOut.Items.AddRange(new object[] {
            "Disable",
            "Enable"});
            this.cb_syncTriggerOut.Location = new System.Drawing.Point(265, 174);
            this.cb_syncTriggerOut.Name = "cb_syncTriggerOut";
            this.cb_syncTriggerOut.Size = new System.Drawing.Size(157, 22);
            this.cb_syncTriggerOut.TabIndex = 22;
            this.cb_syncTriggerOut.Text = "Disable";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label23.Location = new System.Drawing.Point(11, 180);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(143, 14);
            this.label23.TabIndex = 17;
            this.label23.Text = "Sync trigger out:";
            // 
            // cb_externTriggerSource
            // 
            this.cb_externTriggerSource.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cb_externTriggerSource.FormattingEnabled = true;
            this.cb_externTriggerSource.Items.AddRange(new object[] {
            "SYNC-IN"});
            this.cb_externTriggerSource.Location = new System.Drawing.Point(265, 136);
            this.cb_externTriggerSource.Name = "cb_externTriggerSource";
            this.cb_externTriggerSource.Size = new System.Drawing.Size(157, 22);
            this.cb_externTriggerSource.TabIndex = 16;
            this.cb_externTriggerSource.Text = "SYNC-IN";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label24.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label24.Location = new System.Drawing.Point(10, 139);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(183, 14);
            this.label24.TabIndex = 15;
            this.label24.Text = "Extern trigger source:";
            // 
            // cb_encoderTriggerSource
            // 
            this.cb_encoderTriggerSource.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cb_encoderTriggerSource.FormattingEnabled = true;
            this.cb_encoderTriggerSource.Items.AddRange(new object[] {
            "Channel 0",
            "Channel 1",
            "Channel 2"});
            this.cb_encoderTriggerSource.Location = new System.Drawing.Point(265, 87);
            this.cb_encoderTriggerSource.Name = "cb_encoderTriggerSource";
            this.cb_encoderTriggerSource.Size = new System.Drawing.Size(157, 22);
            this.cb_encoderTriggerSource.TabIndex = 14;
            this.cb_encoderTriggerSource.Text = "Channel 0";
            // 
            // cb_triggerMode
            // 
            this.cb_triggerMode.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cb_triggerMode.FormattingEnabled = true;
            this.cb_triggerMode.Items.AddRange(new object[] {
            "Internal trigger",
            "Extern trigger",
            "Encoder trigger",
            "Timing trigger"});
            this.cb_triggerMode.Location = new System.Drawing.Point(265, 38);
            this.cb_triggerMode.Name = "cb_triggerMode";
            this.cb_triggerMode.Size = new System.Drawing.Size(157, 22);
            this.cb_triggerMode.TabIndex = 13;
            this.cb_triggerMode.Text = "Internal trigger";
            this.cb_triggerMode.SelectedIndexChanged += new System.EventHandler(this.cb_triggerMode_SelectedIndexChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label25.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label25.Location = new System.Drawing.Point(10, 90);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(191, 14);
            this.label25.TabIndex = 9;
            this.label25.Text = "Encoder trigger source:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label26.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label26.Location = new System.Drawing.Point(10, 49);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(111, 14);
            this.label26.TabIndex = 3;
            this.label26.Text = "Trigger mode:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btn_signalSmooth);
            this.groupBox3.Controls.Add(this.nud_signalSmoothLen);
            this.groupBox3.Controls.Add(this.label92);
            this.groupBox3.Controls.Add(this.tb_offset);
            this.groupBox3.Controls.Add(this.btn_offset_set);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.btn_signalSet);
            this.groupBox3.Controls.Add(this.cb_signalSelect);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.nud_mainFaculIndex);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.rb_mulDis_DIS);
            this.groupBox3.Controls.Add(this.rb_mulDis_EN);
            this.groupBox3.Location = new System.Drawing.Point(468, 15);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(418, 220);
            this.groupBox3.TabIndex = 45;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "用户控制";
            // 
            // btn_signalSmooth
            // 
            this.btn_signalSmooth.Location = new System.Drawing.Point(273, 183);
            this.btn_signalSmooth.Name = "btn_signalSmooth";
            this.btn_signalSmooth.Size = new System.Drawing.Size(67, 26);
            this.btn_signalSmooth.TabIndex = 54;
            this.btn_signalSmooth.Text = "Set";
            this.btn_signalSmooth.UseVisualStyleBackColor = true;
            this.btn_signalSmooth.Click += new System.EventHandler(this.btn_signalSmooth_Click);
            // 
            // nud_signalSmoothLen
            // 
            this.nud_signalSmoothLen.Location = new System.Drawing.Point(126, 185);
            this.nud_signalSmoothLen.Maximum = new decimal(new int[] {
            33,
            0,
            0,
            0});
            this.nud_signalSmoothLen.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_signalSmoothLen.Name = "nud_signalSmoothLen";
            this.nud_signalSmoothLen.Size = new System.Drawing.Size(100, 21);
            this.nud_signalSmoothLen.TabIndex = 53;
            this.nud_signalSmoothLen.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label92.Location = new System.Drawing.Point(29, 183);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(72, 16);
            this.label92.TabIndex = 52;
            this.label92.Text = "信号平滑";
            // 
            // tb_offset
            // 
            this.tb_offset.Location = new System.Drawing.Point(126, 142);
            this.tb_offset.Name = "tb_offset";
            this.tb_offset.Size = new System.Drawing.Size(100, 21);
            this.tb_offset.TabIndex = 37;
            this.tb_offset.Text = "0";
            // 
            // btn_offset_set
            // 
            this.btn_offset_set.Location = new System.Drawing.Point(273, 137);
            this.btn_offset_set.Name = "btn_offset_set";
            this.btn_offset_set.Size = new System.Drawing.Size(67, 26);
            this.btn_offset_set.TabIndex = 51;
            this.btn_offset_set.Text = "Set";
            this.btn_offset_set.UseVisualStyleBackColor = true;
            this.btn_offset_set.Click += new System.EventHandler(this.btn_offset_set_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label22.Location = new System.Drawing.Point(28, 142);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(56, 16);
            this.label22.TabIndex = 50;
            this.label22.Text = "Offset";
            // 
            // btn_signalSet
            // 
            this.btn_signalSet.Location = new System.Drawing.Point(273, 101);
            this.btn_signalSet.Name = "btn_signalSet";
            this.btn_signalSet.Size = new System.Drawing.Size(67, 26);
            this.btn_signalSet.TabIndex = 48;
            this.btn_signalSet.Text = "Set";
            this.btn_signalSet.UseVisualStyleBackColor = true;
            this.btn_signalSet.Click += new System.EventHandler(this.btn_signalSet_Click);
            // 
            // cb_signalSelect
            // 
            this.cb_signalSelect.Enabled = false;
            this.cb_signalSelect.FormattingEnabled = true;
            this.cb_signalSelect.Items.AddRange(new object[] {
            "Near",
            "Far",
            "Max"});
            this.cb_signalSelect.Location = new System.Drawing.Point(127, 107);
            this.cb_signalSelect.Name = "cb_signalSelect";
            this.cb_signalSelect.Size = new System.Drawing.Size(99, 20);
            this.cb_signalSelect.TabIndex = 47;
            this.cb_signalSelect.Text = "Near";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.Location = new System.Drawing.Point(22, 106);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(72, 16);
            this.label21.TabIndex = 33;
            this.label21.Text = "信号选择";
            // 
            // nud_mainFaculIndex
            // 
            this.nud_mainFaculIndex.Enabled = false;
            this.nud_mainFaculIndex.Location = new System.Drawing.Point(127, 71);
            this.nud_mainFaculIndex.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_mainFaculIndex.Name = "nud_mainFaculIndex";
            this.nud_mainFaculIndex.Size = new System.Drawing.Size(120, 21);
            this.nud_mainFaculIndex.TabIndex = 32;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(22, 69);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(88, 16);
            this.label20.TabIndex = 31;
            this.label20.Text = "主波峰索引";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(22, 31);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(88, 16);
            this.label19.TabIndex = 26;
            this.label19.Text = "多距离模式";
            // 
            // rb_mulDis_DIS
            // 
            this.rb_mulDis_DIS.AutoSize = true;
            this.rb_mulDis_DIS.Location = new System.Drawing.Point(216, 28);
            this.rb_mulDis_DIS.Name = "rb_mulDis_DIS";
            this.rb_mulDis_DIS.Size = new System.Drawing.Size(65, 16);
            this.rb_mulDis_DIS.TabIndex = 30;
            this.rb_mulDis_DIS.TabStop = true;
            this.rb_mulDis_DIS.Text = "Disable";
            this.rb_mulDis_DIS.UseVisualStyleBackColor = true;
            this.rb_mulDis_DIS.CheckedChanged += new System.EventHandler(this.rb_mulDis_DIS_CheckedChanged);
            // 
            // rb_mulDis_EN
            // 
            this.rb_mulDis_EN.AutoSize = true;
            this.rb_mulDis_EN.Location = new System.Drawing.Point(127, 28);
            this.rb_mulDis_EN.Name = "rb_mulDis_EN";
            this.rb_mulDis_EN.Size = new System.Drawing.Size(59, 16);
            this.rb_mulDis_EN.TabIndex = 29;
            this.rb_mulDis_EN.TabStop = true;
            this.rb_mulDis_EN.Text = "Enable";
            this.rb_mulDis_EN.UseVisualStyleBackColor = true;
            this.rb_mulDis_EN.CheckedChanged += new System.EventHandler(this.rb_mulDis_EN_CheckedChanged);
            // 
            // cb_singleCH_MeasureMode
            // 
            this.cb_singleCH_MeasureMode.FormattingEnabled = true;
            this.cb_singleCH_MeasureMode.Items.AddRange(new object[] {
            "距离",
            "厚度"});
            this.cb_singleCH_MeasureMode.Location = new System.Drawing.Point(94, 18);
            this.cb_singleCH_MeasureMode.Name = "cb_singleCH_MeasureMode";
            this.cb_singleCH_MeasureMode.Size = new System.Drawing.Size(99, 20);
            this.cb_singleCH_MeasureMode.TabIndex = 46;
            this.cb_singleCH_MeasureMode.Text = "距离";
            this.cb_singleCH_MeasureMode.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(16, 20);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(72, 16);
            this.label17.TabIndex = 45;
            this.label17.Text = "测量模式";
            // 
            // gb_control_para
            // 
            this.gb_control_para.Controls.Add(this.cb_binningMode);
            this.gb_control_para.Controls.Add(this.label63);
            this.gb_control_para.Controls.Add(this.groupBox12);
            this.gb_control_para.Controls.Add(this.cb_frameRateControlMode);
            this.gb_control_para.Controls.Add(this.btn_setFrameRate);
            this.gb_control_para.Controls.Add(this.nud_frameRate);
            this.gb_control_para.Controls.Add(this.lb_light);
            this.gb_control_para.Controls.Add(this.tb_light);
            this.gb_control_para.Controls.Add(this.rb_manualLight);
            this.gb_control_para.Controls.Add(this.rb_autoLight);
            this.gb_control_para.Controls.Add(this.nud_expTime);
            this.gb_control_para.Controls.Add(this.btn_setExpTime);
            this.gb_control_para.Controls.Add(this.label7);
            this.gb_control_para.Location = new System.Drawing.Point(17, 47);
            this.gb_control_para.Name = "gb_control_para";
            this.gb_control_para.Size = new System.Drawing.Size(445, 243);
            this.gb_control_para.TabIndex = 25;
            this.gb_control_para.TabStop = false;
            this.gb_control_para.Text = "基础控制参数";
            // 
            // cb_binningMode
            // 
            this.cb_binningMode.FormattingEnabled = true;
            this.cb_binningMode.Items.AddRange(new object[] {
            "X1",
            "X2",
            "X4"});
            this.cb_binningMode.Location = new System.Drawing.Point(257, 198);
            this.cb_binningMode.Name = "cb_binningMode";
            this.cb_binningMode.Size = new System.Drawing.Size(99, 20);
            this.cb_binningMode.TabIndex = 48;
            this.cb_binningMode.Text = "X1";
            this.cb_binningMode.SelectedIndexChanged += new System.EventHandler(this.cb_binningMode_SelectedIndexChanged);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label63.Location = new System.Drawing.Point(252, 172);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(104, 16);
            this.label63.TabIndex = 47;
            this.label63.Text = "Binning mode";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.rb_trubo_enalbe);
            this.groupBox12.Controls.Add(this.rb_trubo_disalbe);
            this.groupBox12.Location = new System.Drawing.Point(24, 163);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(195, 67);
            this.groupBox12.TabIndex = 39;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Turbo ";
            // 
            // rb_trubo_enalbe
            // 
            this.rb_trubo_enalbe.AutoSize = true;
            this.rb_trubo_enalbe.Location = new System.Drawing.Point(13, 36);
            this.rb_trubo_enalbe.Name = "rb_trubo_enalbe";
            this.rb_trubo_enalbe.Size = new System.Drawing.Size(59, 16);
            this.rb_trubo_enalbe.TabIndex = 37;
            this.rb_trubo_enalbe.TabStop = true;
            this.rb_trubo_enalbe.Text = "Enable";
            this.rb_trubo_enalbe.UseVisualStyleBackColor = true;
            this.rb_trubo_enalbe.CheckedChanged += new System.EventHandler(this.rb_trubo_enalbe_CheckedChanged);
            // 
            // rb_trubo_disalbe
            // 
            this.rb_trubo_disalbe.AutoSize = true;
            this.rb_trubo_disalbe.Location = new System.Drawing.Point(118, 36);
            this.rb_trubo_disalbe.Name = "rb_trubo_disalbe";
            this.rb_trubo_disalbe.Size = new System.Drawing.Size(65, 16);
            this.rb_trubo_disalbe.TabIndex = 38;
            this.rb_trubo_disalbe.TabStop = true;
            this.rb_trubo_disalbe.Text = "Disable";
            this.rb_trubo_disalbe.UseVisualStyleBackColor = true;
            this.rb_trubo_disalbe.CheckedChanged += new System.EventHandler(this.rb_trubo_disalbe_CheckedChanged);
            // 
            // cb_frameRateControlMode
            // 
            this.cb_frameRateControlMode.AutoSize = true;
            this.cb_frameRateControlMode.Location = new System.Drawing.Point(25, 131);
            this.cb_frameRateControlMode.Name = "cb_frameRateControlMode";
            this.cb_frameRateControlMode.Size = new System.Drawing.Size(96, 16);
            this.cb_frameRateControlMode.TabIndex = 36;
            this.cb_frameRateControlMode.Text = "帧率控制模式";
            this.cb_frameRateControlMode.UseVisualStyleBackColor = true;
            this.cb_frameRateControlMode.CheckedChanged += new System.EventHandler(this.cb_frameRateControlMode_CheckedChanged);
            // 
            // btn_setFrameRate
            // 
            this.btn_setFrameRate.Enabled = false;
            this.btn_setFrameRate.Location = new System.Drawing.Point(289, 130);
            this.btn_setFrameRate.Name = "btn_setFrameRate";
            this.btn_setFrameRate.Size = new System.Drawing.Size(67, 26);
            this.btn_setFrameRate.TabIndex = 35;
            this.btn_setFrameRate.Text = "Set";
            this.btn_setFrameRate.UseVisualStyleBackColor = true;
            this.btn_setFrameRate.Click += new System.EventHandler(this.btn_setFrameRate_Click);
            // 
            // nud_frameRate
            // 
            this.nud_frameRate.Enabled = false;
            this.nud_frameRate.Location = new System.Drawing.Point(150, 130);
            this.nud_frameRate.Maximum = new decimal(new int[] {
            71000,
            0,
            0,
            0});
            this.nud_frameRate.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_frameRate.Name = "nud_frameRate";
            this.nud_frameRate.Size = new System.Drawing.Size(120, 21);
            this.nud_frameRate.TabIndex = 34;
            this.nud_frameRate.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // lb_light
            // 
            this.lb_light.AutoSize = true;
            this.lb_light.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_light.Location = new System.Drawing.Point(261, 97);
            this.lb_light.Name = "lb_light";
            this.lb_light.Size = new System.Drawing.Size(16, 16);
            this.lb_light.TabIndex = 32;
            this.lb_light.Text = "0";
            // 
            // tb_light
            // 
            this.tb_light.Location = new System.Drawing.Point(25, 97);
            this.tb_light.Maximum = 150;
            this.tb_light.Name = "tb_light";
            this.tb_light.Size = new System.Drawing.Size(230, 45);
            this.tb_light.TabIndex = 31;
            this.tb_light.Scroll += new System.EventHandler(this.tb_light_Scroll);
            this.tb_light.TabIndexChanged += new System.EventHandler(this.tb_light_TabIndexChanged);
            // 
            // rb_manualLight
            // 
            this.rb_manualLight.AutoSize = true;
            this.rb_manualLight.Location = new System.Drawing.Point(126, 75);
            this.rb_manualLight.Name = "rb_manualLight";
            this.rb_manualLight.Size = new System.Drawing.Size(71, 16);
            this.rb_manualLight.TabIndex = 30;
            this.rb_manualLight.TabStop = true;
            this.rb_manualLight.Text = "手动调光";
            this.rb_manualLight.UseVisualStyleBackColor = true;
            this.rb_manualLight.CheckedChanged += new System.EventHandler(this.rb_manualLight_CheckedChanged);
            // 
            // rb_autoLight
            // 
            this.rb_autoLight.AutoSize = true;
            this.rb_autoLight.Location = new System.Drawing.Point(25, 75);
            this.rb_autoLight.Name = "rb_autoLight";
            this.rb_autoLight.Size = new System.Drawing.Size(71, 16);
            this.rb_autoLight.TabIndex = 29;
            this.rb_autoLight.TabStop = true;
            this.rb_autoLight.Text = "自动调光";
            this.rb_autoLight.UseVisualStyleBackColor = true;
            this.rb_autoLight.CheckedChanged += new System.EventHandler(this.rb_autoLight_CheckedChanged);
            // 
            // nud_expTime
            // 
            this.nud_expTime.Location = new System.Drawing.Point(100, 34);
            this.nud_expTime.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_expTime.Minimum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nud_expTime.Name = "nud_expTime";
            this.nud_expTime.Size = new System.Drawing.Size(120, 21);
            this.nud_expTime.TabIndex = 28;
            this.nud_expTime.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // btn_setExpTime
            // 
            this.btn_setExpTime.Location = new System.Drawing.Point(235, 32);
            this.btn_setExpTime.Name = "btn_setExpTime";
            this.btn_setExpTime.Size = new System.Drawing.Size(67, 26);
            this.btn_setExpTime.TabIndex = 27;
            this.btn_setExpTime.Text = "Set";
            this.btn_setExpTime.UseVisualStyleBackColor = true;
            this.btn_setExpTime.Click += new System.EventHandler(this.btn_setExpTime_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(22, 35);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 16);
            this.label7.TabIndex = 26;
            this.label7.Text = "曝光时间";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cb_channe_4_lEnable);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.cb_channe_3_lEnable);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.cb_channe_2_lEnable);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.cb_channe_1_lEnable);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Location = new System.Drawing.Point(16, 411);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(271, 111);
            this.groupBox2.TabIndex = 40;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "通道使能";
            // 
            // cb_channe_4_lEnable
            // 
            this.cb_channe_4_lEnable.AutoSize = true;
            this.cb_channe_4_lEnable.Location = new System.Drawing.Point(208, 74);
            this.cb_channe_4_lEnable.Name = "cb_channe_4_lEnable";
            this.cb_channe_4_lEnable.Size = new System.Drawing.Size(48, 16);
            this.cb_channe_4_lEnable.TabIndex = 43;
            this.cb_channe_4_lEnable.Text = "使能";
            this.cb_channe_4_lEnable.UseVisualStyleBackColor = true;
            this.cb_channe_4_lEnable.CheckedChanged += new System.EventHandler(this.cb_channe_4_lEnable_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(152, 71);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(48, 16);
            this.label13.TabIndex = 42;
            this.label13.Text = "通道4";
            // 
            // cb_channe_3_lEnable
            // 
            this.cb_channe_3_lEnable.AutoSize = true;
            this.cb_channe_3_lEnable.Location = new System.Drawing.Point(208, 42);
            this.cb_channe_3_lEnable.Name = "cb_channe_3_lEnable";
            this.cb_channe_3_lEnable.Size = new System.Drawing.Size(48, 16);
            this.cb_channe_3_lEnable.TabIndex = 41;
            this.cb_channe_3_lEnable.Text = "使能";
            this.cb_channe_3_lEnable.UseVisualStyleBackColor = true;
            this.cb_channe_3_lEnable.CheckedChanged += new System.EventHandler(this.cb_channe_3_lEnable_CheckedChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(152, 39);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(48, 16);
            this.label14.TabIndex = 40;
            this.label14.Text = "通道3";
            // 
            // cb_channe_2_lEnable
            // 
            this.cb_channe_2_lEnable.AutoSize = true;
            this.cb_channe_2_lEnable.Location = new System.Drawing.Point(78, 74);
            this.cb_channe_2_lEnable.Name = "cb_channe_2_lEnable";
            this.cb_channe_2_lEnable.Size = new System.Drawing.Size(48, 16);
            this.cb_channe_2_lEnable.TabIndex = 39;
            this.cb_channe_2_lEnable.Text = "使能";
            this.cb_channe_2_lEnable.UseVisualStyleBackColor = true;
            this.cb_channe_2_lEnable.CheckedChanged += new System.EventHandler(this.cb_channe_2_lEnable_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(22, 71);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 16);
            this.label11.TabIndex = 38;
            this.label11.Text = "通道2";
            // 
            // cb_channe_1_lEnable
            // 
            this.cb_channe_1_lEnable.AutoSize = true;
            this.cb_channe_1_lEnable.Location = new System.Drawing.Point(78, 42);
            this.cb_channe_1_lEnable.Name = "cb_channe_1_lEnable";
            this.cb_channe_1_lEnable.Size = new System.Drawing.Size(48, 16);
            this.cb_channe_1_lEnable.TabIndex = 37;
            this.cb_channe_1_lEnable.Text = "使能";
            this.cb_channe_1_lEnable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cb_channe_1_lEnable.UseVisualStyleBackColor = true;
            this.cb_channe_1_lEnable.CheckedChanged += new System.EventHandler(this.cb_channe_1_lEnable_CheckedChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(22, 39);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 16);
            this.label12.TabIndex = 26;
            this.label12.Text = "通道1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.nud_movingAverageFilter);
            this.groupBox1.Controls.Add(this.btn_setMobingAverageFilter);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.nud_medianFilter);
            this.groupBox1.Controls.Add(this.btn_setMedianFilter);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Location = new System.Drawing.Point(16, 301);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(446, 107);
            this.groupBox1.TabIndex = 37;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "滤波设置";
            // 
            // nud_movingAverageFilter
            // 
            this.nud_movingAverageFilter.Location = new System.Drawing.Point(135, 73);
            this.nud_movingAverageFilter.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_movingAverageFilter.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_movingAverageFilter.Name = "nud_movingAverageFilter";
            this.nud_movingAverageFilter.Size = new System.Drawing.Size(120, 21);
            this.nud_movingAverageFilter.TabIndex = 31;
            this.nud_movingAverageFilter.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btn_setMobingAverageFilter
            // 
            this.btn_setMobingAverageFilter.Location = new System.Drawing.Point(274, 68);
            this.btn_setMobingAverageFilter.Name = "btn_setMobingAverageFilter";
            this.btn_setMobingAverageFilter.Size = new System.Drawing.Size(67, 26);
            this.btn_setMobingAverageFilter.TabIndex = 30;
            this.btn_setMobingAverageFilter.Text = "Set";
            this.btn_setMobingAverageFilter.UseVisualStyleBackColor = true;
            this.btn_setMobingAverageFilter.Click += new System.EventHandler(this.btn_setMobingAverageFilter_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(22, 71);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(104, 16);
            this.label8.TabIndex = 29;
            this.label8.Text = "滑动平均滤波";
            // 
            // nud_medianFilter
            // 
            this.nud_medianFilter.Location = new System.Drawing.Point(135, 37);
            this.nud_medianFilter.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_medianFilter.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_medianFilter.Name = "nud_medianFilter";
            this.nud_medianFilter.Size = new System.Drawing.Size(120, 21);
            this.nud_medianFilter.TabIndex = 28;
            this.nud_medianFilter.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btn_setMedianFilter
            // 
            this.btn_setMedianFilter.Location = new System.Drawing.Point(274, 32);
            this.btn_setMedianFilter.Name = "btn_setMedianFilter";
            this.btn_setMedianFilter.Size = new System.Drawing.Size(67, 26);
            this.btn_setMedianFilter.TabIndex = 27;
            this.btn_setMedianFilter.Text = "Set";
            this.btn_setMedianFilter.UseVisualStyleBackColor = true;
            this.btn_setMedianFilter.Click += new System.EventHandler(this.btn_setMedianFilter_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(22, 35);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 16);
            this.label9.TabIndex = 26;
            this.label9.Text = "中间值滤波";
            // 
            // lb_frameRate
            // 
            this.lb_frameRate.AutoSize = true;
            this.lb_frameRate.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_frameRate.Location = new System.Drawing.Point(1121, 54);
            this.lb_frameRate.Name = "lb_frameRate";
            this.lb_frameRate.Size = new System.Drawing.Size(16, 16);
            this.lb_frameRate.TabIndex = 39;
            this.lb_frameRate.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(1067, 55);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 16);
            this.label10.TabIndex = 38;
            this.label10.Text = "帧率:";
            // 
            // btn_saveConfig
            // 
            this.btn_saveConfig.Location = new System.Drawing.Point(505, 283);
            this.btn_saveConfig.Name = "btn_saveConfig";
            this.btn_saveConfig.Size = new System.Drawing.Size(78, 41);
            this.btn_saveConfig.TabIndex = 27;
            this.btn_saveConfig.Text = "保存配置";
            this.btn_saveConfig.UseVisualStyleBackColor = true;
            this.btn_saveConfig.Click += new System.EventHandler(this.btn_saveConfig_Click);
            // 
            // btn_singleShot
            // 
            this.btn_singleShot.Location = new System.Drawing.Point(13, 556);
            this.btn_singleShot.Name = "btn_singleShot";
            this.btn_singleShot.Size = new System.Drawing.Size(87, 38);
            this.btn_singleShot.TabIndex = 26;
            this.btn_singleShot.Text = "单次采集";
            this.btn_singleShot.UseVisualStyleBackColor = true;
            this.btn_singleShot.Click += new System.EventHandler(this.btn_singleShot_Click);
            // 
            // gb_connectDevice
            // 
            this.gb_connectDevice.Controls.Add(this.rb_cf1000);
            this.gb_connectDevice.Controls.Add(this.button2);
            this.gb_connectDevice.Controls.Add(this.btn_scan_device);
            this.gb_connectDevice.Controls.Add(this.rb_cf2000);
            this.gb_connectDevice.Controls.Add(this.rb_cf4000);
            this.gb_connectDevice.Controls.Add(this.btn_open_device);
            this.gb_connectDevice.Location = new System.Drawing.Point(12, 283);
            this.gb_connectDevice.Name = "gb_connectDevice";
            this.gb_connectDevice.Size = new System.Drawing.Size(347, 135);
            this.gb_connectDevice.TabIndex = 20;
            this.gb_connectDevice.TabStop = false;
            this.gb_connectDevice.Text = "连接设备";
            // 
            // rb_cf1000
            // 
            this.rb_cf1000.AutoSize = true;
            this.rb_cf1000.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rb_cf1000.Location = new System.Drawing.Point(14, 43);
            this.rb_cf1000.Name = "rb_cf1000";
            this.rb_cf1000.Size = new System.Drawing.Size(87, 23);
            this.rb_cf1000.TabIndex = 53;
            this.rb_cf1000.TabStop = true;
            this.rb_cf1000.Text = "CF1000";
            this.rb_cf1000.UseVisualStyleBackColor = true;
            this.rb_cf1000.CheckedChanged += new System.EventHandler(this.rb_cf1000_CheckedChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(236, 82);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 37);
            this.button2.TabIndex = 52;
            this.button2.Text = "断开设备";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_scan_device
            // 
            this.btn_scan_device.Enabled = false;
            this.btn_scan_device.Location = new System.Drawing.Point(9, 82);
            this.btn_scan_device.Name = "btn_scan_device";
            this.btn_scan_device.Size = new System.Drawing.Size(100, 37);
            this.btn_scan_device.TabIndex = 0;
            this.btn_scan_device.Text = "扫描设备";
            this.btn_scan_device.UseVisualStyleBackColor = true;
            this.btn_scan_device.Click += new System.EventHandler(this.btn_scan_device_Click);
            // 
            // rb_cf2000
            // 
            this.rb_cf2000.AutoSize = true;
            this.rb_cf2000.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rb_cf2000.Location = new System.Drawing.Point(120, 43);
            this.rb_cf2000.Name = "rb_cf2000";
            this.rb_cf2000.Size = new System.Drawing.Size(87, 23);
            this.rb_cf2000.TabIndex = 19;
            this.rb_cf2000.TabStop = true;
            this.rb_cf2000.Text = "CF2000";
            this.rb_cf2000.UseVisualStyleBackColor = true;
            this.rb_cf2000.CheckedChanged += new System.EventHandler(this.rb_cf2000_CheckedChanged);
            // 
            // rb_cf4000
            // 
            this.rb_cf4000.AutoSize = true;
            this.rb_cf4000.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rb_cf4000.Location = new System.Drawing.Point(231, 41);
            this.rb_cf4000.Name = "rb_cf4000";
            this.rb_cf4000.Size = new System.Drawing.Size(87, 23);
            this.rb_cf4000.TabIndex = 18;
            this.rb_cf4000.TabStop = true;
            this.rb_cf4000.Text = "CF4000";
            this.rb_cf4000.UseVisualStyleBackColor = true;
            this.rb_cf4000.CheckedChanged += new System.EventHandler(this.rb_cf4000_CheckedChanged);
            // 
            // btn_open_device
            // 
            this.btn_open_device.Enabled = false;
            this.btn_open_device.Location = new System.Drawing.Point(115, 82);
            this.btn_open_device.Name = "btn_open_device";
            this.btn_open_device.Size = new System.Drawing.Size(107, 37);
            this.btn_open_device.TabIndex = 3;
            this.btn_open_device.Text = "打开设备";
            this.btn_open_device.UseVisualStyleBackColor = true;
            this.btn_open_device.Click += new System.EventHandler(this.btn_open_device_Click);
            // 
            // cb_presetExpTime
            // 
            this.cb_presetExpTime.AutoSize = true;
            this.cb_presetExpTime.Location = new System.Drawing.Point(453, 522);
            this.cb_presetExpTime.Name = "cb_presetExpTime";
            this.cb_presetExpTime.Size = new System.Drawing.Size(96, 16);
            this.cb_presetExpTime.TabIndex = 23;
            this.cb_presetExpTime.Text = "所有曝光时间";
            this.cb_presetExpTime.UseVisualStyleBackColor = true;
            // 
            // chart1
            // 
            this.chart1.AllowDrop = true;
            chartArea2.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chart1.Legends.Add(legend2);
            this.chart1.Location = new System.Drawing.Point(720, 75);
            this.chart1.Name = "chart1";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            series2.Legend = "Legend1";
            series2.Name = "Signal";
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(488, 218);
            this.chart1.TabIndex = 24;
            this.chart1.Text = "chart1";
            // 
            // btn_dark
            // 
            this.btn_dark.Location = new System.Drawing.Point(378, 572);
            this.btn_dark.Name = "btn_dark";
            this.btn_dark.Size = new System.Drawing.Size(78, 41);
            this.btn_dark.TabIndex = 22;
            this.btn_dark.Text = "Dark";
            this.btn_dark.UseVisualStyleBackColor = true;
            this.btn_dark.Click += new System.EventHandler(this.btn_dark_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(17, 131);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "设备个数:";
            // 
            // lb_device_number
            // 
            this.lb_device_number.AutoSize = true;
            this.lb_device_number.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_device_number.Location = new System.Drawing.Point(145, 132);
            this.lb_device_number.Name = "lb_device_number";
            this.lb_device_number.Size = new System.Drawing.Size(19, 19);
            this.lb_device_number.TabIndex = 2;
            this.lb_device_number.Text = "0";
            // 
            // lb_controler_version
            // 
            this.lb_controler_version.AutoSize = true;
            this.lb_controler_version.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_controler_version.Location = new System.Drawing.Point(146, 50);
            this.lb_controler_version.Name = "lb_controler_version";
            this.lb_controler_version.Size = new System.Drawing.Size(19, 19);
            this.lb_controler_version.TabIndex = 17;
            this.lb_controler_version.Text = "0";
            // 
            // btn_start_sample
            // 
            this.btn_start_sample.Location = new System.Drawing.Point(13, 424);
            this.btn_start_sample.Name = "btn_start_sample";
            this.btn_start_sample.Size = new System.Drawing.Size(100, 37);
            this.btn_start_sample.TabIndex = 4;
            this.btn_start_sample.Text = "启动测量";
            this.btn_start_sample.UseVisualStyleBackColor = true;
            this.btn_start_sample.Click += new System.EventHandler(this.btn_start_sample_Click);
            // 
            // lb_sdk_version
            // 
            this.lb_sdk_version.AutoSize = true;
            this.lb_sdk_version.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_sdk_version.Location = new System.Drawing.Point(146, 7);
            this.lb_sdk_version.Name = "lb_sdk_version";
            this.lb_sdk_version.Size = new System.Drawing.Size(19, 19);
            this.lb_sdk_version.TabIndex = 16;
            this.lb_sdk_version.Text = "0";
            // 
            // rtb_error_text
            // 
            this.rtb_error_text.Location = new System.Drawing.Point(378, 42);
            this.rtb_error_text.Name = "rtb_error_text";
            this.rtb_error_text.Size = new System.Drawing.Size(317, 235);
            this.rtb_error_text.TabIndex = 5;
            this.rtb_error_text.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(15, 50);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 19);
            this.label6.TabIndex = 15;
            this.label6.Text = "控制器版本:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(374, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 19);
            this.label3.TabIndex = 6;
            this.label3.Text = "错误信息:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(22, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 19);
            this.label5.TabIndex = 14;
            this.label5.Text = "SDK版本:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(877, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "测量结果(mm):";
            // 
            // btn_zero
            // 
            this.btn_zero.Location = new System.Drawing.Point(270, 574);
            this.btn_zero.Name = "btn_zero";
            this.btn_zero.Size = new System.Drawing.Size(74, 41);
            this.btn_zero.TabIndex = 13;
            this.btn_zero.Text = "Zero";
            this.btn_zero.UseVisualStyleBackColor = true;
            this.btn_zero.Click += new System.EventHandler(this.btn_zero_Click);
            // 
            // lb_result
            // 
            this.lb_result.AutoSize = true;
            this.lb_result.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_result.Location = new System.Drawing.Point(999, 53);
            this.lb_result.Name = "lb_result";
            this.lb_result.Size = new System.Drawing.Size(16, 16);
            this.lb_result.TabIndex = 8;
            this.lb_result.Text = "0";
            // 
            // lb_saturation
            // 
            this.lb_saturation.AutoSize = true;
            this.lb_saturation.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_saturation.Location = new System.Drawing.Point(822, 55);
            this.lb_saturation.Name = "lb_saturation";
            this.lb_saturation.Size = new System.Drawing.Size(32, 16);
            this.lb_saturation.TabIndex = 12;
            this.lb_saturation.Text = "0 %";
            // 
            // btn_error_text_clear
            // 
            this.btn_error_text_clear.Location = new System.Drawing.Point(378, 283);
            this.btn_error_text_clear.Name = "btn_error_text_clear";
            this.btn_error_text_clear.Size = new System.Drawing.Size(66, 28);
            this.btn_error_text_clear.TabIndex = 9;
            this.btn_error_text_clear.Text = "清空";
            this.btn_error_text_clear.UseVisualStyleBackColor = true;
            this.btn_error_text_clear.Click += new System.EventHandler(this.btn_error_text_clear_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(730, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 16);
            this.label2.TabIndex = 11;
            this.label2.Text = "信号强度:";
            // 
            // btn_stop_sample
            // 
            this.btn_stop_sample.Location = new System.Drawing.Point(12, 470);
            this.btn_stop_sample.Name = "btn_stop_sample";
            this.btn_stop_sample.Size = new System.Drawing.Size(100, 37);
            this.btn_stop_sample.TabIndex = 10;
            this.btn_stop_sample.Text = "停止测量";
            this.btn_stop_sample.UseVisualStyleBackColor = true;
            this.btn_stop_sample.Click += new System.EventHandler(this.btn_stop_sample_Click);
            // 
            // gb_thickness
            // 
            this.gb_thickness.Controls.Add(this.btn_addPoint);
            this.gb_thickness.Controls.Add(this.lb_calibthicknesspointnum);
            this.gb_thickness.Controls.Add(this.lb_calibthicknesspoint);
            this.gb_thickness.Controls.Add(this.label102);
            this.gb_thickness.Controls.Add(this.label106);
            this.gb_thickness.Controls.Add(this.nud_calibthickness);
            this.gb_thickness.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.gb_thickness.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gb_thickness.Location = new System.Drawing.Point(12, 104);
            this.gb_thickness.Name = "gb_thickness";
            this.gb_thickness.Size = new System.Drawing.Size(405, 55);
            this.gb_thickness.TabIndex = 66;
            this.gb_thickness.TabStop = false;
            this.gb_thickness.Text = "厚度标定";
            // 
            // lb_calibthicknesspointnum
            // 
            this.lb_calibthicknesspointnum.AutoSize = true;
            this.lb_calibthicknesspointnum.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_calibthicknesspointnum.ForeColor = System.Drawing.SystemColors.MenuText;
            this.lb_calibthicknesspointnum.Location = new System.Drawing.Point(315, 26);
            this.lb_calibthicknesspointnum.Name = "lb_calibthicknesspointnum";
            this.lb_calibthicknesspointnum.Size = new System.Drawing.Size(14, 14);
            this.lb_calibthicknesspointnum.TabIndex = 56;
            this.lb_calibthicknesspointnum.Text = "0";
            // 
            // lb_calibthicknesspoint
            // 
            this.lb_calibthicknesspoint.AutoSize = true;
            this.lb_calibthicknesspoint.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_calibthicknesspoint.ForeColor = System.Drawing.SystemColors.MenuText;
            this.lb_calibthicknesspoint.Location = new System.Drawing.Point(260, 26);
            this.lb_calibthicknesspoint.Name = "lb_calibthicknesspoint";
            this.lb_calibthicknesspoint.Size = new System.Drawing.Size(49, 14);
            this.lb_calibthicknesspoint.TabIndex = 55;
            this.lb_calibthicknesspoint.Text = "点数: ";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label102.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label102.Location = new System.Drawing.Point(219, 26);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(17, 12);
            this.label102.TabIndex = 54;
            this.label102.Text = "mm";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label106.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label106.Location = new System.Drawing.Point(7, 25);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(53, 12);
            this.label106.TabIndex = 53;
            this.label106.Text = "真实厚度";
            // 
            // nud_calibthickness
            // 
            this.nud_calibthickness.DecimalPlaces = 4;
            this.nud_calibthickness.Location = new System.Drawing.Point(97, 22);
            this.nud_calibthickness.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.nud_calibthickness.Name = "nud_calibthickness";
            this.nud_calibthickness.Size = new System.Drawing.Size(120, 21);
            this.nud_calibthickness.TabIndex = 18;
            this.nud_calibthickness.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // bt_reset
            // 
            this.bt_reset.Location = new System.Drawing.Point(240, 165);
            this.bt_reset.Name = "bt_reset";
            this.bt_reset.Size = new System.Drawing.Size(75, 23);
            this.bt_reset.TabIndex = 67;
            this.bt_reset.Text = "复位";
            this.bt_reset.UseVisualStyleBackColor = true;
            this.bt_reset.Click += new System.EventHandler(this.bt_reset_Click);
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label99.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label99.Location = new System.Drawing.Point(225, 23);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(48, 16);
            this.label99.TabIndex = 69;
            this.label99.Text = "Mode:";
            // 
            // cb_calibrationmode
            // 
            this.cb_calibrationmode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_calibrationmode.Font = new System.Drawing.Font("黑体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cb_calibrationmode.FormattingEnabled = true;
            this.cb_calibrationmode.Items.AddRange(new object[] {
            "Thickness",
            "Coefficient"});
            this.cb_calibrationmode.Location = new System.Drawing.Point(287, 22);
            this.cb_calibrationmode.Name = "cb_calibrationmode";
            this.cb_calibrationmode.Size = new System.Drawing.Size(104, 22);
            this.cb_calibrationmode.TabIndex = 68;
            // 
            // btn_addPoint
            // 
            this.btn_addPoint.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_addPoint.Location = new System.Drawing.Point(336, 22);
            this.btn_addPoint.Name = "btn_addPoint";
            this.btn_addPoint.Size = new System.Drawing.Size(69, 23);
            this.btn_addPoint.TabIndex = 58;
            this.btn_addPoint.Text = "添加";
            this.btn_addPoint.UseVisualStyleBackColor = true;
            this.btn_addPoint.Click += new System.EventHandler(this.btn_addPoint_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1389, 670);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "光谱共焦SDK测试Demo V1.8.10";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.gb_control.ResumeLayout(false);
            this.gb_control.PerformLayout();
            this.groupBox26.ResumeLayout(false);
            this.groupBox26.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_k2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_k1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_k0)).EndInit();
            this.groupBox22.ResumeLayout(false);
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_k_nf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_k_nd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_k_nc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_k_index2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_k_index1)).EndInit();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_prrgSeg)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_controllerport)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.gb_timing_trigger.ResumeLayout(false);
            this.gb_timing_trigger.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_timingTriggerHZ)).EndInit();
            this.gb_encoder_division.ResumeLayout(false);
            this.gb_encoder_division.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_encoderDivision)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_signalSmoothLen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_mainFaculIndex)).EndInit();
            this.gb_control_para.ResumeLayout(false);
            this.gb_control_para.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_frameRate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_light)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_expTime)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_movingAverageFilter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_medianFilter)).EndInit();
            this.gb_connectDevice.ResumeLayout(false);
            this.gb_connectDevice.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.gb_thickness.ResumeLayout(false);
            this.gb_thickness.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_calibthickness)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_device_number;
        private System.Windows.Forms.Button btn_start_sample;
        private System.Windows.Forms.RichTextBox rtb_error_text;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lb_result;
        private System.Windows.Forms.Button btn_error_text_clear;
        private System.Windows.Forms.Button btn_stop_sample;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lb_saturation;
        private System.Windows.Forms.Button btn_zero;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lb_sdk_version;
        private System.Windows.Forms.Label lb_controler_version;
        private System.Windows.Forms.Button btn_open_device;
        private System.Windows.Forms.RadioButton rb_cf4000;
        private System.Windows.Forms.RadioButton rb_cf2000;
        private System.Windows.Forms.Button btn_scan_device;
        private System.Windows.Forms.GroupBox gb_connectDevice;
        private System.Windows.Forms.Button btn_dark;
        private System.Windows.Forms.CheckBox cb_presetExpTime;
        private System.Windows.Forms.Button btn_singleShot;
        private System.Windows.Forms.Button btn_saveConfig;
        private System.Windows.Forms.Label lb_frameRate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lb_controler_SN;
        private System.Windows.Forms.CheckBox cb_dark_all_ch;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox cb_doubleChannel;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.Label lb_saturation2;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox gb_control;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.ComboBox cb_inputport_func2;
        private System.Windows.Forms.ComboBox cb_inputport_ch_2;
        private System.Windows.Forms.Button btn_set_input_port;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.ComboBox cb_inputport_func1;
        private System.Windows.Forms.ComboBox cb_inputport_ch_1;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button btn_tol_set;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox tb_lowerLimitValue;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox tb_upperLimitValue;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.NumericUpDown nud_prrgSeg;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.ComboBox cb_OUT_IO_4_Mode;
        private System.Windows.Forms.ComboBox cb_OUT_IO_3_Mode;
        private System.Windows.Forms.ComboBox cb_OUT_IO_2_Mode;
        private System.Windows.Forms.ComboBox cb_group;
        private System.Windows.Forms.ComboBox cb_OUT_IO_3_FUNC;
        private System.Windows.Forms.ComboBox cb_OUT_IO_2_FUNC;
        private System.Windows.Forms.ComboBox cb_OUT_IO_4_CH;
        private System.Windows.Forms.ComboBox cb_OUT_IO_3_CH;
        private System.Windows.Forms.ComboBox cb_OUT_IO_2_CH;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Button btn_IO_OutputSet;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox cb_OUT_IO_1_Mode;
        private System.Windows.Forms.ComboBox cb_OUT_IO_1_FUNC;
        private System.Windows.Forms.ComboBox cb_OUT_IO_1_CH;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button btn_vol_set;
        private System.Windows.Forms.RadioButton rb_vol_output_disen;
        private System.Windows.Forms.RadioButton rb_vol_output_en;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox tb_max_dis;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox tb_min_dis;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox tb_max_vol;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tb_mini_vol;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button btn_ethernetPara;
        private System.Windows.Forms.TextBox tb_ip;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.NumericUpDown nud_controllerport;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox gb_timing_trigger;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.NumericUpDown nud_timingTriggerHZ;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.GroupBox gb_encoder_division;
        private System.Windows.Forms.Button btn_encoderDivSet;
        private System.Windows.Forms.NumericUpDown nud_encoderDivision;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btn_trigger_set;
        private System.Windows.Forms.ComboBox cb_syncTriggerOut;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox cb_externTriggerSource;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox cb_encoderTriggerSource;
        private System.Windows.Forms.ComboBox cb_triggerMode;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox tb_offset;
        private System.Windows.Forms.Button btn_offset_set;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button btn_signalSet;
        private System.Windows.Forms.ComboBox cb_signalSelect;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown nud_mainFaculIndex;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.RadioButton rb_mulDis_DIS;
        private System.Windows.Forms.RadioButton rb_mulDis_EN;
        private System.Windows.Forms.ComboBox cb_singleCH_MeasureMode;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cb_channelSelect;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox gb_control_para;
        private System.Windows.Forms.CheckBox cb_frameRateControlMode;
        private System.Windows.Forms.Button btn_setFrameRate;
        private System.Windows.Forms.NumericUpDown nud_frameRate;
        private System.Windows.Forms.Label lb_light;
        private System.Windows.Forms.TrackBar tb_light;
        private System.Windows.Forms.RadioButton rb_manualLight;
        private System.Windows.Forms.RadioButton rb_autoLight;
        private System.Windows.Forms.NumericUpDown nud_expTime;
        private System.Windows.Forms.Button btn_setExpTime;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox cb_channe_4_lEnable;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.CheckBox cb_channe_3_lEnable;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckBox cb_channe_2_lEnable;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox cb_channe_1_lEnable;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown nud_movingAverageFilter;
        private System.Windows.Forms.Button btn_setMobingAverageFilter;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown nud_medianFilter;
        private System.Windows.Forms.Button btn_setMedianFilter;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton rb_cf1000;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.RadioButton rb_trubo_enalbe;
        private System.Windows.Forms.RadioButton rb_trubo_disalbe;
        private System.Windows.Forms.ComboBox cb_binningMode;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Button btn_get_cache_info;
        private System.Windows.Forms.RichTextBox rb_cache_info;
        private System.Windows.Forms.Button btn_clear_cache;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ComboBox cb_encoder_working_mode;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox cb_encoder_input;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label lb_trigger2;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label lb_trigger1;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label lb_trigger0;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Button btn_clear_trigger_count;
        private System.Windows.Forms.Label lb_dis4;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label lb_dis3;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label lb_dis2;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label lb_dis1;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label lb_distanceNumber;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox tb_signalDetectThrehold;
        private System.Windows.Forms.TextBox tb_cal_threhold;
        private System.Windows.Forms.TextBox tb_mini_cal_point;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.RadioButton trigger_pass_en;
        private System.Windows.Forms.RadioButton trigger_pass_off;
        private System.Windows.Forms.Label lb_isTriggerPass;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Button btn_clear_trigger_pass_flag;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.RadioButton rb_sc_abs_en;
        private System.Windows.Forms.RadioButton rb_sc_abs_off;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.RadioButton rb_mc_abs_en;
        private System.Windows.Forms.RadioButton rb_mc_abs_off;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.RadioButton rb_mc_reverse_en;
        private System.Windows.Forms.RadioButton rb_mc_reverse_off;
        private System.Windows.Forms.Label lb_cf2000port;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label lb_cf2000mac;
        private System.Windows.Forms.Label lb_cf2000ip;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.NumericUpDown nud_k_index1;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Button bt_setthicknesskparam;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.ComboBox cb_k_ch;
        private System.Windows.Forms.NumericUpDown nud_k_nf;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.NumericUpDown nud_k_nd;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.NumericUpDown nud_k_nc;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.NumericUpDown nud_k_index2;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.RadioButton rdb_lucency_en;
        private System.Windows.Forms.RadioButton rdb_lucency_disen;
        private System.Windows.Forms.CheckBox cb_doubleChannelRSxxxOutput;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.ComboBox cb_rsxxx_parity;
        private System.Windows.Forms.ComboBox cb_rsxxx_baudrate;
        private System.Windows.Forms.Button cb_rsxxx_set;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.RadioButton cb_rsxxx_ascii;
        private System.Windows.Forms.RadioButton cb_rsxxx_hex;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.RadioButton cb_rsxxx_hardware;
        private System.Windows.Forms.RadioButton cb_rsxxx_software;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.RadioButton cb_rsxxx_rs232;
        private System.Windows.Forms.RadioButton cb_rsxxx_rs485;
        private System.Windows.Forms.RadioButton cb_rsxxx_rs422;
        private System.Windows.Forms.Button btn_signalSmooth;
        private System.Windows.Forms.NumericUpDown nud_signalSmoothLen;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.TextBox tb_autoSignalDetectStep;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.RadioButton rb_disable_autoSignalDetect;
        private System.Windows.Forms.RadioButton rb_enable_autoSignalDetect;
        private System.Windows.Forms.Label lb_signalNumber;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.TextBox tb_signalNumberLimit;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.Button btn_k_set;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.NumericUpDown nud_k0;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.NumericUpDown nud_k2;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.NumericUpDown nud_k1;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.GroupBox gb_thickness;
        private System.Windows.Forms.Label lb_calibthicknesspointnum;
        private System.Windows.Forms.Label lb_calibthicknesspoint;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.NumericUpDown nud_calibthickness;
        private System.Windows.Forms.Button bt_reset;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.ComboBox cb_calibrationmode;
        private System.Windows.Forms.Button btn_addPoint;
    }
}

