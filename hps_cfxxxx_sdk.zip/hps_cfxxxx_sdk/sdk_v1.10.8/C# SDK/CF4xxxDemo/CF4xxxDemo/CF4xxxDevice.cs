﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Utils;

namespace CF4xxxDeviceLib
{
    //类型定义

    //控制器类型
    public enum ControlerModel_t
    {
        Model_CF1000,
        Model_CF2000,
        Model_CF4000
    };

    //错误码定义
    public enum StatusTypeDef
    {
        Status_Succeed = 0,
        Status_Others = -1,
        Status_Offline = -2,
        Status_NoDevice = -3,
        Status_DeviceAlreadyOpen = -4,
        Status_DeviceNumberExceedLimit = -5,
        Status_OpenDeviceFailed = -6,
        Status_InvalidPara = -7,
        Status_Timeout = -8,
        Status_DeviceNotFound = -9,
        Status_NotStart = -10,
        Status_InvalidState = -11,
        Status_OutOfRange = -12,
        Status_ParaNotExist = -13,
        Status_NoSignal = -14,
        Status_FileNotFound = -15,
        Status_NoLicense = -16,
        Status_LicenseExpired = -17,
        Status_LoadLibFailed = -18,
        Status_EnvCheckError = -19,
        Status_ErrorSDKVersion = -20,
    };


    //通道测量模式
    enum Confocal_MeasureMode_t
    {
        MeasureMode_Distance = 0,       //距离模式
        MeasureMode_Thickness,          //厚度模式
    };


    // 多通道协同测量下的测量模式
    enum Confocal_CooperationMeasureMode_t
    {
        CM_Thickness = 0,               //双头测厚

    };

    //单距离模式下，选择哪个信号用于计算
    enum Confocal_SignalSelect_t
    {
        Signal_MaxIntensity,            //光强最强的信号
        Signal_NearEnd,                 //最近端信号
        Signal_FarEnd                   //最远端信号
    };

    //返回过程数据的RID
    public  enum ConfocalDataRid_t
    {
	    RID_RESULT = 0,						//测量结果
	    RID_IO_BOARD_TEMP_OVERLOAD,			//温度异常
	    RID_IO_BOARD_FAN_ERROR,				//风扇停转
	    RID_TOLERANCE_ERROR,				//公差异常
	    RID_SIGNAL_ERROR,					//信号异常
	    RID_DEVICE_DISCONNECT,				//设备断开连接
	    RID_API_CALL_EXCEPTION,				//API调用异常
	    RID_ENCODER_COUNT,					//编码器计数值
    };


    //异步通知事件类型
    public enum EventTypeDef
    {
         EventType_DataRecv = 0,             //事件类型:接收数据
    };


    //预设的积分时间,单位us
    /*
    CF2000/CF4000控制器最低曝光时间为20us
    CF1000控制器最低曝光时间为4us
    */
    enum PresetExposureTime_t
    {
        ExposureTime_4 = 4,
        ExposureTime_10 = 10,
        ExposureTime_15 = 15,
        ExposureTime_20 = 20,
        ExposureTime_30 = 30,
        ExposureTime_40 = 40,
        ExposureTime_50 = 50,
        ExposureTime_100 = 100,
        ExposureTime_200 = 200,
        ExposureTime_400 = 400,
        ExposureTime_700 = 700,
        ExposureTime_1000 = 1000,
        ExposureTime_1500 = 1500,
    };


    //警报类型
    enum AlarmType_t
    {
        AlarmType_None,                 //无报警
        AlarmType_UpperLimit,           //上公差报警
        AlarmType_LowerLimit,           //下公差报警
        AlarmTyp_DeviceDisconnect,      //设备断开报警
        AlarmType_SignalWeak,           //信号弱报警
        AlarmType_SignalSaturated,      //信号饱和报警
        AlarmType_TempError,            //温度异常报警
        AlarmType_FanError,             //风扇停转报警
    };

    //输入口触发功能
    enum Confocal_InputPortFunc_t
    {
        InputPort_None = 0,
        InputPort_ExtTrigger,
        InputPort_ExtTriggerCache,
        InputPort_Zero,
        InputPort_StartSample,
        InputPort_StopSample,
        InputPort_SampleToggle,
        InputPort_ClearCache,
        InputPort_EnableCache,
        InputPort_DisableCache,
    };

    //测量单位
    enum Confocal_MeasuretUnit_t
    {
        MeasuretUnit_mm = 0,            //毫米
        MeasuretUnit_um,                //微妙
        MeasuretUnit_inch,              //英寸
    };


    //错误警报输出的开关状态
    enum IoPortState_t
    {
        PortState_Off = 0,              //IO断开
        PortState_On = 1                //IO闭合
    };

    //CF1000控制器binning模式
    enum Confocal_V_BinningMode
    {
        Binning_V_1,
        Binning_V_2,
        Binning_V_4,
    };



    //触发模式选择
    enum Confocal_TriggerMode_t
    {
        Trigger_Internal = 0,           //内部触发
        Trigger_Extern,                
        Trigger_Encoder,                //编码器触发
        Trigger_Timing,                 //内部定时触发
        Trigger_SingleShot,			    //内部单次触发
    };


    //编码器输入模式
    enum Confocal_EncoderInputMode_t
    {
        Mode_1_INC_1 = 0,               //一相一递增	
        Mode_2_INC_1 = 1,               //两相一递增	
        Mode_2_INC_2 = 2,               //两相两递增	
        Mode_2_INC_4 = 3,               //两相四递增	
    } ;


    //编码器工作模式
    enum Confocal_EncoderWorkingMode_t
    {
        Mode_Three_Signal_End = 0,   //三个单端
        Mode_Diff_One_Signal_End = 1,//一个差分一个单端
    };




    //外部触发功能
    enum Confocal_ExtTriggerFunc_t
    {
        Trigger_DirectCapture = 0,      //直接触发
        Trigger_CacheCapture,           //缓存触发
        Trigger_Zero,                   //测量值清零
    };

    //外部触发源
    enum Confocal_ExternTriggerSource_t
    {
        Sync_In_0 = 0,                  //外部触发源0

    };

    //通讯协议控制权
    enum COMM_Protocol_Control_Enum_t
    {
        Hardware = 0,//默认模式
        Software = 1
    };


    //选择通讯协议
    enum COMM_Protocol_Enum_t
    {
        RS422_COMM = 0,                 //默认模式
        RS485_COMM = 1,
        RS232_COMM = 3                  //2和3都是RS232通讯
    };


    //通讯波特率
    enum COMM_BaudRate_Enum_t
    {
        BaudRate_9600 = 0,
        BaudRate_19200 = 1,
        BaudRate_38400 = 2,
        BaudRate_57600 = 3,
        BaudRate_115200 = 4,         //默认波特率
        BaudRate_230400 = 5,
        BaudRate_460800 = 6,
        BaudRate_921600 = 7,
        BaudRate_Max_Num             //多少种波特率选择
    };

    //通讯的校验位,  数据格式：1bit起始位 + 8bit数据位 + 【校验位】 + 1bit停止位
    enum COMM_Parity_Enum_t
    {
        Even = 0, //设置奇偶校验位，以便设置了位的计数为偶数
        Odd = 1,  //设置奇偶校验位，以便设置了位的计数为奇数
        Mark = 2, //将奇偶校验位设置为 1
        Space = 3,//将奇偶校验位设置为 0
        None = 7  //4~7：没有奇偶校验检查时发生
    };


    //通讯的数据格式
    enum COMM_Data_Format_Enum_t
    {
        ASCII = 0,
        Hexadecimal = 1 //默认数据格式

    };



    //数据集的属性
    enum DataSetAttribute_t
    {
        Attribute_MinMax,
        Attribute_Avg,
        Attribute_PtP,
        Attribute_STD
    };

    //设备描述信息
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    struct DeviceInfo_t
    {

        int serverIndex;

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)]
        public string info;
    };


    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    struct ControllerGEPara_t
    {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
        public string controllerIp;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
        public string controllerMAC;

        public UInt16 controllerPort;
    };


    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    struct ControllerGEParaUnsafe_t
    {

        public IntPtr controllerIp;

        public IntPtr controllerMAC;

        public UInt16 controllerPort;
    };


    //独立模式下返回的结果
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    struct SC_ResultDataTypeDef_t
    {

        public int channelIndex;                    //独立模式下该结果对应的通道

        public float saturation;                    //信号饱和度

        public int resultLen;                       //结果的个数，若没使能多距离测量或侧厚度模式，则长度为1，结果存放在result[0]中

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public float[] result;                     //最多存放10个结果

        public int distanceNumber;                 //厚度模式下波峰的个数

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public float[] distance;				    //存放厚度模式下每个波峰对应的距离值

        public Int64 signal;                       //返回信号，仅内部调试有用

        public Int32 signalLength;                 //信号长度

        public Int32 triggerCount;                 //编码器通道0触发计数,只适用于CF2000控制器的编码器触发模式

        public Int32 triggerCount1;               //编码器通道1触发计数,只适用于CF2000控制器的编码器触发模式

        public Int32 triggerCount2;				  //编码器通道2触发计数,只适用于CF2000控制器的编码器触发模式

        public Int32 bTriggerPass;			    //用于指示是否tirgger pass，必须开启trigger pass 调试功能该变量才有效
    };


    //多传感头协同工作下返回的结果
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    struct MC_ResultDataTypeDef_t
    {

        public int groupIndex;                                    //组索引
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public SC_ResultDataTypeDef_t[] channelResult;           //每个通道单独的计算结果
        public float thickness;                                  //双头测厚模式下的计算结果
        public int resultLen;
        public Int32 triggerCount;                              //编码器通道0触发计数,只适用于CF2000控制器的编码器触发模式
        public Int32 triggerCount1;                             //编码器通道1触发计数,只适用于CF2000控制器的编码器触发模式
        public Int32 triggerCount2;				                //编码器通道2触发计数,只适用于CF2000控制器的编码器触发模式
        public Int32 bTriggerPass;			                    //用于指示是否tirgger pass，必须开启trigger pass 调试功能该变量才有效
    };


    //异步事件参数
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct EventCallbackArgs_t
    {

        public EventTypeDef eventType;       //事件类型
        public IntPtr data;                  //数据
        public int dataLen;                 //数据个数
        public int rid;			            //数据RID
    };


    //卡尔曼滤波参数
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    struct KalmanFilterPara_t
    {
        float kalman_k;
        float kalman_threshold;
        UInt32 num_check;
    };



    // 事件委托类型
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate void UserEventCallbackHandleDelegate(int handle, EventCallbackArgs_t arg,IntPtr userPara);
    
    class CF4xxxDevice
    {
        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setControllerModel(ControlerModel_t model);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef scanDeviceList(ref IntPtr devList, ref int deviceNumber);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef openDevice(IntPtr device, ref int handle);


        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef GE_openDevice(ref ControllerGEParaUnsafe_t controllerPara, IntPtr localIP,ref int handle);


        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static void closeDevice(int handle);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        [return: MarshalAs(UnmanagedType.I1)]
        extern static byte isOpen(int handle);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static IntPtr getErrorText(int handle);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static IntPtr getSDKVersion();

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static IntPtr getControlerVersion(int handle);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static IntPtr getSensorHeadSN(int handle, int channel);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static IntPtr getControlerSN(int handle);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef singleShot(int handle, byte[] result);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef darkSignal(int handle, int channel, bool presetExpTime);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef registerEventCallback(UserEventCallbackHandleDelegate eventHandle, IntPtr userPara);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef unregisterEventCallback();

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef continueCaptureStart(int handle);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef continueCaptureStop(int handle);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef zero(int handle, int channel);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setAbsMode(int handle, int channel, bool en);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef reversePos(int handle, int channel, bool en);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setLightIntensity(int handle, int channel, byte value);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setExposureTime(int handle, PresetExposureTime_t us);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef acquisitionFrameMode(int handle, bool en);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef acquisitionFrameRate(int handle, int frameRate);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef bindAlarmIOPort(int handle, int channel, AlarmType_t type, int alarmPort, IoPortState_t portState);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef unbindAlarmIOPort(int handle, int alarmPort);


        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef bindInputPort(int handle, int Channel, Confocal_InputPortFunc_t func, int inputPort);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef unbindInputPort(int handle, int inputPort);


        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setMovingAverageFilter(int handle, int channle, int depth);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef clearMovingAverageFilter(int handle, int channle);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setMedianFilter(int handle, int channle, int depth);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef clearMedianFilter(int handle, int channle);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setAverageFilter(int handle, int avergeNumber);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setErrorFilterDataCount(int handle, int channel, int number);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef enableErrorDataFilter(int handle, int channel, bool en);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setKalmanFilterPara(int handle, int channle, KalmanFilterPara_t para);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef enableKalmanFilter(int handle, int channel, bool en);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef getExistBoard(int handle, byte[] channel);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef getActiveChannel(int handle, byte[] channel);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef isChannelActive(int handle, int channel, ref byte active);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef activeChannel(int handle, int channel, bool en);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setAutoLightIntensity(int handle, int channel, bool en);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef saveUserSetting(int handle);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef restoreFactorySetting(int handle);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setMearsureUnit(int handle, int channel, Confocal_MeasuretUnit_t unit);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef getMeasureRange(int handle, int channel, ref double mini_mm, ref double max_mm);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setChannelMeasureMode(int handle, int channel, Confocal_MeasureMode_t measureMode);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setMainSignalIndex(int handle, int channel, int index);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setMultiDistanceMode(int handle, int channel, bool en);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef selectSignal(int handle, int channel, Confocal_SignalSelect_t signal);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setThicknessLayer(int handle, int channel, byte index1, byte index2, out byte layerIndex);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef removeThicknessLayer(int handle, int channel, int index1, int index2);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef getThicknessLayerNumber(int handle, int channel, ref int layerNumber);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef getThicknessLayerIndex(int handle, int channel, int layerStartIndex, byte[] layer);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef thicknessModeDoCalibration(int handle, int channel, float stdThickness, int areaSelect, int signal1Index, int signal2Index);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef getSaturation(int handle, int channel, ref float saturation);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef reloadSensorHeadPara(int handle, int channel);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef getAnalogVoltageMaxRange(int handle, ref double mini_vol, ref double max_vol);


        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setAnalogVoltageMapping(int handle, int channel, double mini_vol, double max_vol, double value_mini_mm, double value_max_mm);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setAnalogVoltageOutput(int handle, int channel, bool en);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setTriggerMode(int handle, Confocal_TriggerMode_t mode);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setTimmerTriggerFreq(int handle, UInt32 freq);

       [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setEncoderChannel(int handle, int encoderChannel);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef clearEncoderCount(int handle, int encoderChannel);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef enableEncoderCounterNotice(int handle, bool en);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setExternTriggerSource(int handle, Confocal_ExternTriggerSource_t source);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setEncoderDivision(int handle, UInt16 division);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setTriggerSyncOut(int handle, bool en);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setUpperLimit(int handle, int channel, int progSegIndex, double mm);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setLowerLimit(int handle, int channel, int progSegIndex, double mm);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setProgramSegmentIndex(int handle, int channel, int index);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setSignalDetectThresholdCoef(int handle, int channel, double thresholdCoef);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setAutoSignalDetectThresholdCoef(int handle, int channel, double thresholdCoef);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setMiniCalPointsLimit(int handle, int channel, int miniPoints);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setCalculationThreshold(int handle, int channel, double ratio);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setRSxxxProtocol(int handle, COMM_Protocol_Control_Enum_t comm_control, COMM_Protocol_Enum_t comm_protocol);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setRSxxxCommunicationPara(int handle, COMM_BaudRate_Enum_t baudrate, COMM_Parity_Enum_t parity);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setRSxxxDataFormat(int handle, COMM_Data_Format_Enum_t format);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setChannelIndependentMode(int handle, bool en);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setMultiChannelMeasureMode(int handle, Confocal_CooperationMeasureMode_t mode);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setMultiChannelMeasureOffset(int handle, int groupIndex, double offset);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef getMultiChannelMeasureOffset(int handle, int groupIndex, ref double offset);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setDoubleChannelThicknessGroupIndex(int handle, int groupIndex, bool en);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef doubleChannelABSMode(int handle, int channel, bool en);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef doubleChannelThicknessZero(int handle, int groupIndex);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setSignalDataOutput(int handle, bool en);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setAutoSignalDetect(int handle, int channel, bool en);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setDetectSignalNumber(int handle, int channel, int signalNumber);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setSignalSearchAccurateStep(int handle, int channel, byte step);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setSignalRisingStepCount(int handle, int channel, byte count);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setSignalRisingFallRatio(int handle, int channel, double ratio);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef enableDataCache(int handle, int cacheIndex, bool en);
    
        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setDataCacheSize(int handle, int cacheIndex, int dataCount);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef getCurDataCacheCount(int handle, int cacheIndex, ref int dataCount);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef clearDataCache(int handle, int cacheIndex);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef selectCacheData(int handle, int cacheIndex, DataSetAttribute_t attribute, double[] ret, int[] minMaxValueIndex);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef dumpCacheData(int handle, int cacheIndex, double[] retData, int maxCount, ref Int32 dataCount);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef dumpCacheData_SC(int handle, int cacheIndex, SC_ResultDataTypeDef_t[] retData, int maxCount, ref Int32 dataCount);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef dumpCacheData_MC(int handle, int cacheIndex, MC_ResultDataTypeDef_t[] retData, int maxCount, ref Int32 dataCount);


        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setChxOffset(int handle, int channel, float offset);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef getChxOffset(int handle, int channel, ref float offset);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setExtTriggerFunc(int handle, Confocal_ExtTriggerFunc_t func);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef  setControllerIPAddr(int handle, IntPtr ip);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setControllerPort(int handle, UInt16 port);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setTurboMode(int handle, bool en);


        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static UInt32 getCurFrameRate(int handle);


        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setVerticalBinning(int handle, Confocal_V_BinningMode mode);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setEncoderInputMode(int handle, Confocal_EncoderInputMode_t mode);
 
        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setEncoderWorkingMode(int handle, Confocal_EncoderWorkingMode_t mode);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef clearEncodersCount(int handle);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static byte isCaptureStart(int handle);


        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setTriggerPassDebug(int handle,bool en);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef clearTriggerPassFlag(int handle);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef doubleChannelReversePos(int handle, int groupIndex, bool en);


        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef singleShot_MC(int handle, byte[] result);


        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef GE_getControlConnectParam(int handle,  byte[] controllerIP, ref UInt16 controllerPort, byte[] controllerMac);


        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setThicknessRefractivePara(int handle, int channel, int signalIndex1, int signalIndex2, float Nc, float Nd, float Nf);


        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef doubleChannelALMode(int handle, bool en);


        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setDoubleChannelRSxxxOutput(int handle, bool en);


        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setSignalSmoothLen(int handle, int len);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setDoubleChannelThicknessK(int handle, int groupIndex, double[]k);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef clearDoubleChannelThicknessSamplePoint(int handle, int groupIndex);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef setDoubleChannelThicknessSamplePoint(int handle, int groupIndex, float std_thickness);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef doDoubleChannelThicknessCal(int handle, int groupIndex, double[] k);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static int getDoubleChannelThicknessSamplePoint(int handle, int groupIndex);

        [DllImport("hps_cfxxxx_sdk.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        extern static StatusTypeDef getDoubleChannelThicknessK(int handle, int groupIndex, double[] k);





        //超出量程或没信号时输出的无效值
        public const double INVALID_VALUE = 888888;
        


        static UserEventCallbackHandleDelegate userEventHandle;



        /// <summary>
        /// 非托管数据和托管数据转换
        /// </summary>
        /// <param name="ptr"></param>
        /// <param name="signalLen"></param>
        /// <returns></returns>
        public static int[] getSignal(IntPtr ptr, int signalLen)
        {
            if(ptr == IntPtr.Zero)
            {
                return new int[0];
            }

            int[] signal = new int[signalLen];

            Marshal.Copy(ptr, signal, 0, signalLen);

            return signal;
        }


        /// <summary>
        /// 设置要连接的控制器类型，CF1000和CF4000控制器需要调用该接口进行设置，不设置默认为CF4000控制器
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setControllerModel(ControlerModel_t model)
        {
            try
            {
                return setControllerModel(model);
            }
            catch(Exception ex)
            {
                return StatusTypeDef.Status_Others;
            }

         
        }



        /// <summary>
        /// 扫描设备列表
        /// </summary>
        /// <param name="deviceList"></param>
        /// <param name="deviceNumber"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_scanDeviceList(out DeviceInfo_t[] deviceList,out int deviceNumber)
        {
            IntPtr devListPt = IntPtr.Zero;
            deviceNumber = 0;
            deviceList = new DeviceInfo_t[0];

            //扫描设备列表
            StatusTypeDef ret = scanDeviceList(ref devListPt, ref deviceNumber);
            if (ret == StatusTypeDef.Status_Succeed && deviceNumber > 0)
            {

                deviceList = new DeviceInfo_t[deviceNumber];

                byte[] deviceListByteArry = new byte[deviceNumber * Marshal.SizeOf<DeviceInfo_t>()];
                Marshal.Copy(devListPt, deviceListByteArry, 0, deviceListByteArry.Length);
                //将byte 数组转换成结构体
                for (int i = 0; i < deviceNumber; i++)
                {
                    deviceList[i] = (DeviceInfo_t)Util.BytesToStuct(deviceListByteArry, i * Marshal.SizeOf<DeviceInfo_t>(), typeof(DeviceInfo_t));
                    Console.WriteLine(deviceList[i].info);
                }
            }

            return ret;
        }



        /// <summary>
        /// 打开设备，返回设备的handle,适用于CF4000控制器
        /// </summary>
        /// <param name="deviceList"></param>
        /// <param name="handle"></param>
        /// <returns></returns>
        public  static StatusTypeDef hps_openDevice(DeviceInfo_t deviceList, ref int handle)
        {
            StatusTypeDef ret = StatusTypeDef.Status_Succeed;
            IntPtr ptr = Marshal.AllocCoTaskMem(Marshal.SizeOf(typeof(DeviceInfo_t)));
            Marshal.StructureToPtr(deviceList, ptr, true);  //false容易造成内存泄漏
            ret = openDevice(ptr, ref handle);
            Marshal.FreeHGlobal(ptr);    //free tha memory

            return ret;
        }




        /// <summary>
        /// 打开设备，返回设备的handle,适用于CF2000控制器
        /// </summary>
        /// <param name="deviceList"></param>
        /// <param name="handle"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_GE_openDevice(ControllerGEPara_t controllerPara, string localIP, ref int handle)
        {

            StatusTypeDef ret = StatusTypeDef.Status_Succeed;
            ControllerGEParaUnsafe_t para = new ControllerGEParaUnsafe_t();
            para.controllerIp = Marshal.StringToHGlobalAnsi(controllerPara.controllerIp);
            para.controllerMAC = Marshal.StringToHGlobalAnsi(controllerPara.controllerMAC);
            para.controllerPort = controllerPara.controllerPort;


            IntPtr localIP_ptr = Marshal.StringToHGlobalAnsi(localIP);

 
            ret = GE_openDevice(ref para, localIP_ptr, ref handle);

            Marshal.FreeHGlobal(localIP_ptr);//释放分配的非托管内存。 
            return ret;
        }



        /// <summary>
        /// 关闭设备
        /// </summary>
        /// <param name="deviceList"></param>
        /// <param name="handle"></param>
        /// <returns></returns>
        public static void hps_closeDevice(int handle)
        {
            closeDevice(handle);
        }


        /// <summary>
        /// 判断设备是否打开
        /// </summary>
        /// <param name="deviceList"></param>
        /// <param name="handle"></param>
        /// <returns></returns>
        public static bool hps_isOpen(int handle)
        {
            return isOpen(handle)!=0;
        }


    
        /// <summary>
        /// 获取错误码
        /// </summary>
        /// <param name="handle"></param>
        /// <returns></returns>
        public static string hps_getErrorText(int handle)
        {
            string err = "";
            IntPtr ptr =  getErrorText(handle);
            err = Marshal.PtrToStringAnsi(ptr);
            return err;
        }


        /// <summary>
        /// 获取SDK版本
        /// </summary>
        /// <param name="handle"></param>
        /// <returns></returns>
        public static string hps_getSDKVersion()
        {
            string str = "";
            IntPtr ptr = getSDKVersion();
            str = Marshal.PtrToStringAnsi(ptr);
            return str;
        }

        /// <summary>
        /// 获取传感头序列号
        /// </summary>
        /// <returns></returns>
        public static string hps_getSensorHeadSN(int handle,int channel)
        {
            string str = "";
            IntPtr ptr = getSensorHeadSN(handle, channel);
            str = Marshal.PtrToStringAnsi(ptr);
            return str;
        }

        /// <summary>
        /// 获取控制器序列号
        /// </summary>
        /// <returns></returns>
        public static string hps_getControlerSN(int handle)
        {
            string str = "";
            IntPtr ptr = getControlerSN(handle);
            str = Marshal.PtrToStringAnsi(ptr);
            return str;
        }

        /// <summary>
        /// 获取控制器版本号
        /// </summary>
        /// <param name="handle"></param>
        /// <returns></returns>
        public static string hps_getControlerVersion(int handle)
        {
            string str = "";
            IntPtr ptr = getControlerVersion(handle);
            str = Marshal.PtrToStringAnsi(ptr);
            return str;
        }

        /// <summary>
        /// 单次采样
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_singleShot(int handle, out SC_ResultDataTypeDef_t[] result)
        {
            byte[] bytesArray = new byte[Marshal.SizeOf<SC_ResultDataTypeDef_t>() * 4];
            result = new SC_ResultDataTypeDef_t[4];
            StatusTypeDef  ret = singleShot(handle, bytesArray);
            if(ret == StatusTypeDef.Status_Succeed)
            {
                for(int i=0;i<4;i++)
                {
                    result[i] = (SC_ResultDataTypeDef_t)Util.BytesToStuct(bytesArray, i*Marshal.SizeOf<SC_ResultDataTypeDef_t>(), typeof(SC_ResultDataTypeDef_t));
                }
                
            }
            return ret;
        }

        /// <summary>
        /// 采集dark信号
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="channel"></param>
        /// <param name="presetExpTime"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_darkSignal(int handle, int channel, bool presetExpTime)
        {
            return darkSignal(handle, channel, presetExpTime);
        }

   
        /// <summary>
        /// 注册总的事件回调函数
        /// </summary>
        /// <param name="eventHandle"></param>
        /// <param name="userPara"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_registerEventCallback(UserEventCallbackHandleDelegate eventHandle, IntPtr userPara)
        {
            userEventHandle = eventHandle;
            return registerEventCallback(userEventHandle, userPara);
        }


        /// <summary>
        /// 注销总的事件回调函数
        /// </summary>
        /// <param name="eventHandle"></param>
        /// <param name="userPara"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_unregisterEventCallback()
        {
            return unregisterEventCallback();
        }

        /// <summary>
        /// 启动连续采样
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="channel"></param>
        /// <param name="presetExpTime"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_continueCaptureStart(int handle)
        {
            return continueCaptureStart(handle);
        }


        /// <summary>
        /// 停止连续采样
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="channel"></param>
        /// <param name="presetExpTime"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_continueCaptureStop(int handle)
        {
            return continueCaptureStop(handle);
        }


        /// <summary>
        /// 零点复位
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="channel"></param>
        /// <param name="presetExpTime"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_zero(int handle,int channel)
        {
            return zero(handle, channel);
        }



        /// <summary>
        /// 单通道设置ABS模式。测量数据不受零点影响
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="channel"></param>
        /// <param name="presetExpTime"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setAbsMode(int handle, int channel,bool en)
        {
            return setAbsMode(handle, channel, en);
        }


        /// <summary>
        /// 数据翻转
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_reversePos(int handle, int channel, bool en)
        {
            return reversePos(handle, channel, en);
        }


        /// <summary>
        /// 设置照明亮度
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setLightIntensity(int handle, int channel, byte value)
        {
            return setLightIntensity(handle, channel, value);
        }


        /// <summary>
        /// 设置曝光事件
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="us"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setExposureTime(int handle, PresetExposureTime_t us)
        {
            return setExposureTime(handle, us);
        }

        /// <summary>
        /// 设置帧率
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_acquisitionFrameRate(int handle, int frameRate)
        {
            return acquisitionFrameRate(handle, frameRate);
        }


        /// <summary>
        /// 设置帧率控制
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_acquisitionFrameMode(int handle, bool en)
        {
            return acquisitionFrameMode(handle, en);
        }



        /// <summary>
        /// 将IO口和指定通道的特定报警事件绑定
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_bindAlarmIOPort(int handle, int channel, AlarmType_t type, int alarmPort, IoPortState_t portState)
        {
            return bindAlarmIOPort(handle, channel, type, alarmPort, portState);
        }



        /// <summary>
        /// 将指定报警IO口解绑
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_unbindAlarmIOPort(int handle, int alarmPort)
        {
            return unbindAlarmIOPort(handle, alarmPort);
        }


        /// <summary>
        /// 将IO口和指定通道的功能绑定
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_bindInputPort(int handle, int Channel, Confocal_InputPortFunc_t func, int inputPort)
        {
            return bindInputPort(handle,  Channel,  func,  inputPort);
        }


        /// <summary>
        /// 将指定输入IO口解绑
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_unbindInputPort(int handle, int inputPort)
        {
            return unbindInputPort(handle, inputPort);
        }



        /// <summary>
        /// 设置连续采样模式下滑动平均滤波
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setMovingAverageFilter(int handle, int channle, int depth)
        {
            return setMovingAverageFilter(handle, channle, depth);
        }


        /// <summary>
        /// 清空滑动平均滤波里面的数据
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_clearMovingAverageFilter(int handle, int channle)
        {
            return clearMovingAverageFilter(handle, channle);
        }

        /// <summary>
        /// 设置连续采样模式下中值滤波
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setMedianFilter(int handle, int channle, int depth)
        {
            return setMedianFilter(handle, channle, depth);
        }

        /// <summary>
        /// 	清空滑动中值滤波里面的数据
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_clearMedianFilter(int handle, int channle)
        {
            return clearMedianFilter(handle, channle);
        }

        /// <summary>
        /// 设置全局平均滤波
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setAverageFilter(int handle, int avergeNumber)
        {
            return setAverageFilter(handle, avergeNumber);
        }

        /// <summary>
        /// 设置异常数据个数，连续异常数据大于该个数则输出数据给用户，小于则不输出
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setErrorFilterDataCount(int handle, int channel, int number)
        {
            return setErrorFilterDataCount(handle, channel, number);
        }

        /// <summary>
        /// 使能异常数据滤波
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_enableErrorDataFilter(int handle, int channel, bool en)
        {
            return enableErrorDataFilter(handle, channel, en);
        }

        /// <summary>
        /// 设置卡尔曼滤波参数
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setKalmanFilterPara(int handle, int channel, KalmanFilterPara_t para)
        {
            return setKalmanFilterPara(handle, channel, para);
        }


        /// <summary>
        /// 设置卡尔曼滤波参数
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_enableKalmanFilter(int handle, int channel, bool en)
        {
            return enableKalmanFilter(handle, channel, en);
        }


        /// <summary>
        /// 获取当前插入的板卡数量
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_getExistBoard(int handle, byte[] channel)
        {
            return getExistBoard(handle, channel);
        }


        /// <summary>
        /// 获取激活的通道
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_getActiveChannel(int handle, byte[] channel)
        {
            return getActiveChannel(handle, channel);
        }


        /// <summary>
        /// 获取激活的通道
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_isChannelActive(int handle, int channel, ref byte active)
        {
            return isChannelActive(handle, channel,ref active);
        }


        /// <summary>
        /// 激活指定通道
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_activeChannel(int handle, int channel, bool en)
        {
            return activeChannel(handle, channel, en);
        }

        /// <summary>
        /// 设置自动调光
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setAutoLightIntensity(int handle, int channel, bool en)
        {
            return setAutoLightIntensity(handle, channel, en);
        }

        /// <summary>
        /// 保存用户配置到Flash中
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_saveUserSetting(int handle)
        {
            return saveUserSetting(handle);
        }


        /// <summary>
        ///恢复出厂设置
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_restoreFactorySetting(int handle)
        {
            return restoreFactorySetting(handle);
        }


        /// <summary>
        ///设置测量单位，默认的测量单位为mm
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setMearsureUnit(int handle,int channel, Confocal_MeasuretUnit_t unit)
        {
            return setMearsureUnit(handle,channel,unit);
        }

        /// <summary>
        ///设置测量单位，默认的测量单位为mm
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_getMeasureRange(int handle, int channel, out double mini_mm, out double max_mm)
        {
            mini_mm = 0;
            max_mm = 0;
            return getMeasureRange(handle, channel, ref mini_mm,ref max_mm);
        }



        /// <summary>
        ///设置指定通道的测量模式
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setChannelMeasureMode(int handle, int channel, Confocal_MeasureMode_t measureMode)
        {
            return setChannelMeasureMode(handle, channel, measureMode);
        }

        /// <summary>
        ///设置主光斑索引
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setMainSignalIndex(int handle, int channel, int index)
        {
            return setMainSignalIndex(handle, channel, index);
        }

        /// <summary>
        ///设置多个距离模式，不打开则只计算强度最高的光斑对应的距离
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setMultiDistanceMode(int handle, int channel, bool en)
        {
            return setMultiDistanceMode(handle, channel, en);
        }

        /// <summary>
        ///单距离模式下选择那个信号计算
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_selectSignal(int handle, int channel, Confocal_SignalSelect_t signal)
        {
            return selectSignal(handle, channel, signal);
        }



        /// <summary>
        ///指定厚度测量时的层的索引,不设置默认使用0、1个波峰
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setThicknessLayer(int handle, int channel, byte index1, byte index2, out byte layerIndex)
        {
            layerIndex = 0;
            return setThicknessLayer(handle, channel, index1, index2,out layerIndex);
        }


        /// <summary>
        ///删除已经设置的厚度测量的层索引
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_removeThicknessLayer(int handle, int channel, int index1, int index2)
        {
            return removeThicknessLayer(handle, channel, index1, index2);
        }


        /// <summary>
        ///获取厚度测量下光斑索引组数
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_getThicknessLayerNumber(int handle, int channel, out int layerNumber)
        {
            layerNumber = 0;
            return getThicknessLayerNumber(handle, channel, ref layerNumber);
        }


        /// <summary>
        ///获取厚度测量下光斑索引组数
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_getThicknessLayerIndex(int handle, int channel, int layerStartIndex,byte[] layer)
        {
            
            return getThicknessLayerIndex(handle, channel, layerStartIndex,layer);
        }

        /// <summary>
        ///执行厚度测量校准
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_thicknessModeDoCalibration(int handle, int channel, float stdThickness, int areaSelect, int signal1Index, int signal2Index)
        {

            return thicknessModeDoCalibration(handle, channel, stdThickness, areaSelect, signal1Index, signal2Index);
        }

        /// <summary>
        ///获取指定通道信号的饱和度
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_getSaturation(int handle, int channel,  out float saturation)
        {
            saturation = 0;
            return getSaturation(handle, channel,ref saturation);
        }

        /// <summary>
        ///重新加载指定通道的参数
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_reloadSensorHeadPara(int handle, int channel)
        {
            return reloadSensorHeadPara(handle, channel);
        }

        /// <summary>
        ///获取模拟输出的范围
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_getAnalogVoltageMaxRange(int handle,out double mini_vol, out double max_vol)
        {
            mini_vol = 0;
            max_vol = 0;
            return getAnalogVoltageMaxRange(handle, ref mini_vol, ref max_vol);
        }


        /// <summary>
        ///获取模拟输出的范围
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setAnalogVoltageMapping(int handle, int channel, double mini_vol, double max_vol, double value_mini_mm, double value_max_mm)
        {
            return setAnalogVoltageMapping(handle, channel, mini_vol, max_vol, value_mini_mm, value_max_mm);
        }

        /// <summary>
        ///使能模拟电压输出
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setAnalogVoltageOutput(int handle, int channel, bool en)
        {
            return setAnalogVoltageOutput(handle, channel, en);
        }

        /// <summary>
        ///设置触发模式
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setTriggerMode(int handle, Confocal_TriggerMode_t mode)
        {
            return setTriggerMode(handle, mode);
        }


        /// <summary>
        /// 设置内部定时器触发频率
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="freq"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setTimmerTriggerFreq(int handle, UInt32 freq)
        {
            return setTimmerTriggerFreq(handle, freq);
        }



        /// <summary>
        ///设置编码器通道
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setEncoderChannel(int handle, int encoderChannel)
        {
            return setEncoderChannel(handle, encoderChannel);
        }

        /// <summary>
        ///清除编码器内部脉冲计数
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_clearEncoderCount(int handle, int encoderChannel)
        {
            return clearEncoderCount(handle, encoderChannel);
        }

        /// <summary>
        ///设置编码器计数异步通知,使能通知后会在数据接收回调函数中接收编码器计数结果
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_enableEncoderCounterNotice(int handle, bool en)
        {
            return enableEncoderCounterNotice(handle, en);
        }

        /// <summary>
        ///设置编码器计数异步通知,使能通知后会在数据接收回调函数中接收编码器计数结果
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setExternTriggerSource(int handle, Confocal_ExternTriggerSource_t source)
        {
            return setExternTriggerSource(handle, source);
        }


        /// <summary>
        ///设置编码器触发的分频因子
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setEncoderDivision(int handle, UInt16 division)
        {
            return setEncoderDivision(handle, division);
        }

        /// <summary>
        ///使能外部同步输出
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setTriggerSyncOut(int handle, bool en)
        {
            return setTriggerSyncOut(handle, en);
        }

        /// <summary>
        ///设置公差上限
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setUpperLimit(int handle, int channel, int progSegIndex, double mm)
        {
            return setUpperLimit(handle, channel, progSegIndex, mm);
        }

        /// <summary>
        ///设置公差下限
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setLowerLimit(int handle, int channel, int progSegIndex, double mm)
        {
            return setLowerLimit(handle, channel, progSegIndex, mm);
        }


        /// <summary>
        ///设定公差上下限IO报警程序段
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setProgramSegmentIndex(int handle, int channel, int index)
        {
            return setProgramSegmentIndex(handle, channel, index);
        }


        /// <summary>
        ///设置信号检测的阈值系数
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setSignalDetectThresholdCoef(int handle, int channel, double thresholdCoef)
        {
            return setSignalDetectThresholdCoef(handle, channel, thresholdCoef);
        }

        /// <summary>
        ///设置自动信号检测阈值系数，为噪声的倍数，大于该数值则开始自动查找信号
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setAutoSignalDetectThresholdCoef(int handle, int channel, double thresholdCoef)
        {
            return setAutoSignalDetectThresholdCoef(handle, channel, thresholdCoef);
        }


        /// <summary>
        ///设置最小的计算点数，少于该值则认为是无效信号
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setMiniCalPointsLimit(int handle, int channel, int miniPoints)
        {
            return setMiniCalPointsLimit(handle, channel, miniPoints);
        }


        /// <summary>
        ///设置信号计算的阈值
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setCalculationThreshold(int handle, int channel, double ratio)
        {
            return setCalculationThreshold(handle, channel, ratio);
        }


        /// <summary>
        ///设置RSxxx通讯协议
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setRSxxxProtocol(int handle, COMM_Protocol_Control_Enum_t comm_control, COMM_Protocol_Enum_t comm_protocol)
        {
            return setRSxxxProtocol(handle, comm_control, comm_protocol);
        }


        /// <summary>
        ///设置RSxxx通讯参数
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setRSxxxCommunicationPara(int handle, COMM_BaudRate_Enum_t baudrate, COMM_Parity_Enum_t parity)
        {
            return setRSxxxCommunicationPara(handle, baudrate, parity);
        }

        /// <summary>
        ///设置RSxxx命令解析格式
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setRSxxxDataFormat(int handle, COMM_Data_Format_Enum_t format)
        {
            return setRSxxxDataFormat(handle, format);
        }


        //// <summary>
        ///设置或关闭独立模式
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setChannelIndependentMode(int handle, bool en)
        {
            return setChannelIndependentMode(handle, en);
        }

        //// <summary>
        ///设置多通道协同下的测量模式
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setMultiChannelMeasureMode(int handle, Confocal_CooperationMeasureMode_t mode)
        {
            return setMultiChannelMeasureMode(handle, mode);
        }


        //// <summary>
        ///设置多通道协同测量下的offset
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setMultiChannelMeasureOffset(int handle, int groupIndex, double offset)
        {
            return setMultiChannelMeasureOffset(handle, groupIndex, offset);
        }

        //// <summary>
        ///获取多通道协同测量下的offset
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_getMultiChannelMeasureOffset(int handle, int groupIndex, out double offset)
        {
            offset = 0;
            return getMultiChannelMeasureOffset(handle, groupIndex, ref offset);
        }

        //// <summary>
        ///设置双头测厚模式下组索引，0组对应0、1通道；1组对一个2、3通道
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setDoubleChannelThicknessGroupIndex(int handle, int groupIndex, bool en)
        {
            return setDoubleChannelThicknessGroupIndex(handle, groupIndex, en);
        }

        //// <summary>
        ///	双头测量使能ABS模式，测量数据不受零点影响
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_doubleChannelABSMode(int handle, int groupIndex, bool en)
        {
            return doubleChannelABSMode(handle, groupIndex, en);
        }

        //// <summary>
        ///双头测厚对两个通道进行zero
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_doubleChannelThicknessZero(int handle, int groupIndex)
        {
            return doubleChannelThicknessZero(handle, groupIndex);
        }


        //// <summary>
        ///使能输出信号数据
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setSignalDataOutput(int handle, bool en)
        {
            return setSignalDataOutput(handle, en);
        }

        //// <summary>
        ///使能多个信号自动检测
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setAutoSignalDetect(int handle, int channel, bool en)
        {
            return setAutoSignalDetect(handle, channel, en);
        }

        //// <summary>
        ///设置检测的信号个数，如果检测到的信号个数不等于该个数，则输出无效值
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setDetectSignalNumber(int handle, int channel, int signalNumber)
        {
            return setDetectSignalNumber(handle, channel, signalNumber);
        }

        //// <summary>
        ///设置精确查找信号的步伐
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setSignalSearchAccurateStep(int handle, int channel, byte step)
        {
            return setSignalSearchAccurateStep(handle, channel, step);
        }





        //// <summary>
        ///使能Cache缓存，上电Cache缓存默认是使能状态
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_enableDataCache(int handle, int cacheIndex, bool en)
        {
            return enableDataCache(handle, cacheIndex, en);
        }



        //// <summary>
        ///将Cache里面的所有数据都获取出来,获取的数据类型为double,用户应该先调用getCurDataCacheCount获取当前Cache里面有多少数据，在开辟好内存空间将数据获取出去
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_dumpCacheData(int handle, int cacheIndex, double[] retData, int maxCount, ref Int32 dataCount)
        {

            return dumpCacheData(handle, cacheIndex, retData, maxCount,ref dataCount);
        }


        //// <summary>
        ///将Cache里面的所有数据都获取出来，获取的数据类型为SC_ResultDataTypeDef_t,用户应该先调用getCurDataCacheCount获取当前Cache里面有多少数据，在开辟好内存空间将数据获取出去
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_dumpCacheData_SC(int handle, int cacheIndex, SC_ResultDataTypeDef_t[] retData, int maxCount, ref Int32 dataCount)
        {

            return dumpCacheData_SC(handle, cacheIndex, retData, maxCount, ref dataCount);
        }


        //// <summary>
        ///将Cache里面的所有数据都获取出来，获取的数据类型为MC_ResultDataTypeDef_t,用户应该先调用getCurDataCacheCount获取当前Cache里面有多少数据，在开辟好内存空间将数据获取出去
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_dumpCacheData_MC(int handle, int cacheIndex, MC_ResultDataTypeDef_t[] retData, int maxCount, ref Int32 dataCount)
        {

            return dumpCacheData_MC(handle, cacheIndex, retData, maxCount, ref dataCount);
        }



        //// <summary>
        ///设置数据缓存的大小，默认可以缓存100万个数据
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setDataCacheSize(int handle, int cacheIndex, int dataCount)
        {
            return setDataCacheSize(handle, cacheIndex, dataCount);
        }

        //// <summary>
        ///获取当前数据缓存的数据个数
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_getCurDataCacheCount(int handle, int cacheIndex, out int dataCount)
        {
            dataCount = 0;
            return getCurDataCacheCount(handle, cacheIndex, ref dataCount);
        }

        //// <summary>
        ///清空数据缓存
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_clearDataCache(int handle, int cacheIndex)
        {

            return clearDataCache(handle, cacheIndex);
        }


        //// <summary>
        ///根据用户指定的数据属性，使用数据缓存的数据计算出结果
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public static StatusTypeDef hps_selectCacheData(int handle, int cacheIndex, DataSetAttribute_t attribute, double[]ret, int[] minMaxValueIndex)
        {
            
            return selectCacheData(handle, cacheIndex, attribute, ret, minMaxValueIndex);
        }

		/// <summary>
        /// 设置指定通道的位移偏差补偿值
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="channel">0-3</param>
        /// <param name="offset"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setChxOffset(int handle, int channel, float offset)
        {
            return setChxOffset(handle, channel, offset);
        }

        /// <summary>
        /// 获取指定通道的位移偏差补偿值
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="channel">0-3</param>
        /// <param name="offset"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_getChxOffset(int handle, int channel, ref float offset)
        {
            return getChxOffset(handle, channel, ref offset);
        }




        /// <summary>
        /// 设置外部触发指定的功能模式
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="channel">0-3</param>
        /// <param name="offset"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setExtTriggerFunc(int handle, Confocal_ExtTriggerFunc_t func)
        {
            return setExtTriggerFunc(handle, func);
        }



        /// <summary>
        /// 设置控制器IP地址
        /// </summary>
        /// <param name="ip"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setControllerIPAddr(int handle, string ip)
        {
            IntPtr string_ptr = Marshal.StringToHGlobalAnsi(ip);
            StatusTypeDef ret  = setControllerIPAddr(handle, string_ptr);
            Marshal.FreeHGlobal(string_ptr);
            return ret;
        }

        /// <summary>
        /// 设置控制器端口号
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="port"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setControllerPort(int handle, UInt16 port)
        {
            return setControllerPort(handle,port);
        }


        /// <summary>
        /// 使能加速模式，只适用于CF1000控制器
        /// /// </summary>
        /// <param name="handle"></param>
        /// <param name="en"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setTurboMode(int handle, bool en)
        {

            try
            {
                return setTurboMode(handle, en);
            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
          
        }



        /// <summary>
        /// 获取当前的帧率
        /// </summary>
        /// <param name="handle"></param>
        /// <returns></returns>
        public static UInt32 hps_getCurFrameRate(int handle)
        {
            try
            {
                return getCurFrameRate(handle);
            }
            catch(Exception ex)
            {
                return 0;
            }
           
        }


        /// <summary>
        /// 设置相机bining模式,只适用于CF1000控制器
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setVerticalBinning(int handle, Confocal_V_BinningMode mode)
        {

            try
            {
                return setVerticalBinning(handle, mode);
            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
           
        }



        /// <summary>
        /// 设置编码器输入模式
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setEncoderInputMode(int handle, Confocal_EncoderInputMode_t mode)
        {
            try
            {
                return setEncoderInputMode(handle, mode);
            }
            catch(Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
        }


        /// <summary>
        /// 设置编码器工作模式
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setEncoderWorkingMode(int handle, Confocal_EncoderWorkingMode_t mode)
        {
            try
            {
                return setEncoderWorkingMode(handle, mode);
            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
        }

        /// <summary>
        /// 清除所有编码器通道的计数
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_clearEncodersCount(int handle)
        {
            try
            {
                return clearEncodersCount(handle);
            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
        }



        /// <summary>
        /// 获取当前是否在连续采样数据
        /// </summary>
        /// <param name="handle"></param>
        /// <returns></returns>
        public static bool hps_isCaptureStart(int handle)
        {
            try
            {
              byte ret = isCaptureStart(handle);

                return ret != 0;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        /// <summary>
        /// 使能trigger pass 调试功能,成功使能后返回的结果里面 bTriggerPass变量用于指示是否trigger pass
        /// </summary>
        /// <param name="handle"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_setTriggerPassDebug(int handle,bool en)
        {
            try
            {
                return setTriggerPassDebug(handle, en);
            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
        }


        /// <summary>
        ///清除trigger pass 标志位
        /// </summary>
        /// <param name="handle"></param>
        /// <returns></returns>
        public static StatusTypeDef hps_clearTriggerPassFlag(int handle)
        {
            try
            {
                return clearTriggerPassFlag(handle);
            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
        }


        /// <summary>
        /// 双头测量测量值翻转
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="groupIndex"></param>
        /// <param name="en"></param>
        /// <returns></returns>

        public static StatusTypeDef hps_doubleChannelReversePos(int handle, int groupIndex, bool en)
        {
            try
            {
                return doubleChannelReversePos(handle, groupIndex, en);
            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
        }

        public static StatusTypeDef hps_singleShot_MC(int handle, out MC_ResultDataTypeDef_t[] result)
        {
            result = new MC_ResultDataTypeDef_t[2];
            try
            {
                byte[] bytesArray = new byte[Marshal.SizeOf<MC_ResultDataTypeDef_t>() * 2];
                StatusTypeDef ret = singleShot_MC(handle, bytesArray);
                if (ret == StatusTypeDef.Status_Succeed)
                {
                    for (int i = 0; i < 2; i++)
                    {
                        result[i] = (MC_ResultDataTypeDef_t)Util.BytesToStuct(bytesArray, i * Marshal.SizeOf<MC_ResultDataTypeDef_t>(), typeof(MC_ResultDataTypeDef_t));
                    }

                }
                return ret;
            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
        }

        public static StatusTypeDef hps_GE_getControlConnectParam(int handle, out string controlerIP,out UInt16 controlerPort, out string controlerMAC)
        {
            controlerIP = "";
            controlerPort = 0;
            controlerMAC = "";

            try
            {
                StatusTypeDef ret;
                byte[] ip = new byte[32];
                byte[] mac = new byte[32];
                ret  = GE_getControlConnectParam(handle,ip, ref controlerPort, mac);
                if (ret != StatusTypeDef.Status_Succeed)
                    return ret;


                controlerIP = System.Text.Encoding.Default.GetString(ip);
                controlerMAC = System.Text.Encoding.Default.GetString(mac);
                return ret;

            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
        }


        public static StatusTypeDef hps_setThicknessRefractivePara(int handle, int channel, int signalIndex1, int signalIndex2, float Nc, float Nd, float Nf)
        {
            try
            {
                return setThicknessRefractivePara(handle, channel, signalIndex1, signalIndex2, Nc,Nd,Nf);
            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
        }


        public static StatusTypeDef hps_doubleChannelALMode(int handle, bool en)
        {
            try
            {
                return doubleChannelALMode(handle, en);
            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
        }


        public static StatusTypeDef hps_setDoubleChannelRSxxxOutput(int handle, bool en)
        {
            try
            {
                return setDoubleChannelRSxxxOutput(handle, en);
            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
        }

        public static StatusTypeDef hps_setSignalSmoothLen(int handle, int len)
        {
            try
            {
                return setSignalSmoothLen(handle, len);
            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
        }

        public static StatusTypeDef hps_setDoubleChannelThicknessK(int handle, int groupIndex, double[] k)
        {
            try
            {
                return setDoubleChannelThicknessK(handle, groupIndex, k);
            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
        }

        public static StatusTypeDef hps_clearDoubleChannelThicknessSamplePoint(int handle, int groupIndex)
        {
            try
            {
                return clearDoubleChannelThicknessSamplePoint(handle, groupIndex);
            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
        }

        public static StatusTypeDef hps_setDoubleChannelThicknessSamplePoint(int handle, int groupIndex, float std_thickness)
        {
            try
            {
                return setDoubleChannelThicknessSamplePoint(handle, groupIndex, std_thickness);
            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
        }

        public static StatusTypeDef hps_doDoubleChannelThicknessCal(int handle, int groupIndex, double[] k)
        {
            try
            {
                return doDoubleChannelThicknessCal(handle, groupIndex, k);
            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
        }

        public static int hps_getDoubleChannelThicknessSamplePoint(int handle, int groupIndex)
        {
            try
            {
                return getDoubleChannelThicknessSamplePoint(handle, groupIndex);
            }
            catch (Exception ex)
            {
                return (int)StatusTypeDef.Status_ErrorSDKVersion;
            }
        }

        public static StatusTypeDef hps_getDoubleChannelThicknessK(int handle, int groupIndex, double[] k)
        {
            try
            {
                return getDoubleChannelThicknessK(handle, groupIndex,k);
            }
            catch (Exception ex)
            {
                return StatusTypeDef.Status_ErrorSDKVersion;
            }
        }




    }
}
