﻿// DllTest.cpp : 定义控制台应用程序的入口点。
//

#include "stdafx.h"
#include <iostream>
#include <windows.h>
#include <time.h>

#include "UserInterface.h"


//#define CF2000

using namespace std;





DeviceHandle_t g_handler;
DeviceInfo_t*  g_devList = NULL;
float g_measureData = 0;
float g_saturation = 0;
float g_channel = 0;

void eventCallback(DeviceHandle_t handler, EventCallbackArgs_t arg, void*userPara)
{
	SC_ResultDataTypeDef_t* res;

	if (handler == g_handler)
	{
		
		//接收到数据，这里不宜做复杂的操作，应该只是将数据拷贝走
		if (arg.eventType == EventType_DataRecv)
		{
			//数据类型
			if (arg.rid == RID_RESULT)
			{
				//arg.dataLen:有多少个通道的数据。 res[i]:通道i的数据，如果只有一个通道则arg.dataLen为1
				res = (SC_ResultDataTypeDef_t*)arg.data;
					
				//读取测量结果
				g_channel = res[0].channelIndex;   //该结果对应的通道索引
				g_measureData = res[0].result[0];  //测量结果,默认没有使能多距离测量模式只有resul[0]数据是有效的
				g_saturation = res[0].saturation;	//信号饱和度
				if (g_measureData == INVALID_VALUE) //没有信号，输出无效值
				{
					
				}
			}
			else if (arg.rid == RID_DEVICE_DISCONNECT)   //设备断开
			{
				cout << "Device disconnected!\r\n";
			}
			else if (arg.rid == RID_API_CALL_EXCEPTION)	 //API调用异常
			{
				const char* err = (const char*)arg.data;
				cout << err << endl;
			}

		}
	}
}




int main()
{
	StatusTypeDef state;
	int deviceNumber = 0;

	int channel = 0;  //通道0

#ifdef CF2000  //CF2000网口控制器

	//所有通信参数都使用默认值
	state = GE_openDevice(NULL, NULL, &g_handler);
	if (state != Status_Succeed)
	{
		cout << "Open device failed Error code: " << state << endl;
		getchar();
		return -1;
	}
#else			//CF4000 USB3.0控制器
	//扫描设备
	scanDeviceList(&g_devList, &deviceNumber);
	if (deviceNumber == 0)
	{
		cout << "No USB device detected\r\n";
		getchar();
		return -1;

	}

	//打开设备列表的第一个设备
	state = openDevice(&g_devList[0], &g_handler);
	if (state != Status_Succeed)
	{
		cout << "Open device failed Error code: " << state << endl;
		getchar();
		return -1;
	}
	
#endif

	cout << "SDK version: " << getSDKVersion() << endl;
	cout << "Controler version: " << getControlerVersion(g_handler) << endl;

	//注册事件回调函数
	registerEventCallback(eventCallback, NULL);

	//设定曝光时间为100us
	state = setExposureTime(g_handler, ExposureTime_100);
	if (state != Status_Succeed)
	{
		cout << getErrorText(g_handler) << endl;
		getchar();
		return -1;
	}

	//使能通道0自动光强调节
	state = setAutoLightIntensity(g_handler, channel, true);
	if (state != Status_Succeed)
	{
		cout << getErrorText(g_handler) << endl;
		getchar();
		return -1;
	}


	

	//启动连续采样
	state = continueCaptureStart(g_handler);
	if (state != Status_Succeed)
	{
		cout << getErrorText(g_handler) << endl;
		getchar();
		return -1;
	}


	//按下回车键退出循环
	while (!(GetAsyncKeyState(VK_RETURN) & 0x8000f))
	{
		cout << "Result :" << g_measureData <<"  Saturation :" << g_saturation << endl;
		Sleep(200);
	}



	//关闭设备，释放所有资源
	closeDevice(g_handler);

    return 0;
}

